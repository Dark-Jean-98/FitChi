import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:fitchi_app/screens/login.dart';
import 'package:fitchi_app/screens/home.dart';
import 'package:fitchi_app/screens/meta_fisica.dart';
import 'package:fitchi_app/screens/recetas_page.dart';
import 'package:fitchi_app/screens/edit_profile.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  await Supabase.initialize(
    url: 'https://ifoxmbxdttyckphrunlf.supabase.co',  // Reemplaza con tu URL
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imlmb3htYnhkdHR5Y2twaHJ1bmxmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk3MDU3MzcsImV4cCI6MjA3NTI4MTczN30.hFRQS9faV6Axc1lFDziuxSdEs3ySL_RwAlX2GoVLT3o', // Reemplaza con tu anon key
  );
  
  runApp(const MyApp());
}

// Cliente global de Supabase
final supabase = Supabase.instance.client;

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'FitChi',
      initialRoute: '/',
      routes: {
        '/': (context) => const LoginScreen(),
        '/meta-fisica': (context) => const MetaFisicaPage(),
        '/recetas': (context) => const RecetasPage(),
        '/edit-profile': (context) => const EditProfilePage(),
      },
      onGenerateRoute: (settings) {
        if (settings.name == '/home') {
          final args = settings.arguments as Map<String, dynamic>?;
          final userName = args?['userName'] ?? 'Usuario';
          return MaterialPageRoute(
            builder: (context) => HomeScreen(userName: userName),
          );
        }
        return null;
      },
    );
  }
}