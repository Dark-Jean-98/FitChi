import 'package:fitchi_app/styled_text.dart';
import 'package:flutter/material.dart';
import 'screens/login.dart';

const starAlignment = Alignment.topCenter;
const endAlignment = Alignment.bottomCenter;

class GradientContainer extends StatelessWidget {
  const GradientContainer({super.key});

void botonEmpezar () {}

  @override
  Widget build(context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Color.fromARGB(255, 166, 226, 198),
            Color.fromARGB(255, 106, 168, 138),
            Color.fromARGB(255, 15, 119, 69),
            Color.fromARGB(255, 2, 80, 42)
          ],
          begin: starAlignment,
          end: endAlignment,
        ),
      ),
      child:  Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset('assets/images/FitChiLogo_SinFondo.png', 
              width: 200,  
              height: 200,
            ),
            SizedBox(height: 80),

            // Texto principal
            StyledText(),

            SizedBox(height: 80),

            // Subtítulo
            Text(
              "Tu plan nutricional personalizado e inteligente",
              style: TextStyle(
                color: Colors.white70, // un poco más tenue
                fontSize: 20,
                fontWeight: FontWeight.normal,
              ),
              textAlign: TextAlign.center,
            ),

            SizedBox(height: 80),

            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const LoginScreen()),
                );
              },
              child: const Text("EMPEZAR"),
                )

            
          ],
        ),
      ),
    );
  }
}
