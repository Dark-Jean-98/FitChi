import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'custom_bottom_nav.dart';

class MenuSemanalPage extends StatefulWidget {
  const MenuSemanalPage({super.key});

  @override
  State<MenuSemanalPage> createState() => _MenuSemanalPageState();
}

class _MenuSemanalPageState extends State<MenuSemanalPage> {
  final String baseUrl = "https://fitchi-backend-398799029559.southamerica-west1.run.app";
  final supabase = Supabase.instance.client;
  static const Color verdeApp = Color(0xFF66BB6A);
  
  Map<String, dynamic>? menuSemanal;
  bool _cargando = true;
  int progreso = 0;
  bool menuCompleto = false;

  @override
  void initState() {
    super.initState();
    _cargarMenuSemanal();
  }

  Future<void> _cargarMenuSemanal() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/menu-semanal/${user.id}'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          menuSemanal = data['menu'];
          progreso = data['progreso'];
          menuCompleto = data['completo'];
          _cargando = false;
        });
      }
    } catch (e) {
      setState(() => _cargando = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        automaticallyImplyLeading: false,
        title: const Text(
          'Mi Menú Semanal',
          style: TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.black),
            onPressed: _cargarMenuSemanal,
          ),
        ],
      ),
      body: _cargando
          ? const Center(child: CircularProgressIndicator())
          : menuSemanal == null || (menuSemanal!.isEmpty)
              ? _buildEmptyState()
              : Column(
                  children: [
                    if (!menuCompleto) _buildProgresoBar(),
                    Expanded(child: _buildMenuList()),
                  ],
                ),
      bottomNavigationBar: const CustomBottomNav(currentIndex: 4),
    );
  }

  Widget _buildProgresoBar() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.orange[50],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.orange[200]!),
      ),
      child: Column(
        children: [
          Row(
            children: [
              const Icon(Icons.access_time, color: Colors.orange),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Generando tu menú personalizado',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '$progreso% completado',
                      style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          LinearProgressIndicator(
            value: progreso / 100,
            backgroundColor: Colors.orange[100],
            valueColor: const AlwaysStoppedAnimation<Color>(Colors.orange),
          ),
        ],
      ),
    );
  }

  Widget _buildMenuList() {
    final dias = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
    
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: dias.length,
      itemBuilder: (context, index) {
        final dia = dias[index];
        final comidasDia = menuSemanal![dia];
        
        return _buildDiaCard(dia, comidasDia);
      },
    );
  }

  Widget _buildDiaCard(String dia, Map<String, dynamic> comidas) {
    final tieneComidas = comidas.values.any((c) => c != null);
    final esHoy = _esDiaDeHoy(dia);
    
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: esHoy ? 4 : 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: esHoy 
          ? BorderSide(color: verdeApp, width: 2)
          : BorderSide.none,
      ),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: esHoy 
                  ? verdeApp
                  : verdeApp.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                Icons.calendar_today,
                color: esHoy ? Colors.white : verdeApp,
                size: 20
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        dia,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: esHoy ? FontWeight.bold : FontWeight.w600,
                        ),
                      ),
                      if (esHoy) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: verdeApp,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Text(
                            'HOY',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 8, left: 40),
          child: Text(
            tieneComidas ? '4 comidas planificadas' : 'Generando...',
            style: TextStyle(fontSize: 12, color: Colors.grey[600]),
          ),
        ),
        children: [
          const Divider(height: 1),
          _buildComidaItem('Desayuno', comidas['desayuno'], Icons.wb_sunny_outlined),
          _buildComidaItem('Almuerzo', comidas['almuerzo'], Icons.restaurant),
          _buildComidaItem('Cena', comidas['cena'], Icons.dinner_dining),
          _buildComidaItem('Snack', comidas['snack'], Icons.cookie_outlined),
        ],
      ),
    );
  }

  Widget _buildComidaItem(String titulo, dynamic comida, IconData icon) {
    return InkWell(
      onTap: comida != null ? () => _mostrarRecetaCompleta(comida) : null,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        child: Row(
          children: [
            Icon(
              icon,
              color: comida != null ? verdeApp : Colors.grey,
              size: 24
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    titulo,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Colors.grey[700],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    comida != null ? comida['nombre'] : 'Generando...',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: comida != null ? FontWeight.bold : FontWeight.normal,
                      color: comida != null ? Colors.black : Colors.grey,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (comida != null) ...[
                    const SizedBox(height: 4),
                    Text(
                      '${comida['calorias']} kcal',
                      style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                    ),
                  ],
                ],
              ),
            ),
            if (comida != null)
              Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey[400]),
          ],
        ),
      ),
    );
  }

  bool _esDiaDeHoy(String dia) {
    final diasSemana = {
      1: 'Lunes',
      2: 'Martes',
      3: 'Miércoles',
      4: 'Jueves',
      5: 'Viernes',
      6: 'Sábado',
      7: 'Domingo',
    };
    
    final hoy = DateTime.now().weekday;
    return diasSemana[hoy] == dia;
  }

  void _mostrarRecetaCompleta(dynamic comida) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.9,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        builder: (_, controller) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          padding: const EdgeInsets.all(20),
          child: ListView(
            controller: controller,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                comida['nombre'],
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              Text(
                comida['contenido_completo'],
                style: const TextStyle(fontSize: 14, height: 1.6),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.calendar_month, size: 80, color: Colors.grey[400]),
          const SizedBox(height: 16),
          Text(
            'No tienes menú semanal',
            style: TextStyle(fontSize: 18, color: Colors.grey[600]),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: _generarMenuCompleto,
            icon: const Icon(Icons.auto_awesome),
            label: const Text('Generar Menú Semanal'),
            style: ElevatedButton.styleFrom(
              backgroundColor: verdeApp,
              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _generarMenuCompleto() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    setState(() => _cargando = true);

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/inicializar-menu-usuario'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'user_id': user.id, 'tipo_comida': 'desayuno'}),
      );

      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Generando tu menú semanal completo desde Lunes...'),
            backgroundColor: Colors.orange,
          ),
        );
        
        // Esperar un poco y recargar
        await Future.delayed(const Duration(seconds: 2));
        _cargarMenuSemanal();
      }
    } catch (e) {
      setState(() => _cargando = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }
}