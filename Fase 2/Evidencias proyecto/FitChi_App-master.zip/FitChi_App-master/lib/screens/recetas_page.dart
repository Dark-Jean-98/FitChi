import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'custom_bottom_nav.dart';

class RecetasPage extends StatefulWidget {
  const RecetasPage({super.key});

  @override
  State<RecetasPage> createState() => _RecetasPageState();
}

class _RecetasPageState extends State<RecetasPage> {
  final String baseUrl = "https://fitchi-backend-398799029559.southamerica-west1.run.app";
  static const Color verdeApp = Color(0xFF66BB6A);
  final supabase = Supabase.instance.client;
  
  bool _cargando = false;
  String? _recetaActual;
  String? _tipoComidaSeleccionado;

  final List<Map<String, dynamic>> tiposComida = [
    {'tipo': 'desayuno', 'nombre': 'Desayuno', 'icon': Icons.wb_sunny_outlined},
    {'tipo': 'almuerzo', 'nombre': 'Almuerzo', 'icon': Icons.restaurant},
    {'tipo': 'cena', 'nombre': 'Cena', 'icon': Icons.dinner_dining},
    {'tipo': 'snack', 'nombre': 'Snack', 'icon': Icons.cookie_outlined},
  ];

  Future<void> generarReceta(String tipoComida) async {
    setState(() {
      _cargando = true;
      _recetaActual = null;
      _tipoComidaSeleccionado = tipoComida;
    });

    try {
      final user = supabase.auth.currentUser;
      if (user == null) {
        throw Exception("Usuario no autenticado");
      }

      final response = await http.post(
        Uri.parse('$baseUrl/api/generar-receta'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'user_id': user.id,
          'tipo_comida': tipoComida,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _recetaActual = data['receta_completa'];
        });
      } else {
        throw Exception('Error al generar receta: ${response.statusCode}');
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
      );
    } finally {
      setState(() {
        _cargando = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        automaticallyImplyLeading: false,
        title: const Text("Recetas Personalizadas", style: TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.bold)),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(color: Colors.grey[900], borderRadius: BorderRadius.circular(16)),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(color: verdeApp.withOpacity(0.2), borderRadius: BorderRadius.circular(12)),
                      child: Icon(Icons.auto_awesome, color: verdeApp, size: 28),
                    ),
                    const SizedBox(width: 16),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Generadas con IA", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                          SizedBox(height: 4),
                          Text("Según tus objetivos nutricionales", style: TextStyle(color: Colors.white70, fontSize: 12)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 1.3,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                ),
                itemCount: tiposComida.length,
                itemBuilder: (context, index) {
                  final comida = tiposComida[index];
                  final isSelected = _tipoComidaSeleccionado == comida['tipo'];
                  
                  return GestureDetector(
                    onTap: _cargando ? null : () => generarReceta(comida['tipo']),
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.grey[900],
                        borderRadius: BorderRadius.circular(16),
                        border: isSelected ? Border.all(color: verdeApp, width: 2) : null,
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(comida['icon'], size: 40, color: isSelected ? verdeApp : Colors.white70),
                          const SizedBox(height: 12),
                          Text(comida['nombre'], style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: isSelected ? verdeApp : Colors.white)),
                        ],
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 24),
              if (_cargando)
                _buildLoadingCard()
              else if (_recetaActual != null)
                _buildRecetaCard()
              else
                _buildEmptyState(),
              const SizedBox(height: 80),
            ],
          ),
        ),
      ),
      bottomNavigationBar: const CustomBottomNav(currentIndex: 3),
    );
  }

  Widget _buildLoadingCard() {
    return Container(
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          SizedBox(
            width: 60,
            height: 60,
            child: CircularProgressIndicator(
              strokeWidth: 5,
              valueColor: AlwaysStoppedAnimation<Color>(verdeApp),
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            "Creando tu receta personalizada...",
            style: TextStyle(
              fontSize: 16,
              color: Colors.white,
              fontWeight: FontWeight.w500,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          const Text(
            "Esto puede tomar unos segundos",
            style: TextStyle(
              fontSize: 13,
              color: Colors.white70,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildRecetaCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.restaurant_menu, color: verdeApp, size: 24),
                  const SizedBox(width: 12),
                  const Text(
                    "Tu receta personalizada",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
              IconButton(
                icon: const Icon(Icons.refresh_rounded),
                onPressed: _cargando 
                    ? null 
                    : () => generarReceta(_tipoComidaSeleccionado!),
                color: verdeApp,
                iconSize: 26,
              ),
            ],
          ),
          
          const Divider(height: 32, color: Colors.white24),
          
          // Contenido de la receta
          _buildFormattedReceta(_recetaActual!),
        ],
      ),
    );
  }

  Widget _buildFormattedReceta(String receta) {
    final sections = receta.split('\n\n');
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: sections.map((section) {
        if (section.toUpperCase().startsWith('NOMBRE:')) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Text(
              section.replaceFirst(RegExp(r'NOMBRE:\s*', caseSensitive: false), ''),
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: verdeApp,
              ),
            ),
          );
        } else if (section.toUpperCase().startsWith('INGREDIENTES:')) {
          return _buildSection(
            'Ingredientes',
            section.replaceFirst(RegExp(r'INGREDIENTES:\s*', caseSensitive: false), ''),
            Icons.shopping_basket_outlined,
          );
        } else if (section.toUpperCase().startsWith('PREPARACIÓN:')) {
          return _buildSection(
            'Preparación',
            section.replaceFirst(RegExp(r'PREPARACIÓN:\s*', caseSensitive: false), ''),
            Icons.menu_book_outlined,
          );
        } else if (section.toUpperCase().startsWith('INFORMACIÓN NUTRICIONAL:')) {
          return _buildHighlightedSection(
            'Información Nutricional',
            section.replaceFirst(RegExp(r'INFORMACIÓN NUTRICIONAL:\s*', caseSensitive: false), ''),
            Icons.bar_chart_outlined,
          );
        } else if (section.toUpperCase().startsWith('TIEMPO DE PREPARACIÓN:')) {
          return _buildSection(
            'Tiempo de preparación',
            section.replaceFirst(RegExp(r'TIEMPO DE PREPARACIÓN:\s*', caseSensitive: false), ''),
            Icons.timer_outlined,
          );
        } else if (section.toUpperCase().startsWith('CONSEJOS:')) {
          return _buildSection(
            'Consejos',
            section.replaceFirst(RegExp(r'CONSEJOS:\s*', caseSensitive: false), ''),
            Icons.lightbulb_outline,
          );
        }
        return const SizedBox.shrink();
      }).toList(),
    );
  }

  Widget _buildSection(String titulo, String contenido, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: verdeApp, size: 18),
              const SizedBox(width: 8),
              Text(
                titulo,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            contenido.trim(),
            style: const TextStyle(
              fontSize: 13,
              height: 1.5,
              color: Colors.white70,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHighlightedSection(String titulo, String contenido, IconData icon) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: verdeApp.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: verdeApp.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: verdeApp, size: 18),
              const SizedBox(width: 8),
              Text(
                titulo,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: verdeApp,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            contenido.trim(),
            style: const TextStyle(
              fontSize: 13,
              height: 1.5,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Container(
      padding: const EdgeInsets.all(48),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          Icon(
            Icons.restaurant_menu,
            size: 64,
            color: Colors.white38,
          ),
          const SizedBox(height: 24),
          const Text(
            "Selecciona un tipo de comida",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            "Generaremos una receta personalizada\nsegún tus objetivos nutricionales",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 13,
              color: Colors.white70,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}