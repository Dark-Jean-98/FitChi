import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'onboarding_datos_salud.dart';

class OnboardingPerfilPage extends StatefulWidget {
  const OnboardingPerfilPage({super.key});

  @override
  State<OnboardingPerfilPage> createState() => _OnboardingPerfilPageState();
}

class _OnboardingPerfilPageState extends State<OnboardingPerfilPage> {
  final TextEditingController _nombreController = TextEditingController();
  final supabase = Supabase.instance.client;
  DateTime? selectedDate;
  String? selectedSexo;
  bool _loading = false;

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime(2000),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(primary: Color(0xFF66BB6A)),
          ),
          child: child!,
        );
      },
    );
    if (picked != null && picked != selectedDate) {
      setState(() => selectedDate = picked);
    }
  }

  Future<void> _continuar() async {
    if (_nombreController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Por favor ingresa tu nombre")),
      );
      return;
    }

    if (selectedSexo == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Por favor selecciona tu sexo")),
      );
      return;
    }

    if (selectedDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Por favor selecciona tu fecha de nacimiento")),
      );
      return;
    }

    setState(() => _loading = true);

    try {
      final user = supabase.auth.currentUser;
      if (user != null) {
        await supabase.from('usuarios').update({
          'nombre': _nombreController.text.trim(),
          'sexo': selectedSexo,
          'fecha_nacimiento': selectedDate!.toIso8601String().split('T')[0], // Solo fecha
        }).eq('id', user.id);

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const OnboardingDatosSaludPage()),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/onboarding_bg1.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Container(
          decoration: BoxDecoration(color: Colors.black.withOpacity(0.4)),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      Expanded(child: Container(height: 4, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(2)))),
                      const SizedBox(width: 4),
                      Expanded(child: Container(height: 4, decoration: BoxDecoration(color: Colors.white.withOpacity(0.3), borderRadius: BorderRadius.circular(2)))),
                      const SizedBox(width: 4),
                      Expanded(child: Container(height: 4, decoration: BoxDecoration(color: Colors.white.withOpacity(0.3), borderRadius: BorderRadius.circular(2)))),
                    ],
                  ),
                  const SizedBox(height: 40),
                  const Text("Registra tu perfil", style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 10),
                  const Text("Paso 1 de 3", style: TextStyle(color: Colors.white70, fontSize: 16)),
                  const SizedBox(height: 40),
                  const Text("Nombre y Apellido", style: TextStyle(color: Colors.white, fontSize: 16)),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _nombreController,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.2),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
                      hintText: "Ingresa tu nombre completo",
                      hintStyle: TextStyle(color: Colors.white.withOpacity(0.5)),
                    ),
                  ),
                  const SizedBox(height: 30),
                  const Text("Selección de Sexo", style: TextStyle(color: Colors.white, fontSize: 16)),
                  const SizedBox(height: 10),
                  Row(
                    children: ["Masculino", "Femenino", "Otro"].map((sexo) {
                      final isSelected = selectedSexo == sexo;
                      return Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4),
                          child: ElevatedButton(
                            onPressed: () => setState(() => selectedSexo = sexo),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: isSelected ? Colors.white : Colors.white.withOpacity(0.2),
                              foregroundColor: isSelected ? const Color(0xFF66BB6A) : Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                            ),
                            child: Text(sexo),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 30),
                  const Text("Fecha de nacimiento", style: TextStyle(color: Colors.white, fontSize: 16)),
                  const SizedBox(height: 10),
                  InkWell(
                    onTap: () => _selectDate(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            selectedDate == null ? "mm/dd/yyyy" : "${selectedDate!.day.toString().padLeft(2, '0')}/${selectedDate!.month.toString().padLeft(2, '0')}/${selectedDate!.year}",
                            style: TextStyle(color: selectedDate == null ? Colors.white.withOpacity(0.5) : Colors.white, fontSize: 16),
                          ),
                          const Icon(Icons.calendar_today, color: Colors.white70),
                        ],
                      ),
                    ),
                  ),
                  const Spacer(),
                  _loading
                      ? const Center(child: CircularProgressIndicator(color: Colors.white))
                      : ElevatedButton(
                          onPressed: _continuar,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF66BB6A),
                            foregroundColor: Colors.black,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                            elevation: 8,
                          ),
                          child: const Text("Siguiente", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}