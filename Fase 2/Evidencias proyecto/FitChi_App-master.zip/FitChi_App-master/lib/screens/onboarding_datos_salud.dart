import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'onboarding_medidas.dart';

class OnboardingDatosSaludPage extends StatefulWidget {
  const OnboardingDatosSaludPage({super.key});

  @override
  State<OnboardingDatosSaludPage> createState() => _OnboardingDatosSaludPageState();
}

class _OnboardingDatosSaludPageState extends State<OnboardingDatosSaludPage> {
  final TextEditingController _alergiasController = TextEditingController();
  final TextEditingController _patologiaController = TextEditingController();
  final supabase = Supabase.instance.client;
  bool _loading = false;

  Future<void> _continuar() async {
    setState(() => _loading = true);

    try {
      final user = supabase.auth.currentUser;
      if (user != null) {
        await supabase.from('usuarios').update({
          'alergias': _alergiasController.text.trim(),
          'patologia': _patologiaController.text.trim(),
        }).eq('id', user.id);

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const OnboardingMedidasPage()),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _omitir() async {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const OnboardingMedidasPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/onboarding_bg2.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Container(
          decoration: BoxDecoration(color: Colors.black.withOpacity(0.4)),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      Expanded(child: Container(height: 4, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(2)))),
                      const SizedBox(width: 4),
                      Expanded(child: Container(height: 4, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(2)))),
                      const SizedBox(width: 4),
                      Expanded(child: Container(height: 4, decoration: BoxDecoration(color: Colors.white.withOpacity(0.3), borderRadius: BorderRadius.circular(2)))),
                    ],
                  ),
                  const SizedBox(height: 40),
                  Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back, color: Colors.white),
                        onPressed: () => Navigator.pop(context),
                      ),
                      const Expanded(child: Text("Datos de salud", style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold))),
                    ],
                  ),
                  const SizedBox(height: 10),
                  const Text("Paso 2 de 3 (Opcional)", style: TextStyle(color: Colors.white70, fontSize: 16)),
                  const SizedBox(height: 40),
                  const Text("Alergias", style: TextStyle(color: Colors.white, fontSize: 16)),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _alergiasController,
                    style: const TextStyle(color: Colors.white),
                    maxLines: 3,
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.2),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
                      hintText: "Ej: Lácteos, nueces, etc.",
                      hintStyle: TextStyle(color: Colors.white.withOpacity(0.5)),
                    ),
                  ),
                  const SizedBox(height: 30),
                  const Text("Patología", style: TextStyle(color: Colors.white, fontSize: 16)),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _patologiaController,
                    style: const TextStyle(color: Colors.white),
                    maxLines: 3,
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.2),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
                      hintText: "Ej: Diabetes, hipertensión, etc.",
                      hintStyle: TextStyle(color: Colors.white.withOpacity(0.5)),
                    ),
                  ),
                  const Spacer(),
                  _loading
                      ? const Center(child: CircularProgressIndicator(color: Colors.white))
                      : Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            ElevatedButton(
                              onPressed: _continuar,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF66BB6A),
                                foregroundColor: Colors.black,
                                padding: const EdgeInsets.symmetric(vertical: 16),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                                elevation: 8,
                              ),
                              child: const Text("Siguiente", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                            ),
                            const SizedBox(height: 12),
                            TextButton(
                              onPressed: _omitir,
                              style: TextButton.styleFrom(
                                backgroundColor: Colors.white.withOpacity(0.2),
                                padding: const EdgeInsets.symmetric(vertical: 12),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                              ),
                              child: const Text("Omitir", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                            ),
                          ],
                        ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}