import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:fl_chart/fl_chart.dart';
import 'custom_bottom_nav.dart';

class MetaFisicaPage extends StatefulWidget {
  const MetaFisicaPage({super.key});

  @override
  State<MetaFisicaPage> createState() => _MetaFisicaPageState();
}

class _MetaFisicaPageState extends State<MetaFisicaPage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final supabase = Supabase.instance.client;
  String? _actividadSeleccionada;
  String? _objetivoSeleccionado;
  int _numeroComidas = 3;
  
  static const Color verdeApp = Color(0xFF66BB6A);

  final Map<String, double> _factoresActividad = {
    "Sedentario (mínimo ejercicio)": 1.2,
    "Ligera (1-3 días/sem de ejercicio)": 1.375,
    "Moderada (3-5 días/sem)": 1.55,
    "Intensa (6-7 días/sem)": 1.725,
    "Muy intensa (entrenamiento diario)": 1.9,
  };

  final Map<String, double> _ajustesObjetivo = {
    "Déficit calórico (pérdida de grasa)": -500,
    "Recomposición corporal": -300,
    "Mantenimiento": 0,
    "Superávit (ganancia muscular)": 400,
  };

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<Map<String, dynamic>?> _getUserData() async {
    final user = supabase.auth.currentUser;
    if (user == null) return null;

    try {
      final data = await supabase
          .from('usuarios')
          .select()
          .eq('id', user.id)
          .single();
      return data;
    } catch (e) {
      return null;
    }
  }

  int _calcularEdad(String fechaNacStr) {
    try {
      final fechaNac = DateTime.parse(fechaNacStr);
      final hoy = DateTime.now();
      int edad = hoy.year - fechaNac.year;
      if (hoy.month < fechaNac.month || (hoy.month == fechaNac.month && hoy.day < fechaNac.day)) {
        edad--;
      }
      return edad;
    } catch (e) {
      return 0;
    }
  }

  double _calcularTMB(double peso, double altura, int edad, String sexo) {
    if (sexo.toLowerCase() == "hombre" || sexo.toLowerCase() == "masculino") {
      return 66 + (13.7 * peso) + (5 * altura) - (6.8 * edad);
    } else {
      return 655 + (9.6 * peso) + (1.8 * altura) - (4.7 * edad);
    }
  }

  Future<void> _recalcularCalorias() async {
    if (_actividadSeleccionada == null || _objetivoSeleccionado == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Selecciona nivel de actividad y objetivo")),
      );
      return;
    }

    final user = supabase.auth.currentUser;
    if (user == null) return;

    final userData = await _getUserData();
    if (userData == null) return;

    final peso = double.tryParse(userData['peso'].toString()) ?? 0;
    final altura = double.tryParse(userData['altura'].toString()) ?? 0;
    final edad = _calcularEdad(userData['fecha_nacimiento'] ?? '');
    final sexo = userData['sexo'] ?? 'Masculino';

    final tmb = _calcularTMB(peso, altura, edad, sexo);
    final factor = _factoresActividad[_actividadSeleccionada]!;
    final get = tmb * factor;
    final ajuste = _ajustesObjetivo[_objetivoSeleccionado]!;
    final caloriasObjetivo = get + ajuste;

    final distribucionesMacros = {
      "Déficit calórico (pérdida de grasa)": {"proteinas": 27.5, "grasas": 27.5, "carbohidratos": 45.0},
      "Superávit (ganancia muscular)": {"proteinas": 22.5, "grasas": 22.5, "carbohidratos": 52.5},
      "Mantenimiento": {"proteinas": 22.5, "grasas": 27.5, "carbohidratos": 50.0},
      "Recomposición corporal": {"proteinas": 27.5, "grasas": 27.5, "carbohidratos": 45.0},
    };

    final distribucion = distribucionesMacros[_objetivoSeleccionado] ?? distribucionesMacros["Mantenimiento"]!;
    
    final caloriasProteinas = (caloriasObjetivo * distribucion["proteinas"]!) / 100;
    final caloriasGrasas = (caloriasObjetivo * distribucion["grasas"]!) / 100;
    final caloriasCarbo = (caloriasObjetivo * distribucion["carbohidratos"]!) / 100;

    final proteinas = caloriasProteinas / 4;
    final grasas = caloriasGrasas / 9;
    final carbos = caloriasCarbo / 4;

    final porcionesCarbo = carbos / 15;
    final porcionesProteina = proteinas / 7;
    final porcionesGrasa = grasas / 5;

    await supabase.from('usuarios').update({
      'nivel_actividad': _actividadSeleccionada,
      'factor_actividad': factor,
      'objetivo_nutricional': _objetivoSeleccionado,
      'tmb': tmb.round(),
      'get_calorico': get.round(),
      'calorias_objetivo': caloriasObjetivo.round(),
      'proteinas_gramos': proteinas.round(),
      'carbohidratos_gramos': carbos.round(),
      'grasas_gramos': grasas.round(),
      'porciones_carbo': porcionesCarbo.round(),
      'porciones_proteina': porcionesProteina.round(),
      'porciones_grasa': porcionesGrasa.round(),
    }).eq('id', user.id);

    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Plan recalculado exitosamente"), backgroundColor: verdeApp),
    );
  }

  Future<void> _guardarNumeroComidas() async {
    final user = supabase.auth.currentUser;
    if (user != null) {
      await supabase.from('usuarios').update({
        'numero_comidas': _numeroComidas,
      }).eq('id', user.id);
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Número de comidas actualizado"), backgroundColor: verdeApp),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        automaticallyImplyLeading: false,
        title: const Text("Mi plan nutricional", style: TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.bold)),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: verdeApp,
          labelColor: verdeApp,
          unselectedLabelColor: Colors.grey,
          labelStyle: const TextStyle(fontWeight: FontWeight.bold),
          tabs: const [
            Tab(text: "Resumen"),
            Tab(text: "Calorías"),
            Tab(text: "Macros"),
            Tab(text: "Comidas"),
          ],
        ),
      ),
      body: FutureBuilder<Map<String, dynamic>?>(
        future: _getUserData(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final userData = snapshot.data ?? {};
          final caloriasObjetivo = userData['calorias_objetivo'] ?? 0;
          final objetivo = userData['objetivo_nutricional'] ?? 'Mantenimiento';
          final actividad = userData['nivel_actividad'] ?? 'No definido';
          final tmb = userData['tmb'] ?? 0;
          final get = userData['get_calorico'] ?? 0;
          final proteinas = userData['proteinas_gramos'] ?? 0;
          final carbos = userData['carbohidratos_gramos'] ?? 0;
          final grasas = userData['grasas_gramos'] ?? 0;
          final porcionesCarbo = userData['porciones_carbo'] ?? 0;
          final porcionesProteina = userData['porciones_proteina'] ?? 0;
          final porcionesGrasa = userData['porciones_grasa'] ?? 0;

          _actividadSeleccionada ??= actividad;
          _objetivoSeleccionado ??= objetivo;
          _numeroComidas = userData['numero_comidas'] ?? 3;

          final caloriasPorComida = _numeroComidas > 0 ? caloriasObjetivo / _numeroComidas : 0;

          return TabBarView(
            controller: _tabController,
            children: [
              _buildResumenTab(caloriasObjetivo, objetivo, actividad, proteinas, carbos, grasas, caloriasPorComida),
              _buildCaloriasTab(tmb, get, caloriasObjetivo, objetivo, actividad),
              _buildMacrosTab(proteinas, carbos, grasas),
              _buildComidasTab(porcionesCarbo, porcionesProteina, porcionesGrasa),
            ],
          );
        },
      ),
      bottomNavigationBar: const CustomBottomNav(currentIndex: 1),
    );
  }

  Widget _buildResumenTab(int calorias, String objetivo, String actividad, int proteinas, int carbos, int grasas, double caloriasPorComida) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildBlackCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Tu objetivo", style: TextStyle(color: Colors.white, fontSize: 14)),
                Text(objetivo, style: const TextStyle(color: Colors.white70, fontSize: 12)),
                const SizedBox(height: 8),
                Text(
                  "$calorias kcal/día",
                  style: const TextStyle(color: verdeApp, fontSize: 48, fontWeight: FontWeight.bold),
                ),
                Text("Nivel de actividad: $actividad", style: const TextStyle(color: Colors.white70, fontSize: 12)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _buildBlackCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Macronutrientes diarios", style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildMacroCircleGreen("${proteinas}g", "Proteínas"),
                    _buildMacroCircleGreen("${carbos}g", "Carbohidratos"),
                    _buildMacroCircleGreen("${grasas}g", "Grasas"),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _buildBlackCard(
            child: Column(
              children: [
                const Text("Distribución de comidas", style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                _buildWhiteInfoRow("Comidas al día:", "$_numeroComidas"),
                _buildWhiteInfoRow("Calorías por comida:", "~${caloriasPorComida.round()} kcal"),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCaloriasTab(int tmb, int get, int calorias, String objetivo, String actividad) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildBlackCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Cálculo de calorías", style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                _buildGreenInfoRow("TMB (Tasa Metabólica Basal):", "$tmb kcal"),
                _buildGreenInfoRow("Factor de actividad:", "${(_factoresActividad[actividad] ?? 1.0).toStringAsFixed(2)}x"),
                _buildGreenInfoRow("GET (Gasto Energético Total):", "$get kcal"),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _buildBlackCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Tu objetivo", style: TextStyle(color: Colors.white, fontSize: 14)),
                Text(objetivo, style: const TextStyle(color: Colors.white70, fontSize: 12)),
                const SizedBox(height: 8),
                Text("$calorias kcal/día", style: const TextStyle(color: verdeApp, fontSize: 48, fontWeight: FontWeight.bold)),
                Text("(${_ajustesObjetivo[objetivo]! >= 0 ? '+' : ''}${_ajustesObjetivo[objetivo]?.round() ?? 0} kcal del GET)", style: const TextStyle(color: Colors.white70, fontSize: 12)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _buildBlackCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Nivel de actividad", style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text("Actual: $actividad", style: const TextStyle(color: Colors.white70, fontSize: 12)),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF3e3e3e),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: DropdownButton<String>(
                    value: _actividadSeleccionada,
                    isExpanded: true,
                    hint: const Text("Selecciona nivel de actividad", style: TextStyle(color: Colors.white70, fontSize: 12)),
                    dropdownColor: Colors.grey[900],
                    style: const TextStyle(color: Colors.white),
                    underline: Container(),
                    items: _factoresActividad.keys.map((item) {
                      return DropdownMenuItem(
                        value: item,
                        child: Text(item, style: const TextStyle(fontSize: 12)),
                      );
                    }).toList(),
                    onChanged: (value) => setState(() => _actividadSeleccionada = value),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _buildBlackCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Objetivo nutricional", style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text("Actual: $objetivo", style: const TextStyle(color: Colors.white70, fontSize: 12)),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF3e3e3e),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: DropdownButton<String>(
                    value: _objetivoSeleccionado,
                    isExpanded: true,
                    hint: const Text("Selecciona objetivo", style: TextStyle(color: Colors.white70, fontSize: 12)),
                    dropdownColor: Colors.grey[900],
                    style: const TextStyle(color: Colors.white),
                    underline: Container(),
                    items: _ajustesObjetivo.keys.map((item) {
                      return DropdownMenuItem(
                        value: item,
                        child: Text(item, style: const TextStyle(fontSize: 12)),
                      );
                    }).toList(),
                    onChanged: (value) => setState(() => _objetivoSeleccionado = value),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          _buildGreenButton("Recalcular todo el plan", _recalcularCalorias),
        ],
      ),
    );
  }

  Widget _buildMacrosTab(int proteinas, int carbos, int grasas) {
    final total = proteinas * 4 + carbos * 4 + grasas * 9;
    final pPct = total > 0 ? ((proteinas * 4 / total) * 100).round() : 0;
    final cPct = total > 0 ? ((carbos * 4 / total) * 100).round() : 0;
    final gPct = total > 0 ? ((grasas * 9 / total) * 100).round() : 0;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildBlackCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Aporte energético", style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                _buildGreenInfoRow("Proteínas:", "4 kcal/g"),
                _buildGreenInfoRow("Carbohidratos:", "4 kcal/g"),
                _buildGreenInfoRow("Grasas:", "9 kcal/g"),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _buildBlackCard(
            child: Column(
              children: [
                const Text("Distribución de macronutrientes", style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),
                SizedBox(
                  height: 150,
                  child: PieChart(
                    PieChartData(
                      sectionsSpace: 2,
                      centerSpaceRadius: 40,
                      sections: [
                        PieChartSectionData(
                          value: pPct.toDouble(),
                          title: 'P: $pPct%',
                          color: Colors.red,
                          radius: 45,
                          titleStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                        PieChartSectionData(
                          value: cPct.toDouble(),
                          title: 'C: $cPct%',
                          color: Colors.blue,
                          radius: 45,
                          titleStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                        PieChartSectionData(
                          value: gPct.toDouble(),
                          title: 'G: $gPct%',
                          color: Colors.orange,
                          radius: 45,
                          titleStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _buildBlackCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Macros en gramos", style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),
                _buildProgressRow("Proteínas", proteinas, Colors.red),
                const SizedBox(height: 16),
                _buildProgressRow("Carbohidratos", carbos, Colors.blue),
                const SizedBox(height: 16),
                _buildProgressRow("Grasas", grasas, Colors.orange),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildComidasTab(int porcionesCarbo, int porcionesProteina, int porcionesGrasa) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildBlackCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Conversión a porciones", style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text("1 porción de proteínas: 7 g", style: TextStyle(color: Colors.white70, fontSize: 12)),
                const Text("1 porción de carbohidratos: 15 g", style: TextStyle(color: Colors.white70, fontSize: 12)),
                const Text("1 porción de grasas: 5 g", style: TextStyle(color: Colors.white70, fontSize: 12)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _buildBlackCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Total de porciones diarias", style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                _buildGreenPorcionRow("Proteínas", porcionesProteina),
                const SizedBox(height: 8),
                _buildGreenPorcionRow("Carbohidratos", porcionesCarbo),
                const SizedBox(height: 8),
                _buildGreenPorcionRow("Grasas", porcionesGrasa),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _buildBlackCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Distribución de comidas:", style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text("Número de comidas al día:", style: TextStyle(color: Colors.white70, fontSize: 12)),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFF3e3e3e),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: DropdownButton<int>(
                        value: _numeroComidas,
                        dropdownColor: Colors.grey[900],
                        style: const TextStyle(color: Colors.white),
                        underline: Container(),
                        items: [3, 4, 5, 6].map((num) {
                          return DropdownMenuItem(
                            value: num,
                            child: Text("$num comidas", style: const TextStyle(fontSize: 12)),
                          );
                        }).toList(),
                        onChanged: (value) {
                          setState(() {
                            _numeroComidas = value!;
                          });
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Text("Por comida ($_numeroComidas comidas/día):", style: const TextStyle(color: Colors.white70, fontSize: 12)),
                const SizedBox(height: 8),
                _buildWhiteInfoRow("Proteínas:", "${(porcionesProteina / _numeroComidas).toStringAsFixed(1)} porciones"),
                _buildWhiteInfoRow("Carbohidratos:", "${(porcionesCarbo / _numeroComidas).toStringAsFixed(1)} porciones"),
                _buildWhiteInfoRow("Grasas:", "${(porcionesGrasa / _numeroComidas).toStringAsFixed(1)} porciones"),
              ],
            ),
          ),
          const SizedBox(height: 24),
          _buildGreenButton("Guardar número de comidas", _guardarNumeroComidas),
        ],
      ),
    );
  }

  Widget _buildBlackCard({required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.grey[900], // Mismo negro que home
        borderRadius: BorderRadius.circular(16),
      ),
      child: child,
    );
  }

  Widget _buildMacroCircleGreen(String value, String label) {
    return Column(
      children: [
        Container(
          width: 70,
          height: 70,
          decoration: const BoxDecoration(
            color: verdeApp,
            shape: BoxShape.circle,
          ),
          alignment: Alignment.center,
          child: Text(value, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
        ),
        const SizedBox(height: 8),
        Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11)),
      ],
    );
  }

  Widget _buildWhiteInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12)),
          Text(value, style: const TextStyle(color: Colors.white, fontSize: 14)),
        ],
      ),
    );
  }

  Widget _buildGreenInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Colors.white, fontSize: 12)),
          Text(value, style: const TextStyle(color: verdeApp, fontSize: 14, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildProgressRow(String name, int grams, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(name, style: const TextStyle(color: Colors.white70, fontSize: 12)),
        const SizedBox(height: 4),
        Text("$grams g/día", style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: 0.5,
            backgroundColor: Colors.grey[800],
            valueColor: AlwaysStoppedAnimation(color),
            minHeight: 6,
          ),
        ),
      ],
    );
  }

  Widget _buildGreenPorcionRow(String name, int porciones) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: verdeApp,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(name, style: const TextStyle(color: Colors.black, fontSize: 14, fontWeight: FontWeight.bold)),
          Text("$porciones porciones", style: const TextStyle(color: Colors.black, fontSize: 14, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildGreenButton(String text, VoidCallback onPressed) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: verdeApp,
          foregroundColor: Colors.black,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
        ),
        child: Text(text, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
      ),
    );
  }
}