import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'login.dart';
import 'custom_bottom_nav.dart';
import 'edit_profile.dart';
import 'calendario_seguimiento_page.dart';
import 'chat_page.dart';

class HomeScreen extends StatefulWidget {
  final String? userName;
  const HomeScreen({super.key, this.userName});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static const Color verdeApp = Color(0xFF66BB6A);
  final supabase = Supabase.instance.client;
  final String baseUrl = 'https://fitchi-backend-398799029559.southamerica-west1.run.app';

  Map<String, dynamic>? _datosCompletos;
  bool _cargando = true;
  int _vasosAgua = 0;
  static const int _metaVasos = 8; // Meta diaria: 8 vasos = 2 litros
  static const int _mlPorVaso = 250; // Mililitros por vaso

  Map<String, dynamic>? _proximoControl;
  List<Map<String, dynamic>> _historiaPeso = [];
  int _diasRacha = 0;

  @override
  void initState() {
    super.initState();
    _cargarDatos();
    _cargarProgresoAgua();
    _cargarProximoControl();
    _cargarHistorialPeso();
    _cargarRacha();
  }

  Future<void> _cargarDatos() async {
    setState(() => _cargando = true);
    final datos = await _getDatosCompletos();
    if (mounted) {
      setState(() {
        _datosCompletos = datos;
        _cargando = false;
      });
    }
  }

  Future<Map<String, dynamic>?> _getUserData() async {
    final user = supabase.auth.currentUser;
    if (user == null) return null;

    try {
      final data = await supabase
          .from('usuarios')
          .select()
          .eq('id', user.id)
          .single();
      return data;
    } catch (e) {
      return null;
    }
  }

  Future<Map<String, dynamic>?> _getResumenDia() async {
    final user = supabase.auth.currentUser;
    if (user == null) return null;

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/resumen-dia/${user.id}'),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      }
      return null;
    } catch (e) {
      print('Error obteniendo resumen del día: $e');
      return null;
    }
  }

  Future<Map<String, dynamic>> _getDatosCompletos() async {
    final userData = await _getUserData();
    final resumenDia = await _getResumenDia();

    return {
      'usuario': userData ?? {},
      'resumen': resumenDia ?? {},
    };
  }

  Future<void> _cargarProgresoAgua() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final hoy = DateTime.now().toIso8601String().split('T')[0];

      final data = await supabase
          .from('registro_agua')
          .select('cantidad_ml')
          .eq('usuario_id', user.id)
          .eq('fecha', hoy);

      int totalMl = 0;
      for (var registro in data) {
        totalMl += (registro['cantidad_ml'] as int?) ?? 0;
      }

      final vasosCompletos = (totalMl / _mlPorVaso).floor();

      if (mounted) {
        setState(() {
          _vasosAgua = vasosCompletos;
        });
      }
    } catch (e) {
      // Silently fail
    }
  }

  Future<void> _cargarProximoControl() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/calendario-seguimiento/${user.id}'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (mounted && data['plan_activo'] == true) {
          setState(() {
            _proximoControl = data['proximo_control'];
          });
        }
      }
    } catch (e) {
      // Silently fail
    }
  }

  Future<void> _cargarHistorialPeso() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final data = await supabase
          .from('historial_mediciones')
          .select('peso, fecha_registro')
          .eq('usuario_id', user.id)
          .order('fecha_registro', ascending: true)
          .limit(7);

      if (mounted) {
        setState(() {
          _historiaPeso = List<Map<String, dynamic>>.from(data);
        });
      }
    } catch (e) {
      // Silently fail
    }
  }

  Future<void> _cargarRacha() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      // Obtener los últimos 30 días de registros
      final hoy = DateTime.now();
      final hace30Dias = hoy.subtract(const Duration(days: 30));

      final registros = await supabase
          .from('registro_comidas')
          .select('fecha_consumo')
          .eq('usuario_id', user.id)
          .gte('fecha_consumo', hace30Dias.toIso8601String().split('T')[0])
          .order('fecha_consumo', ascending: false);

      // Calcular racha de días consecutivos
      int racha = 0;
      DateTime fechaActual = DateTime.now();

      final Set<String> diasConRegistro = registros
          .map((r) => r['fecha_consumo'].toString())
          .toSet();

      for (int i = 0; i < 30; i++) {
        final fechaStr = fechaActual.toIso8601String().split('T')[0];
        if (diasConRegistro.contains(fechaStr)) {
          racha++;
          fechaActual = fechaActual.subtract(const Duration(days: 1));
        } else {
          break;
        }
      }

      if (mounted) {
        setState(() {
          _diasRacha = racha;
        });
      }
    } catch (e) {
      // Silently fail
    }
  }

  Future<void> _marcarVasoAgua(int indiceVaso) async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final hoy = DateTime.now().toIso8601String().split('T')[0];
      final nuevoValor = indiceVaso < _vasosAgua ? indiceVaso : indiceVaso + 1;

      await supabase.from('registro_agua').insert({
        'usuario_id': user.id,
        'cantidad_ml': _mlPorVaso,
        'fecha': hoy,
        'created_at': DateTime.now().toIso8601String(),
      });

      if (mounted) {
        setState(() {
          _vasosAgua = nuevoValor;
        });

        if (nuevoValor == _metaVasos) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('¡Felicidades! Cumpliste tu meta de agua del día 💧'),
              backgroundColor: verdeApp,
              duration: Duration(seconds: 2),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Error al guardar el registro de agua'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_cargando) {
      return Scaffold(
        backgroundColor: Colors.grey[100],
        body: const Center(child: CircularProgressIndicator(color: verdeApp)),
      );
    }

    final data = _datosCompletos ?? {'usuario': {}, 'resumen': {}};
    final userData = data['usuario'] as Map<String, dynamic>;
    final resumenDia = data['resumen'] as Map<String, dynamic>;

    // Obtener el nombre del usuario desde los datos cargados o usar el parámetro como fallback
    final nombreUsuario = userData['nombre']?.toString() ?? widget.userName ?? 'Usuario';
    final avatarUrl = userData['avatar_url']?.toString();

    final caloriasObjetivo = resumenDia['calorias_objetivo'] ?? userData['calorias_objetivo'] ?? 2000;
    final objetivoNutricional = userData['objetivo_nutricional'] ?? 'Mantenimiento';
    final peso = userData['peso']?.toString() ?? '0';

    final caloriasConsumidas = resumenDia['calorias_consumidas'] ?? 0;
    final caloriasRestantes = resumenDia['calorias_restantes'] ?? caloriasObjetivo;
    final progreso = caloriasObjetivo > 0 ? (caloriasConsumidas / caloriasObjetivo).clamp(0.0, 1.0) : 0.0;

    final ultimaComida = resumenDia['ultima_comida'] as Map<String, dynamic>?;

    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: RefreshIndicator(
        color: verdeApp,
        onRefresh: _cargarDatos,
        child: SafeArea(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => const EditProfilePage()),
                            );
                          },
                          child: CircleAvatar(
                            radius: 25,
                            backgroundColor: verdeApp,
                            backgroundImage: avatarUrl != null && avatarUrl.isNotEmpty
                                ? NetworkImage(avatarUrl)
                                : null,
                            child: avatarUrl == null || avatarUrl.isEmpty
                                ? Text(
                                    nombreUsuario.isNotEmpty ? nombreUsuario[0].toUpperCase() : 'U',
                                    style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
                                  )
                                : null,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text("Hola,", style: TextStyle(fontSize: 14, color: Colors.grey)),
                            Text(nombreUsuario, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                          ],
                        ),
                        const Spacer(),
                        IconButton(
                          icon: const Icon(Icons.logout),
                          onPressed: () async {
                            await supabase.auth.signOut();
                            if (context.mounted) {
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(builder: (_) => const LoginScreen()),
                              );
                            }
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(color: Colors.grey[900], borderRadius: BorderRadius.circular(20)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text("Total calórico diario:", style: TextStyle(color: Colors.white70, fontSize: 14)),
                          const SizedBox(height: 8),
                          Text("$caloriasObjetivo kcal/día", style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 4),
                          Text(objetivoNutricional, style: const TextStyle(color: verdeApp, fontSize: 14)),
                          const SizedBox(height: 16),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: LinearProgressIndicator(
                              value: progreso,
                              backgroundColor: Colors.grey[800],
                              valueColor: const AlwaysStoppedAnimation<Color>(verdeApp),
                              minHeight: 10,
                            ),
                          ),
                          const SizedBox(height: 12),
                          // Iconos de comidas del día
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Icon(Icons.free_breakfast, color: Colors.grey[400], size: 28),
                              Icon(Icons.restaurant, color: Colors.grey[400], size: 28),
                              Icon(Icons.dinner_dining, color: Colors.grey[400], size: 28),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),
                    // Título "Calorías restantes del día"
                    Text(
                      "Calorías restantes del día: $caloriasRestantes kcal",
                      style: const TextStyle(
                        color: Colors.black87,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 12),
                    // Título de agua
                    Text(
                      "Consumo de agua: $_vasosAgua/$_metaVasos vasos (${(_vasosAgua * _mlPorVaso) / 1000}L / ${(_metaVasos * _mlPorVaso) / 1000}L)",
                      style: const TextStyle(
                        color: Colors.black87,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 8),
                    // Vasos de agua
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: List.generate(_metaVasos, (index) {
                        final bool lleno = index < _vasosAgua;
                        return GestureDetector(
                          onTap: () => _marcarVasoAgua(index),
                          child: Container(
                            padding: const EdgeInsets.all(4),
                            child: Icon(
                              lleno ? Icons.local_drink : Icons.local_drink_outlined,
                              color: lleno ? Colors.blue : Colors.grey[400],
                              size: 36,
                            ),
                          ),
                        );
                      }),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(color: Colors.grey[900], borderRadius: BorderRadius.circular(16)),
                      child: Row(
                        children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: Colors.grey[800],
                              borderRadius: BorderRadius.circular(12),
                              image: ultimaComida != null && ultimaComida['imagen_url'] != null
                                  ? DecorationImage(
                                      image: NetworkImage(ultimaComida['imagen_url']),
                                      fit: BoxFit.cover,
                                    )
                                  : null,
                            ),
                            child: ultimaComida == null || ultimaComida['imagen_url'] == null
                                ? const Icon(Icons.restaurant, color: verdeApp, size: 40)
                                : null,
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text("Última comida:", style: TextStyle(color: Colors.white70, fontSize: 14)),
                                const SizedBox(height: 4),
                                Text(
                                  ultimaComida != null ? ultimaComida['nombre'] ?? 'Sin registro' : 'Sin registro',
                                  style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  ultimaComida != null ? '${ultimaComida['calorias'] ?? 0} Kcal' : '0 Kcal',
                                  style: const TextStyle(color: Colors.white70, fontSize: 14),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),
                    // Racha de días
                    if (_diasRacha > 0)
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFFFFD700), Color(0xFFFF8C00)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.local_fire_department, color: Colors.white, size: 40),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    '¡Racha activa!',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    '$_diasRacha días consecutivos registrando comidas',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 14,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              '$_diasRacha',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 36,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    if (_diasRacha > 0) const SizedBox(height: 24),
                    // Sección de peso y próximo control
                    Row(
                      children: [
                        // Peso actual
                        Expanded(
                          child: Container(
                            height: 200,
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: Colors.grey[900],
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.accessibility_new, color: verdeApp, size: 40),
                                const SizedBox(height: 12),
                                const Text(
                                  "Peso anterior:",
                                  style: TextStyle(color: Colors.white70, fontSize: 11),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  "${_historiaPeso.isNotEmpty && _historiaPeso.length > 1 ? _historiaPeso[_historiaPeso.length - 2]['peso'] : peso} kg",
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                const Text(
                                  "Peso actual:",
                                  style: TextStyle(color: Colors.white70, fontSize: 11),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  "$peso kg",
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 16),
                        // Próximo control
                        Expanded(
                          child: InkWell(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (_) => const CalendarioSeguimientoPage()),
                              );
                            },
                            borderRadius: BorderRadius.circular(16),
                            child: Container(
                              height: 200,
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: Colors.grey[900],
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.calendar_month, color: verdeApp, size: 40),
                                  const SizedBox(height: 12),
                                  const Text(
                                    'Próximo control',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w500,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                  const SizedBox(height: 12),
                                  if (_proximoControl != null) ...[
                                    Text(
                                      _formatearFechaControl(DateTime.parse(_proximoControl!['fecha'])),
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                      textAlign: TextAlign.center,
                                    ),
                                    const SizedBox(height: 6),
                                    Text(
                                      'Control ${_proximoControl!['numero_control']}',
                                      style: TextStyle(
                                        color: Colors.grey[400],
                                        fontSize: 11,
                                      ),
                                      textAlign: TextAlign.center,
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      'Día ${_proximoControl!['dias_desde_inicio']}',
                                      style: const TextStyle(
                                        color: verdeApp,
                                        fontSize: 11,
                                      ),
                                      textAlign: TextAlign.center,
                                    ),
                                  ] else ...[
                                    const SizedBox(height: 8),
                                    Text(
                                      'Sin control\nprogramado',
                                      style: TextStyle(
                                        color: Colors.grey[500],
                                        fontSize: 11,
                                      ),
                                      textAlign: TextAlign.center,
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      'Toca para iniciar',
                                      style: TextStyle(
                                        color: Colors.grey[600],
                                        fontSize: 10,
                                      ),
                                      textAlign: TextAlign.center,
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  const SizedBox(height: 100),
                ],
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: const CustomBottomNav(currentIndex: 2),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const ChatPage(),
              fullscreenDialog: true,
            ),
          );
        },
        backgroundColor: verdeApp,
        elevation: 4,
        child: const Icon(Icons.chat_bubble_outline, color: Colors.white),
      ),
    );
  }

  String _formatearFechaControl(DateTime fecha) {
    final ahora = DateTime.now();
    final diferencia = fecha.difference(ahora).inDays;

    if (diferencia == 0) return 'Hoy';
    if (diferencia == 1) return 'Mañana';
    if (diferencia > 1 && diferencia <= 7) return 'En $diferencia días';

    final meses = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
    return '${fecha.day} ${meses[fecha.month - 1]}';
  }
}