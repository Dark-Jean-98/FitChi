import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/intl.dart';

class CalendarioSeguimientoPage extends StatefulWidget {
  const CalendarioSeguimientoPage({super.key});

  @override
  State<CalendarioSeguimientoPage> createState() => _CalendarioSeguimientoPageState();
}

class _CalendarioSeguimientoPageState extends State<CalendarioSeguimientoPage> {
  static const Color verdeApp = Color(0xFF66BB6A);
  final supabase = Supabase.instance.client;
  final String baseUrl = 'https://fitchi-backend-398799029559.southamerica-west1.run.app';

  Map<String, dynamic>? _calendarioData;
  bool _cargando = true;
  bool _planActivo = false;

  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  @override
  void initState() {
    super.initState();
    _cargarCalendario();
  }

  Future<void> _cargarCalendario() async {
    setState(() => _cargando = true);

    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/calendario-seguimiento/${user.id}'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _calendarioData = data;
          _planActivo = data['plan_activo'] ?? false;
          _cargando = false;
        });
      }
    } catch (e) {
      setState(() => _cargando = false);
    }
  }

  Future<void> _iniciarPlan() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.dark(
              primary: verdeApp,
              onPrimary: Colors.black,
              surface: Colors.grey[850]!,
              onSurface: Colors.white,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      try {
        final response = await http.post(
          Uri.parse('$baseUrl/api/iniciar-plan'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'user_id': user.id,
            'fecha_inicio': picked.toIso8601String().split('T')[0],
          }),
        );

        if (response.statusCode == 200 && mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Plan iniciado correctamente'),
              backgroundColor: verdeApp,
            ),
          );
          _cargarCalendario();
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error al iniciar plan: $e'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    }
  }

  Future<void> _registrarPeso() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    final TextEditingController pesoController = TextEditingController();
    final TextEditingController notasController = TextEditingController();

    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Colors.grey[900],
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Registrar peso', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: pesoController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Peso (kg)',
                  labelStyle: const TextStyle(color: Colors.white70),
                  prefixIcon: const Icon(Icons.monitor_weight, color: verdeApp),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.grey[700]!)),
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.grey[700]!)),
                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: verdeApp, width: 2)),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: notasController,
                maxLines: 3,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Notas (opcional)',
                  labelStyle: const TextStyle(color: Colors.white70),
                  prefixIcon: const Icon(Icons.note, color: verdeApp),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.grey[700]!)),
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.grey[700]!)),
                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: verdeApp, width: 2)),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancelar', style: TextStyle(color: Colors.white54)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: verdeApp,
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () async {
                if (pesoController.text.isEmpty) return;

                try {
                  final response = await http.post(
                    Uri.parse('$baseUrl/api/registrar-peso'),
                    headers: {'Content-Type': 'application/json'},
                    body: jsonEncode({
                      'user_id': user.id,
                      'peso': double.parse(pesoController.text),
                      'notas': notasController.text,
                    }),
                  );

                  if (response.statusCode == 200 && mounted) {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Peso registrado correctamente'),
                        backgroundColor: verdeApp,
                      ),
                    );
                    _cargarCalendario();
                  }
                } catch (e) {
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Error al registrar peso: $e'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                }
              },
              child: const Text('Guardar', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text('Calendario de Seguimiento', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black),
        elevation: 0,
        actions: [
          if (_planActivo)
            IconButton(
              icon: const Icon(Icons.add_circle_outline),
              onPressed: _registrarPeso,
            ),
        ],
      ),
      body: _cargando
          ? const Center(child: CircularProgressIndicator(color: verdeApp))
          : !_planActivo
              ? _buildNoPlanView()
              : _buildCalendarioView(),
    );
  }

  Widget _buildNoPlanView() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.calendar_today, size: 100, color: Colors.grey[400]),
            const SizedBox(height: 24),
            const Text(
              'No tienes un plan activo',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            const Text(
              'Inicia tu plan de seguimiento para llevar control de tu progreso cada 15 días',
              style: TextStyle(fontSize: 16, color: Colors.grey),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            ElevatedButton.icon(
              onPressed: _iniciarPlan,
              icon: const Icon(Icons.play_arrow, color: Colors.black),
              label: const Text('Iniciar mi plan', style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.bold)),
              style: ElevatedButton.styleFrom(
                backgroundColor: verdeApp,
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                elevation: 4,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCalendarioView() {
    final data = _calendarioData!;
    final fechaInicio = DateTime.parse(data['fecha_inicio']);
    final diasTranscurridos = data['dias_transcurridos'];
    final controles = data['controles'] as List;
    final proximoControl = data['proximo_control'];
    final registrosPeso = data['registros_peso'] as List;

    // Marcar fechas de control en el calendario
    final Map<DateTime, List<String>> eventos = {};
    for (var control in controles) {
      final fecha = DateTime.parse(control['fecha']);
      final fechaNormalizada = DateTime(fecha.year, fecha.month, fecha.day);
      eventos[fechaNormalizada] = ['Control ${control['numero_control']}'];
    }

    return RefreshIndicator(
      color: verdeApp,
      onRefresh: _cargarCalendario,
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Resumen del plan
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.grey[900],
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: verdeApp,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.calendar_today, color: Colors.white),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Días en tu plan',
                                style: TextStyle(color: Colors.white70, fontSize: 14),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '$diasTranscurridos días',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 28,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Inicio',
                                style: TextStyle(color: Colors.white70, fontSize: 12),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                _formatearFecha(fechaInicio),
                                style: const TextStyle(
                                  color: verdeApp,
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (proximoControl != null)
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                const Text(
                                  'Próximo control',
                                  style: TextStyle(color: Colors.white70, fontSize: 12),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  _formatearFecha(DateTime.parse(proximoControl['fecha'])),
                                  style: const TextStyle(
                                    color: verdeApp,
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              // Calendario
              Container(
                decoration: BoxDecoration(
                  color: Colors.grey[900],
                  borderRadius: BorderRadius.circular(16),
                ),
                child: TableCalendar(
                  firstDay: fechaInicio,
                  lastDay: DateTime.now().add(const Duration(days: 365)),
                  focusedDay: _focusedDay,
                  selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
                  onDaySelected: (selectedDay, focusedDay) {
                    setState(() {
                      _selectedDay = selectedDay;
                      _focusedDay = focusedDay;
                    });
                  },
                  calendarFormat: CalendarFormat.month,
                  startingDayOfWeek: StartingDayOfWeek.monday,
                  eventLoader: (day) {
                    final dayNormalized = DateTime(day.year, day.month, day.day);
                    return eventos[dayNormalized] ?? [];
                  },
                  calendarStyle: CalendarStyle(
                    defaultTextStyle: const TextStyle(color: Colors.white),
                    weekendTextStyle: const TextStyle(color: Colors.redAccent),
                    outsideTextStyle: const TextStyle(color: Colors.white24),
                    todayDecoration: BoxDecoration(
                      color: verdeApp.withAlpha(128),
                      shape: BoxShape.circle,
                    ),
                    todayTextStyle: const TextStyle(color: Colors.white),
                    selectedDecoration: const BoxDecoration(
                      color: verdeApp,
                      shape: BoxShape.circle,
                    ),
                    selectedTextStyle: const TextStyle(color: Colors.black),
                    markerDecoration: const BoxDecoration(
                      color: Colors.orange,
                      shape: BoxShape.circle,
                    ),
                  ),
                  headerStyle: const HeaderStyle(
                    formatButtonVisible: false,
                    titleCentered: true,
                    titleTextStyle: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  daysOfWeekStyle: const DaysOfWeekStyle(
                    weekdayStyle: TextStyle(color: Colors.white70),
                    weekendStyle: TextStyle(color: Colors.redAccent),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              // Lista de controles
              const Text(
                'Controles programados',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black),
              ),
              const SizedBox(height: 12),
              ...controles.take(6).map((control) => _buildControlItem(control)),
              const SizedBox(height: 20),
              // Historial de peso
              if (registrosPeso.isNotEmpty) ...[
                const Text(
                  'Historial de peso',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black),
                ),
                const SizedBox(height: 12),
                ...registrosPeso.reversed.take(5).map((registro) => _buildRegistroPeso(registro)),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildControlItem(Map<String, dynamic> control) {
    final completado = control['completado'];
    final fecha = DateTime.parse(control['fecha']);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: completado ? verdeApp : Colors.grey[700]!,
          width: 2,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: completado ? verdeApp : Colors.grey[700],
              shape: BoxShape.circle,
            ),
            child: Icon(
              completado ? Icons.check : Icons.event,
              color: Colors.white,
              size: 20,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Control ${control['numero_control']}',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  _formatearFecha(fecha),
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.white70,
                  ),
                ),
              ],
            ),
          ),
          Text(
            'Día ${control['dias_desde_inicio']}',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: completado ? verdeApp : Colors.white70,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRegistroPeso(Map<String, dynamic> registro) {
    final fecha = DateTime.parse(registro['fecha']);
    final peso = registro['peso'];

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: verdeApp.withAlpha(51),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.monitor_weight, color: verdeApp, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _formatearFecha(fecha),
                  style: const TextStyle(fontSize: 14, color: Colors.white70),
                ),
                const SizedBox(height: 4),
                Text(
                  '$peso kg',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                if (registro['notas'] != null && registro['notas'].toString().isNotEmpty)
                  Text(
                    registro['notas'],
                    style: const TextStyle(fontSize: 12, color: Colors.white54),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _formatearFecha(DateTime fecha) {
    final meses = [
      'Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun',
      'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'
    ];
    return '${fecha.day} ${meses[fecha.month - 1]} ${fecha.year}';
  }
}
