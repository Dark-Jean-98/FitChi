import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'configuracion_recordatorios.dart';
import 'calendario_seguimiento_page.dart';

// (Asegúrate de que el resto de tus imports estén aquí)

class EditProfilePage extends StatefulWidget {
  const EditProfilePage({super.key});

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  static const Color verdeApp = Color(0xFF66BB6A);
  final supabase = Supabase.instance.client;
  final String baseUrl = "https://fitchi-backend-398799029559.southamerica-west1.run.app";
  bool _loading = false;
  bool _loadingData = true;

  final TextEditingController _nombreController = TextEditingController();
  final TextEditingController _pesoController = TextEditingController();
  final TextEditingController _alturaController = TextEditingController();
  final TextEditingController _cinturaController = TextEditingController();
  final TextEditingController _caderaController = TextEditingController();
  final TextEditingController _alergiasController = TextEditingController();
  final TextEditingController _patologiaController = TextEditingController();

  String? _sexoSeleccionado;
  DateTime? _fechaNacimiento;
  String? _actividadSeleccionada;
  String? _objetivoSeleccionado;
  int _numeroComidas = 3;
  String? _avatarUrl;

  final Map<String, bool> _preferenciasAlimentarias = {
    'Vegetariano': false,
    'Vegano': false,
    'Sin gluten': false,
    'Sin lácteos': false,
    'Kosher/Halal': false,
    'Sin preferencias especiales': true,
  };

  // --- Mapas de factores y ajustes (Tu lógica existente) ---
  final Map<String, double> _factoresActividad = {
    "Sedentario (mínimo ejercicio)": 1.2,
    "Ligera (1-3 días/sem de ejercicio)": 1.375,
    "Moderada (3-5 días/sem)": 1.55,
    "Intensa (6-7 días/sem)": 1.725,
    "Muy intensa (entrenamiento diario)": 1.9,
  };
  final Map<String, double> _ajustesObjetivo = {
    "Déficit calórico (pérdida de grasa)": -500,
    "Recomposición corporal": -300,
    "Mantenimiento": 0,
    "Superávit (ganancia muscular)": 400,
  };
  // (El resto de tus variables de estado)

  @override
  void initState() {
    super.initState();
    _cargarDatos();
  }

  Future<void> _cargarDatos() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final data = await supabase
          .from('usuarios')
          .select()
          .eq('id', user.id)
          .single();

      final preferencias = await supabase
          .from('preferencias_alimentarias')
          .select()
          .eq('usuario_id', user.id);

      setState(() {
        _nombreController.text = data['nombre'] ?? '';
        _pesoController.text = data['peso']?.toString() ?? '';
        _alturaController.text = data['altura']?.toString() ?? '';
        _cinturaController.text = data['cintura']?.toString() ?? '';
        _caderaController.text = data['cadera']?.toString() ?? '';
        _alergiasController.text = data['alergias'] ?? '';
        _patologiaController.text = data['patologia'] ?? '';

        _sexoSeleccionado = data['sexo'];
        _actividadSeleccionada = data['nivel_actividad'];
        _objetivoSeleccionado = data['objetivo_nutricional'];
        _numeroComidas = data['numero_comidas'] ?? 3;
        _avatarUrl = data['avatar_url'];
        
        if (data['fecha_nacimiento'] != null) {
          try {
            _fechaNacimiento = DateTime.parse(data['fecha_nacimiento']);
          } catch (e) {
            _fechaNacimiento = null;
          }
        }

        if (preferencias.isNotEmpty) {
          _preferenciasAlimentarias.updateAll((key, value) => false);
          for (var pref in preferencias) {
            if (_preferenciasAlimentarias.containsKey(pref['preferencia'])) {
              _preferenciasAlimentarias[pref['preferencia']] = true;
            }
          }
        }
        
        _loadingData = false;
      });
    } catch (e) {
      setState(() => _loadingData = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al cargar datos: $e')),
      );
    }
  }

  // --- Tus funciones de cálculo (TMB, Edad) ---
  int _calcularEdad(DateTime fechaNac) {
    final hoy = DateTime.now();
    int edad = hoy.year - fechaNac.year;
    if (hoy.month < fechaNac.month || (hoy.month == fechaNac.month && hoy.day < fechaNac.day)) {
      edad--;
    }
    return edad;
  }

  double _calcularTMB(double peso, double altura, int edad, String sexo) {
    if (sexo.toLowerCase() == "hombre" || sexo.toLowerCase() == "masculino") {
      return 66 + (13.7 * peso) + (5 * altura) - (6.8 * edad);
    } else {
      return 655 + (9.6 * peso) + (1.8 * altura) - (4.7 * edad);
    }
  }
  
  // --- ¡NUEVA FUNCIÓN! ---
  // He movido la lógica de cálculo de % grasa aquí para reutilizarla
  Map<String, double> _calcularComposicion(double peso, double alturaCm, double cintura, double cadera, String sexo) {
      final alturaM = alturaCm / 100;
      
      // 1. IMC
      final imc = (alturaM > 0) ? (peso / (alturaM * alturaM)) : 0.0;
      
      // 2. % Grasa (Misma fórmula de graficos_corporales.dart)
      double percentGrasa = 0.0;
      if (cintura > 0 && alturaCm > 0) {
        if (sexo.toLowerCase().startsWith('m')) { 
          percentGrasa = 86.010 * (cintura / alturaCm) - 24.38; 
        } else if (cadera > 0) { 
          percentGrasa = 163.205 * (cintura + cadera) / alturaCm - 97.604; 
        }
      }
      
      if (percentGrasa < 5) percentGrasa = 5.0; 
      if (percentGrasa > 50) percentGrasa = 50.0; 
      
      // 3. % Masa Magra
      final percentMasaMagra = 100.0 - percentGrasa;

      return {
        'imc': imc,
        'porcentaje_grasa': percentGrasa,
        'porcentaje_masa_magra': percentMasaMagra,
      };
  }

  Future<void> _mostrarSelectorAvatares() async {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        minChildSize: 0.5,
        maxChildSize: 0.9,
        builder: (_, controller) => Container(
          decoration: BoxDecoration(
            color: Colors.grey[900],
            borderRadius: const BorderRadius.vertical(top: Radius.circular(25)),
          ),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.grey[900],
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(25)),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: verdeApp.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.person, color: verdeApp, size: 24),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Text(
                        'Selecciona tu avatar',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1, color: Colors.white24),
              Expanded(
                child: FutureBuilder<List<Map<String, String>>>(
                  future: _cargarAvatares(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(
                        child: CircularProgressIndicator(color: verdeApp),
                      );
                    }

                    if (snapshot.hasError || !snapshot.hasData || snapshot.data!.isEmpty) {
                      return Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.error_outline, size: 64, color: Colors.grey[600]),
                            const SizedBox(height: 16),
                            Text(
                              'No se pudieron cargar los avatares',
                              style: TextStyle(color: Colors.grey[400]),
                            ),
                          ],
                        ),
                      );
                    }

                    final avatares = snapshot.data!;

                    return GridView.builder(
                      controller: controller,
                      padding: const EdgeInsets.all(20),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        childAspectRatio: 1,
                        crossAxisSpacing: 16,
                        mainAxisSpacing: 16,
                      ),
                      itemCount: avatares.length,
                      itemBuilder: (context, index) {
                        final avatar = avatares[index];
                        final isSelected = _avatarUrl == avatar['url'];

                        return GestureDetector(
                          onTap: () {
                            setState(() => _avatarUrl = avatar['url']);
                            Navigator.pop(context);
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.grey[850],
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: isSelected ? verdeApp : Colors.grey[700]!,
                                width: isSelected ? 3 : 1,
                              ),
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.network(
                                avatar['url']!,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) {
                                  return Icon(
                                    Icons.person,
                                    size: 48,
                                    color: Colors.grey[600],
                                  );
                                },
                              ),
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<List<Map<String, String>>> _cargarAvatares() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/avatares'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final avataresList = data['avatares'] as List;
        return avataresList.map((avatar) => {
          'name': avatar['name'] as String,
          'url': avatar['url'] as String,
        }).toList();
      }
      return [];
    } catch (e) {
      print('Error al cargar avatares: $e');
      return [];
    }
  }

  // --- FUNCIÓN DE GUARDADO ACTUALIZADA ---
  Future<void> _guardarCambios() async {
    // (Tus validaciones existentes)
    if (_pesoController.text.isEmpty || _alturaController.text.isEmpty || _actividadSeleccionada == null || _objetivoSeleccionado == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Peso, altura, actividad y objetivo son obligatorios')),
      );
      return;
    }

    setState(() => _loading = true);

    try {
      final user = supabase.auth.currentUser;
      if (user == null) return;

      // 1. Recolectar datos
      final peso = double.parse(_pesoController.text.trim());
      final altura = double.parse(_alturaController.text.trim());
      final cintura = _cinturaController.text.trim().isEmpty ? 0.0 : double.parse(_cinturaController.text.trim());
      final cadera = _caderaController.text.trim().isEmpty ? 0.0 : double.parse(_caderaController.text.trim());
      final sexo = _sexoSeleccionado ?? 'Masculino';
      final edad = _fechaNacimiento != null ? _calcularEdad(_fechaNacimiento!) : 25;

      // 2. Calcular todo
      final tmb = _calcularTMB(peso, altura, edad, sexo);
      final factor = _factoresActividad[_actividadSeleccionada]!;
      final get = tmb * factor;
      final ajuste = _ajustesObjetivo[_objetivoSeleccionado]!;
      final caloriasObjetivo = get + ajuste;

      // (Tu lógica de macros existente)
      final distribucionesMacros = {
        "Déficit calórico (pérdida de grasa)": {"proteinas": 27.5, "grasas": 27.5, "carbohidratos": 45.0},
        "Superávit (ganancia muscular)": {"proteinas": 22.5, "grasas": 22.5, "carbohidratos": 52.5},
        "Mantenimiento": {"proteinas": 22.5, "grasas": 27.5, "carbohidratos": 50.0},
        "Recomposición corporal": {"proteinas": 27.5, "grasas": 27.5, "carbohidratos": 45.0},
      };
      final distribucion = distribucionesMacros[_objetivoSeleccionado]!;
      final proteinas = ((caloriasObjetivo * distribucion["proteinas"]!) / 100) / 4;
      final grasas = ((caloriasObjetivo * distribucion["grasas"]!) / 100) / 9;
      final carbos = ((caloriasObjetivo * distribucion["carbohidratos"]!) / 100) / 4;
      final porcionesCarbo = carbos / 15;
      final porcionesProteina = proteinas / 7;
      final porcionesGrasa = grasas / 5;
      
      // 3. Calcular composición corporal
      final composicion = _calcularComposicion(peso, altura, cintura, cadera, sexo);

      // 4. Guardar en historial_mediciones
      await supabase.from('historial_mediciones').insert({
        'usuario_id': user.id,
        'peso': peso,
        'altura': altura,
        'cintura': cintura == 0.0 ? null : cintura,
        'cadera': cadera == 0.0 ? null : cadera,
        'imc': composicion['imc'],
        'porcentaje_grasa': composicion['porcentaje_grasa'],
        'porcentaje_masa_magra': composicion['porcentaje_masa_magra'],
        'fecha_registro': DateTime.now().toIso8601String(),
      });

      await supabase.from('usuarios').update({
        'nombre': _nombreController.text.trim(),
        'peso': peso,
        'altura': altura,
        'cintura': cintura == 0.0 ? null : cintura,
        'cadera': cadera == 0.0 ? null : cadera,
        'sexo': _sexoSeleccionado,
        'fecha_nacimiento': _fechaNacimiento?.toIso8601String().split('T')[0],
        'alergias': _alergiasController.text.trim(),
        'patologia': _patologiaController.text.trim(),
        'nivel_actividad': _actividadSeleccionada,
        'factor_actividad': factor,
        'objetivo_nutricional': _objetivoSeleccionado,
        'numero_comidas': _numeroComidas,
        'tmb': tmb.round(),
        'get_calorico': get.round(),
        'calorias_objetivo': caloriasObjetivo.round(),
        'proteinas_gramos': proteinas.round(),
        'avatar_url': _avatarUrl,
        'carbohidratos_gramos': carbos.round(),
        'grasas_gramos': grasas.round(),
        'porciones_carbo': porcionesCarbo.round(),
        'porciones_proteina': porcionesProteina.round(),
        'porciones_grasa': porcionesGrasa.round(),
      }).eq('id', user.id);

      await supabase
          .from('preferencias_alimentarias')
          .delete()
          .eq('usuario_id', user.id);

      final preferenciasSeleccionadas = _preferenciasAlimentarias.entries
          .where((entry) => entry.value)
          .map((entry) => {'usuario_id': user.id, 'preferencia': entry.key})
          .toList();

      if (preferenciasSeleccionadas.isNotEmpty) {
        await supabase.from('preferencias_alimentarias').insert(preferenciasSeleccionadas);
      }

      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Perfil actualizado correctamente'), backgroundColor: Colors.green),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    } finally {
      setState(() => _loading = false);
    }
  }

  // --- El resto de tus widgets _build... (sin cambios) ---
  
  @override
  Widget build(BuildContext context) {
    if (_loadingData) {
      return Scaffold(
        backgroundColor: Colors.grey[100],
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          title: const Text('Editar Perfil', style: TextStyle(color: Colors.black)),
          iconTheme: const IconThemeData(color: Colors.black),
        ),
        body: const Center(child: CircularProgressIndicator(color: verdeApp)),
      );
    }

    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          'Editar Perfil',
          style: TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.bold),
        ),
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Avatar selector
            Container(
              margin: const EdgeInsets.only(bottom: 16),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  GestureDetector(
                    onTap: _mostrarSelectorAvatares,
                    child: Stack(
                      children: [
                        Container(
                          width: 100,
                          height: 100,
                          decoration: BoxDecoration(
                            color: Colors.grey[200],
                            shape: BoxShape.circle,
                            border: Border.all(color: verdeApp, width: 3),
                          ),
                          child: ClipOval(
                            child: _avatarUrl != null && _avatarUrl!.isNotEmpty
                                ? Image.network(
                                    _avatarUrl!,
                                    fit: BoxFit.cover,
                                    errorBuilder: (context, error, stackTrace) {
                                      return const Icon(Icons.person, size: 50, color: Colors.grey);
                                    },
                                  )
                                : const Icon(Icons.person, size: 50, color: Colors.grey),
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: verdeApp,
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 2),
                            ),
                            child: const Icon(Icons.edit, color: Colors.white, size: 16),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'Toca para cambiar avatar',
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
            _buildSection(
              'Datos Personales',
              Icons.person_outline,
              [
                _buildTextField('Nombre', _nombreController),
                const SizedBox(height: 16),
                _buildSexoSelector(),
                const SizedBox(height: 16),
                _buildFechaNacimientoSelector(),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(child: _buildTextField('Peso (kg)', _pesoController, isNumber: true)),
                    const SizedBox(width: 12),
                    Expanded(child: _buildTextField('Altura (cm)', _alturaController, isNumber: true)),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(child: _buildTextField('Cintura (cm)', _cinturaController, isNumber: true, required: false)),
                    const SizedBox(width: 12),
                    Expanded(child: _buildTextField('Cadera (cm)', _caderaController, isNumber: true, required: false)),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 20),

            _buildSection(
              'Objetivos',
              Icons.flag_outlined,
              [
                _buildDropdown(
                  'Nivel de actividad',
                  _actividadSeleccionada,
                  _factoresActividad.keys.toList(),
                  (value) => setState(() => _actividadSeleccionada = value),
                ),
                const SizedBox(height: 16),
                _buildDropdown(
                  'Objetivo nutricional',
                  _objetivoSeleccionado,
                  _ajustesObjetivo.keys.toList(),
                  (value) => setState(() => _objetivoSeleccionado = value),
                ),
                const SizedBox(height: 16),
                _buildNumeroComidas(),
              ],
            ),
            const SizedBox(height: 20),

            _buildSection(
              'Salud',
              Icons.favorite_outline,
              [
                _buildTextField('Alergias', _alergiasController, maxLines: 3, required: false),
                const SizedBox(height: 16),
                _buildTextField('Patologías', _patologiaController, maxLines: 3, required: false),
              ],
            ),
            const SizedBox(height: 20),

            _buildSection(
              'Preferencias Alimentarias',
              Icons.restaurant_menu,
              [
                _buildPreferenciasCheckboxes(),
              ],
            ),
            const SizedBox(height: 20),

            _buildSection(
              'Configuración',
              Icons.settings,
              [
                _buildMenuOption(
                  icon: Icons.notifications_active,
                  title: 'Recordatorios',
                  subtitle: 'Configura recordatorios de comidas y agua',
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const ConfiguracionRecordatoriosPage()),
                    );
                  },
                ),
                const SizedBox(height: 12),
                _buildMenuOption(
                  icon: Icons.calendar_month,
                  title: 'Calendario de Seguimiento',
                  subtitle: 'Controla tu progreso cada 15 días',
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const CalendarioSeguimientoPage()),
                    );
                  },
                ),
              ],
            ),
            const SizedBox(height: 32),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _loading ? null : _guardarCambios,
                style: ElevatedButton.styleFrom(
                  backgroundColor: verdeApp,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  elevation: 4,
                ),
                child: _loading
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2),
                      )
                    : const Text('Guardar Cambios', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(String title, IconData icon, List<Widget> children) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: verdeApp, size: 24),
              const SizedBox(width: 12),
              Text(
                title,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
              ),
            ],
          ),
          const SizedBox(height: 20),
          ...children,
        ],
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller, {bool isNumber = false, int maxLines = 1, bool required = true}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: Colors.white)),
            if (required) const Text(' *', style: TextStyle(color: Colors.red)),
          ],
        ),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          keyboardType: isNumber ? TextInputType.number : TextInputType.text,
          maxLines: maxLines,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            filled: true,
            fillColor: Colors.grey[800],
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          ),
        ),
      ],
    );
  }

  Widget _buildSexoSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Row(
          children: [
            Text('Sexo', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: Colors.white)),
            Text(' *', style: TextStyle(color: Colors.red)),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: ['Masculino', 'Femenino', 'Otro'].map((sexo) {
            final isSelected = _sexoSeleccionado == sexo;
            return Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: ElevatedButton(
                  onPressed: () => setState(() => _sexoSeleccionado = sexo),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isSelected ? verdeApp : Colors.grey[700],
                    foregroundColor: isSelected ? Colors.black : Colors.white,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: Text(sexo, style: const TextStyle(fontSize: 13)),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildFechaNacimientoSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Row(
          children: [
            Text('Fecha de nacimiento', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: Colors.white)),
            Text(' *', style: TextStyle(color: Colors.red)),
          ],
        ),
        const SizedBox(height: 8),
        InkWell(
          onTap: () async {
            final picked = await showDatePicker(
              context: context,
              initialDate: _fechaNacimiento ?? DateTime(2000),
              firstDate: DateTime(1900),
              lastDate: DateTime.now(),
            );
            if (picked != null) {
              setState(() => _fechaNacimiento = picked);
            }
          },
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.grey[800],
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  _fechaNacimiento == null
                      ? 'Seleccionar fecha'
                      : "${_fechaNacimiento!.day}/${_fechaNacimiento!.month}/${_fechaNacimiento!.year}",
                  style: TextStyle(color: _fechaNacimiento == null ? Colors.grey : Colors.white),
                ),
                const Icon(Icons.calendar_today, size: 20, color: Colors.white70),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDropdown(String label, String? value, List<String> items, Function(String?) onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: Colors.white)),
            const Text(' *', style: TextStyle(color: Colors.red)),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: Colors.grey[800],
            borderRadius: BorderRadius.circular(12),
          ),
          child: DropdownButton<String>(
            value: value,
            isExpanded: true,
            underline: Container(),
            dropdownColor: Colors.grey[800],
            hint: const Text('Seleccionar', style: TextStyle(color: Colors.white54)),
            style: const TextStyle(color: Colors.white, fontSize: 13),
            items: items.map((item) {
              return DropdownMenuItem(
                value: item,
                child: Text(item, style: const TextStyle(fontSize: 13)),
              );
            }).toList(),
            onChanged: onChanged,
          ),
        ),
      ],
    );
  }

  Widget _buildNumeroComidas() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Número de comidas al día', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: Colors.white)),
        const SizedBox(height: 8),
        Row(
          children: [3, 4, 5, 6].map((num) {
            final isSelected = _numeroComidas == num;
            return Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: ElevatedButton(
                  onPressed: () => setState(() => _numeroComidas = num),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isSelected ? verdeApp : Colors.grey[700],
                    foregroundColor: isSelected ? Colors.black : Colors.white,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: Text('$num'),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildPreferenciasCheckboxes() {
    return Column(
      children: _preferenciasAlimentarias.keys.map((preferencia) {
        return CheckboxListTile(
          title: Text(preferencia, style: const TextStyle(color: Colors.white)),
          value: _preferenciasAlimentarias[preferencia],
          activeColor: verdeApp,
          checkColor: Colors.black,
          contentPadding: EdgeInsets.zero,
          onChanged: (value) {
            setState(() {
              if (preferencia == 'Sin preferencias especiales' && value == true) {
                _preferenciasAlimentarias.updateAll((key, val) => key == 'Sin preferencias especiales');
              } else {
                _preferenciasAlimentarias[preferencia] = value!;
                if (value == true) _preferenciasAlimentarias['Sin preferencias especiales'] = false;
              }
            });
          },
        );
      }).toList(),
    );
  }

  Widget _buildMenuOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: verdeApp.withAlpha(51),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: verdeApp, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      fontSize: 13,
                      color: Colors.white70,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: Colors.white54),
          ],
        ),
      ),
    );
  }
}