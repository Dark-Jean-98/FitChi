import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/notification_service.dart';

class ConfiguracionRecordatoriosPage extends StatefulWidget {
  const ConfiguracionRecordatoriosPage({super.key});

  @override
  State<ConfiguracionRecordatoriosPage> createState() => _ConfiguracionRecordatoriosPageState();
}

class _ConfiguracionRecordatoriosPageState extends State<ConfiguracionRecordatoriosPage> {
  static const Color verdeApp = Color(0xFF66BB6A);

  final NotificationService _notificationService = NotificationService();

  bool _recordatoriosActivos = false;
  bool _recordatoriosAguaActivos = false;

  TimeOfDay _horaDesayuno = const TimeOfDay(hour: 8, minute: 0);
  TimeOfDay _horaAlmuerzo = const TimeOfDay(hour: 13, minute: 0);
  TimeOfDay _horaCena = const TimeOfDay(hour: 19, minute: 0);

  int _intervaloAgua = 2; // horas
  int _horaInicioAgua = 8;
  int _horaFinAgua = 20;

  bool _cambiosPendientes = false;

  @override
  void initState() {
    super.initState();
    _initNotifications();
    _cargarConfiguracion();
  }

  Future<void> _initNotifications() async {
    await _notificationService.initialize();
    await _notificationService.requestPermissions();
  }

  Future<void> _cargarConfiguracion() async {
    final prefs = await SharedPreferences.getInstance();

    setState(() {
      // Cargar estado de recordatorios
      _recordatoriosActivos = prefs.getBool('recordatorios_activos') ?? false;
      _recordatoriosAguaActivos = prefs.getBool('recordatorios_agua_activos') ?? false;

      // Cargar horas de comidas
      _horaDesayuno = TimeOfDay(
        hour: prefs.getInt('hora_desayuno_hour') ?? 8,
        minute: prefs.getInt('hora_desayuno_minute') ?? 0,
      );
      _horaAlmuerzo = TimeOfDay(
        hour: prefs.getInt('hora_almuerzo_hour') ?? 13,
        minute: prefs.getInt('hora_almuerzo_minute') ?? 0,
      );
      _horaCena = TimeOfDay(
        hour: prefs.getInt('hora_cena_hour') ?? 19,
        minute: prefs.getInt('hora_cena_minute') ?? 0,
      );

      // Cargar configuración de agua
      _intervaloAgua = prefs.getInt('intervalo_agua') ?? 2;
      _horaInicioAgua = prefs.getInt('hora_inicio_agua') ?? 8;
      _horaFinAgua = prefs.getInt('hora_fin_agua') ?? 20;
    });
  }

  Future<void> _guardarConfiguracion() async {
    final prefs = await SharedPreferences.getInstance();

    // Guardar estado de recordatorios
    await prefs.setBool('recordatorios_activos', _recordatoriosActivos);
    await prefs.setBool('recordatorios_agua_activos', _recordatoriosAguaActivos);

    // Guardar horas de comidas
    await prefs.setInt('hora_desayuno_hour', _horaDesayuno.hour);
    await prefs.setInt('hora_desayuno_minute', _horaDesayuno.minute);
    await prefs.setInt('hora_almuerzo_hour', _horaAlmuerzo.hour);
    await prefs.setInt('hora_almuerzo_minute', _horaAlmuerzo.minute);
    await prefs.setInt('hora_cena_hour', _horaCena.hour);
    await prefs.setInt('hora_cena_minute', _horaCena.minute);

    // Guardar configuración de agua
    await prefs.setInt('intervalo_agua', _intervaloAgua);
    await prefs.setInt('hora_inicio_agua', _horaInicioAgua);
    await prefs.setInt('hora_fin_agua', _horaFinAgua);

    // Aplicar recordatorios
    await _programarRecordatorios();
    await _programarRecordatoriosAgua();

    setState(() => _cambiosPendientes = false);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Configuración guardada exitosamente'),
          backgroundColor: verdeApp,
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  Future<void> _seleccionarHora(BuildContext context, String tipoComida) async {
    TimeOfDay? horaActual;

    switch (tipoComida) {
      case 'desayuno':
        horaActual = _horaDesayuno;
        break;
      case 'almuerzo':
        horaActual = _horaAlmuerzo;
        break;
      case 'cena':
        horaActual = _horaCena;
        break;
    }

    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: horaActual ?? const TimeOfDay(hour: 12, minute: 0),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: verdeApp,
              onPrimary: Colors.white,
              onSurface: Colors.black,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        switch (tipoComida) {
          case 'desayuno':
            _horaDesayuno = picked;
            break;
          case 'almuerzo':
            _horaAlmuerzo = picked;
            break;
          case 'cena':
            _horaCena = picked;
            break;
        }
        _cambiosPendientes = true;
      });
    }
  }

  Future<void> _programarRecordatorios() async {
    await _notificationService.cancelarRecordatoriosComidas();

    if (_recordatoriosActivos) {
      await _notificationService.programarRecordatorioComida(
        id: 1,
        tipoComida: 'desayuno',
        hora: _horaDesayuno.hour,
        minuto: _horaDesayuno.minute,
      );

      await _notificationService.programarRecordatorioComida(
        id: 2,
        tipoComida: 'almuerzo',
        hora: _horaAlmuerzo.hour,
        minuto: _horaAlmuerzo.minute,
      );

      await _notificationService.programarRecordatorioComida(
        id: 3,
        tipoComida: 'cena',
        hora: _horaCena.hour,
        minuto: _horaCena.minute,
      );
    }
  }

  Future<void> _programarRecordatoriosAgua() async {
    await _notificationService.cancelarRecordatoriosAgua();

    if (_recordatoriosAguaActivos) {
      await _notificationService.programarRecordatoriosAgua(
        intervaloHoras: _intervaloAgua,
        horaInicio: _horaInicioAgua,
        horaFin: _horaFinAgua,
      );
    }
  }

  String _formatearHora(TimeOfDay time) {
    final hour = time.hour.toString().padLeft(2, '0');
    final minute = time.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text('Recordatorios', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Sección de recordatorios de comidas
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.grey[900],
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.1),
                      spreadRadius: 1,
                      blurRadius: 5,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Recordatorios de comida',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        Switch(
                          value: _recordatoriosActivos,
                          onChanged: (value) {
                            setState(() {
                              _recordatoriosActivos = value;
                              _cambiosPendientes = true;
                            });
                          },
                          activeColor: verdeApp,
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Configura las horas en las que deseas recibir recordatorios para tus comidas',
                      style: TextStyle(color: Colors.white54, fontSize: 14),
                    ),
                    const SizedBox(height: 20),
                    _buildHorarioComida(
                      icon: Icons.free_breakfast,
                      titulo: 'Desayuno',
                      hora: _horaDesayuno,
                      onTap: () => _seleccionarHora(context, 'desayuno'),
                    ),
                    const SizedBox(height: 12),
                    _buildHorarioComida(
                      icon: Icons.restaurant,
                      titulo: 'Almuerzo',
                      hora: _horaAlmuerzo,
                      onTap: () => _seleccionarHora(context, 'almuerzo'),
                    ),
                    const SizedBox(height: 12),
                    _buildHorarioComida(
                      icon: Icons.dinner_dining,
                      titulo: 'Cena',
                      hora: _horaCena,
                      onTap: () => _seleccionarHora(context, 'cena'),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              // Sección de recordatorios de agua
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.grey[900],
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.1),
                      spreadRadius: 1,
                      blurRadius: 5,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Recordatorios de agua',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        Switch(
                          value: _recordatoriosAguaActivos,
                          onChanged: (value) {
                            setState(() {
                              _recordatoriosAguaActivos = value;
                              _cambiosPendientes = true;
                            });
                          },
                          activeColor: verdeApp,
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Configura cada cuánto tiempo deseas recibir recordatorios para tomar agua',
                      style: TextStyle(color: Colors.white54, fontSize: 14),
                    ),
                    const SizedBox(height: 20),
                    _buildConfiguracionAgua(),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              // Botón Guardar
              if (_cambiosPendientes)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: ElevatedButton(
                    onPressed: _guardarConfiguracion,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: verdeApp,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      'Guardar configuración',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHorarioComida({
    required IconData icon,
    required String titulo,
    required TimeOfDay hora,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: _recordatoriosActivos ? onTap : null,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: _recordatoriosActivos ? verdeApp.withOpacity(0.1) : Colors.grey[700],
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                icon,
                color: _recordatoriosActivos ? verdeApp : Colors.grey,
                size: 24,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Text(
                titulo,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: _recordatoriosActivos ? Colors.white : Colors.grey,
                ),
              ),
            ),
            Text(
              _formatearHora(hora),
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: _recordatoriosActivos ? verdeApp : Colors.grey,
              ),
            ),
            const SizedBox(width: 8),
            Icon(
              Icons.chevron_right,
              color: _recordatoriosActivos ? Colors.white70 : Colors.grey[600],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildConfiguracionAgua() {
    return Column(
      children: [
        // Intervalo de horas
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.grey[800],
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Icon(Icons.schedule, color: _recordatoriosAguaActivos ? verdeApp : Colors.grey),
              const SizedBox(width: 16),
              const Expanded(
                child: Text(
                  'Cada cuántas horas',
                  style: TextStyle(fontSize: 16, color: Colors.white),
                ),
              ),
              DropdownButton<int>(
                value: _intervaloAgua,
                dropdownColor: Colors.grey[800],
                underline: Container(),
                style: TextStyle(
                  color: _recordatoriosAguaActivos ? verdeApp : Colors.white54,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
                items: [1, 2, 3, 4].map((int value) {
                  return DropdownMenuItem<int>(
                    value: value,
                    child: Text('$value h'),
                  );
                }).toList(),
                onChanged: _recordatoriosAguaActivos
                    ? (int? newValue) {
                        if (newValue != null) {
                          setState(() {
                            _intervaloAgua = newValue;
                            _cambiosPendientes = true;
                          });
                        }
                      }
                    : null,
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        // Hora de inicio
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.grey[800],
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Icon(Icons.wb_sunny, color: _recordatoriosAguaActivos ? verdeApp : Colors.grey),
              const SizedBox(width: 16),
              const Expanded(
                child: Text(
                  'Hora de inicio',
                  style: TextStyle(fontSize: 16, color: Colors.white),
                ),
              ),
              DropdownButton<int>(
                value: _horaInicioAgua,
                dropdownColor: Colors.grey[800],
                underline: Container(),
                style: TextStyle(
                  color: _recordatoriosAguaActivos ? verdeApp : Colors.white54,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
                items: List.generate(24, (index) => index).map((int value) {
                  return DropdownMenuItem<int>(
                    value: value,
                    child: Text('${value.toString().padLeft(2, '0')}:00'),
                  );
                }).toList(),
                onChanged: _recordatoriosAguaActivos
                    ? (int? newValue) {
                        if (newValue != null && newValue < _horaFinAgua) {
                          setState(() {
                            _horaInicioAgua = newValue;
                            _cambiosPendientes = true;
                          });
                        }
                      }
                    : null,
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        // Hora de fin
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.grey[800],
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Icon(Icons.nightlight_round, color: _recordatoriosAguaActivos ? verdeApp : Colors.grey),
              const SizedBox(width: 16),
              const Expanded(
                child: Text(
                  'Hora de fin',
                  style: TextStyle(fontSize: 16, color: Colors.white),
                ),
              ),
              DropdownButton<int>(
                value: _horaFinAgua,
                dropdownColor: Colors.grey[800],
                underline: Container(),
                style: TextStyle(
                  color: _recordatoriosAguaActivos ? verdeApp : Colors.white54,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
                items: List.generate(24, (index) => index).map((int value) {
                  return DropdownMenuItem<int>(
                    value: value,
                    child: Text('${value.toString().padLeft(2, '0')}:00'),
                  );
                }).toList(),
                onChanged: _recordatoriosAguaActivos
                    ? (int? newValue) {
                        if (newValue != null && newValue > _horaInicioAgua) {
                          setState(() {
                            _horaFinAgua = newValue;
                            _cambiosPendientes = true;
                          });
                        }
                      }
                    : null,
              ),
            ],
          ),
        ),
      ],
    );
  }
}
