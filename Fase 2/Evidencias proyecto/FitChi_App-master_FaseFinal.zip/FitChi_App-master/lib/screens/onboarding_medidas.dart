import 'package:flutter/material.dart';
import 'package:http/http.dart' as http; 
import 'dart:convert';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'home.dart';

class OnboardingMedidasPage extends StatefulWidget {
  const OnboardingMedidasPage({super.key});

  @override
  State<OnboardingMedidasPage> createState() => _OnboardingMedidasPageState();
}

class _OnboardingMedidasPageState extends State<OnboardingMedidasPage> {
  final TextEditingController _pesoController = TextEditingController();
  final TextEditingController _alturaController = TextEditingController();
  final TextEditingController _cinturaController = TextEditingController();
  final TextEditingController _caderaController = TextEditingController();
  final supabase = Supabase.instance.client;
  
  String? _actividadSeleccionada;
  String? _objetivoSeleccionado;
  bool _loading = false;

  // NUEVAS VARIABLES PARA CATÁLOGOS
  List<Map<String, dynamic>> _nivelesActividad = [];
  List<Map<String, dynamic>> _objetivos = [];
  bool _cargandoCatalogos = true;
  
  int? _nivelActividadId;
  int? _objetivoId;

  final Map<String, double> _factoresActividad = {
    "Sedentario (mínimo ejercicio)": 1.2,
    "Ligera (1-3 días/sem de ejercicio)": 1.375,
    "Moderada (3-5 días/sem)": 1.55,
    "Intensa (6-7 días/sem)": 1.725,
    "Muy intensa (entrenamiento diario)": 1.9,
  };

  final Map<String, double> _ajustesObjetivo = {
    "Déficit calórico (pérdida de grasa)": -500,
    "Recomposición corporal": -300,
    "Mantenimiento": 0,
    "Superávit (ganancia muscular)": 400,
  };

  @override
  void initState() {
    super.initState();
    _cargarCatalogos();
  }

  // NUEVO MÉTODO PARA CARGAR CATÁLOGOS
  Future<void> _cargarCatalogos() async {
    try {
      // Cargar niveles de actividad
      final nivelesResponse = await supabase
          .from('cat_niveles_actividad')
          .select('id, codigo, descripcion, factor_actividad')
          .order('id');

      // Cargar objetivos
      final objetivosResponse = await supabase
          .from('cat_objetivos_nutricionales')
          .select('id, codigo, descripcion, ajuste_calorico')
          .order('id');

      setState(() {
        _nivelesActividad = List<Map<String, dynamic>>.from(nivelesResponse);
        _objetivos = List<Map<String, dynamic>>.from(objetivosResponse);
        _cargandoCatalogos = false;
      });
    } catch (e) {
      setState(() {
        _cargandoCatalogos = false;
      });
      
      // Fallback: valores hardcodeados
      setState(() {
        _nivelesActividad = [
          {'id': 1, 'codigo': 'sedentario', 'descripcion': 'Sedentario (mínimo ejercicio)', 'factor_actividad': 1.2},
          {'id': 2, 'codigo': 'ligera', 'descripcion': 'Ligera (1-3 días/sem de ejercicio)', 'factor_actividad': 1.375},
          {'id': 3, 'codigo': 'moderada', 'descripcion': 'Moderada (3-5 días/sem)', 'factor_actividad': 1.55},
          {'id': 4, 'codigo': 'intensa', 'descripcion': 'Intensa (6-7 días/sem)', 'factor_actividad': 1.725},
          {'id': 5, 'codigo': 'muy_intensa', 'descripcion': 'Muy intensa (entrenamiento diario)', 'factor_actividad': 1.9},
        ];
        
        _objetivos = [
          {'id': 1, 'codigo': 'deficit', 'descripcion': 'Déficit calórico (pérdida de grasa)', 'ajuste_calorico': -500},
          {'id': 2, 'codigo': 'recomposicion', 'descripcion': 'Recomposición corporal', 'ajuste_calorico': -300},
          {'id': 3, 'codigo': 'mantenimiento', 'descripcion': 'Mantenimiento', 'ajuste_calorico': 0},
          {'id': 4, 'codigo': 'superavit', 'descripcion': 'Superávit (ganancia muscular)', 'ajuste_calorico': 400},
        ];
      });
    }
  }

  int _calcularEdad(String fechaNacStr) {
    try {
      final fechaNac = DateTime.parse(fechaNacStr);
      final hoy = DateTime.now();
      int edad = hoy.year - fechaNac.year;
      if (hoy.month < fechaNac.month || (hoy.month == fechaNac.month && hoy.day < fechaNac.day)) {
        edad--;
      }
      return edad;
    } catch (e) {
      return 0;
    }
  }

  double _calcularTMB(double peso, double altura, int edad, String sexo) {
    if (sexo.toLowerCase() == "hombre" || sexo.toLowerCase() == "masculino") {
      return 66 + (13.7 * peso) + (5 * altura) - (6.8 * edad);
    } else {
      return 655 + (9.6 * peso) + (1.8 * altura) - (4.7 * edad);
    }
  }

  Map<String, double> _calcularMacros(double caloriasObjetivo, String objetivo) {
    final distribucionesMacros = {
      "Déficit calórico (pérdida de grasa)": {"proteinas": 27.5, "grasas": 27.5, "carbohidratos": 45.0},
      "Superávit (ganancia muscular)": {"proteinas": 22.5, "grasas": 22.5, "carbohidratos": 52.5},
      "Mantenimiento": {"proteinas": 22.5, "grasas": 27.5, "carbohidratos": 50.0},
      "Recomposición corporal": {"proteinas": 27.5, "grasas": 27.5, "carbohidratos": 45.0},
    };

    final distribucion = distribucionesMacros[objetivo] ?? distribucionesMacros["Mantenimiento"]!;
    
    final caloriasProteinas = (caloriasObjetivo * distribucion["proteinas"]!) / 100;
    final caloriasGrasas = (caloriasObjetivo * distribucion["grasas"]!) / 100;
    final caloriasCarbo = (caloriasObjetivo * distribucion["carbohidratos"]!) / 100;

    return {
      "proteinas": caloriasProteinas / 4,
      "grasas": caloriasGrasas / 9,
      "carbohidratos": caloriasCarbo / 4,
    };
  }
  
  // --- ¡NUEVA FUNCIÓN! ---
  // Lógica de cálculo de composición corporal
  Map<String, double> _calcularComposicion(double peso, double alturaCm, double cintura, double cadera, String sexo) {
      final alturaM = alturaCm / 100;
      
      final imc = (alturaM > 0) ? (peso / (alturaM * alturaM)) : 0.0;
      
      double percentGrasa = 0.0;
      if (cintura > 0 && alturaCm > 0) {
        if (sexo.toLowerCase().startsWith('m')) { 
          percentGrasa = 86.010 * (cintura / alturaCm) - 24.38; 
        } else if (cadera > 0) { 
          percentGrasa = 163.205 * (cintura + cadera) / alturaCm - 97.604; 
        }
      }
      
      if (percentGrasa < 5) percentGrasa = 5.0; 
      if (percentGrasa > 50) percentGrasa = 50.0; 
      
      final percentMasaMagra = 100.0 - percentGrasa;

      return {
        'imc': imc,
        'porcentaje_grasa': percentGrasa,
        'porcentaje_masa_magra': percentMasaMagra,
      };
  }

  // --- FUNCIÓN _finalizar() ACTUALIZADA ---

  Future<void> _finalizar() async {
    // (Tus validaciones existentes)
    if (_pesoController.text.isEmpty || _alturaController.text.isEmpty || _actividadSeleccionada == null || _objetivoSeleccionado == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Por favor ingresa peso, altura, actividad y objetivo")),
      );
      return;
    }

    setState(() => _loading = true);

    try {
      final user = supabase.auth.currentUser;
      if (user == null) return;

      // 1. Recolectar datos
      final peso = double.parse(_pesoController.text.trim());
      final altura = double.parse(_alturaController.text.trim());
      final cintura = _cinturaController.text.trim().isEmpty ? 0.0 : double.parse(_cinturaController.text.trim());
      final cadera = _caderaController.text.trim().isEmpty ? 0.0 : double.parse(_caderaController.text.trim());

      // 2. Obtener datos básicos del usuario
      final userData = await supabase
          .from('usuarios')
          .select('nombre, sexo, fecha_nacimiento')
          .eq('id', user.id)
          .maybeSingle();

      if (userData == null) throw Exception("No se encontraron datos del usuario");
      
      String nombreUsuario = userData['nombre'] ?? "Usuario";
      String sexo = userData['sexo'] ?? "Masculino";
      String? fechaNac = userData['fecha_nacimiento'];
      int edad = fechaNac != null ? _calcularEdad(fechaNac) : 25;

      // 3. Calcular TMB, GET y calorías objetivo
      final tmb = _calcularTMB(peso, altura, edad, sexo);
      final factor = _factoresActividad[_actividadSeleccionada]!;
      final get = tmb * factor;
      final ajuste = _ajustesObjetivo[_objetivoSeleccionado]!;
      final caloriasObjetivo = get + ajuste;

      // 4. Calcular macros y porciones
      final macros = _calcularMacros(caloriasObjetivo, _objetivoSeleccionado!);
      final porcionesCarbo = macros["carbohidratos"]! / 15;
      final porcionesProteina = macros["proteinas"]! / 7;
      final porcionesGrasa = macros["grasas"]! / 5;

      // 5. Calcular composición corporal
      final composicion = _calcularComposicion(peso, altura, cintura, cadera, sexo);

      // 6. Insertar primer registro en historial_mediciones
      await supabase.from('historial_mediciones').insert({
        'usuario_id': user.id,
        'peso': peso,
        'altura': altura,
        'cintura': cintura == 0.0 ? null : cintura,
        'cadera': cadera == 0.0 ? null : cadera,
        'imc': composicion['imc'],
        'porcentaje_grasa': composicion['porcentaje_grasa'],
        'porcentaje_masa_magra': composicion['porcentaje_masa_magra'],
        'fecha_registro': DateTime.now().toIso8601String(),
      });

      // 7. GUARDAR CON IDs NORMALIZADOS + STRINGS (COMPATIBILIDAD)
      await supabase.from('usuarios').update({
        'peso': peso,
        'altura': altura,
        'cintura': _cinturaController.text.trim().isEmpty ? null : double.parse(_cinturaController.text.trim()),
        'cadera': _caderaController.text.trim().isEmpty ? null : double.parse(_caderaController.text.trim()),
        
        // LEGACY (strings) - para compatibilidad
        'nivel_actividad': _actividadSeleccionada,
        'factor_actividad': factor,
        'objetivo_nutricional': _objetivoSeleccionado,
        
        // NUEVOS CAMPOS NORMALIZADOS (IDs)
        'nivel_actividad_id': _nivelActividadId,
        'objetivo_nutricional_id': _objetivoId,
        
        'tmb': tmb.round(),
        'get_calorico': get.round(),
        'calorias_objetivo': caloriasObjetivo.round(),
        'proteinas_gramos': macros["proteinas"]!.round(),
        'carbohidratos_gramos': macros["carbohidratos"]!.round(),
        'grasas_gramos': macros["grasas"]!.round(),
        'porciones_carbo': porcionesCarbo.round(),
        'porciones_proteina': porcionesProteina.round(),
        'porciones_grasa': porcionesGrasa.round(),
        'numero_comidas': 3,
        'onboarding_completo': true,
        // (OPCIONAL: Si quieres guardar el valor más reciente también en la tabla 'usuarios')
        // 'imc': composicion['imc'],
        // 'porcentaje_grasa': composicion['porcentaje_grasa'],
        // 'porcentaje_masa_magra': composicion['porcentaje_masa_magra'],
      }).eq('id', user.id);

      try {
        await http.post(
          Uri.parse('https://fitchi-backend-398799029559.southamerica-west1.run.app/api/inicializar-menu-usuario'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'user_id': user.id, 'tipo_comida': 'desayuno'}),
        );
      } catch (e) {
      }

      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => HomeScreen(userName: nombreUsuario)),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    } finally {
      setState(() => _loading = false);
    }
  }

  // --- WIDGET BUILD ---
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/onboarding_bg3.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Container(
          decoration: BoxDecoration(color: Colors.black.withOpacity(0.4)),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // (Tu UI de barra de progreso)
                  Row(
                    children: [
                      Expanded(child: Container(height: 4, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(2)))),
                      const SizedBox(width: 4),
                      Expanded(child: Container(height: 4, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(2)))),
                      const SizedBox(width: 4),
                      Expanded(child: Container(height: 4, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(2)))),
                    ],
                  ),
                  const SizedBox(height: 40),
                  // (Tu UI de Header)
                  Row(
                    children: [
                      IconButton(icon: const Icon(Icons.arrow_back, color: Colors.white), onPressed: () => Navigator.pop(context)),
                      const Expanded(child: Text("Medidas físicas", style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold))),
                    ],
                  ),
                  const SizedBox(height: 10),
                  const Text("Paso 3 de 3", style: TextStyle(color: Colors.white70, fontSize: 16)),
                  const SizedBox(height: 40),
                  
                  // (Tu UI de Campos de Texto)
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _buildTextField(label: "Peso (kg)", controller: _pesoController, required: true),
                          const SizedBox(height: 20),
                          _buildTextField(label: "Altura (cm)", controller: _alturaController, required: true),
                          const SizedBox(height: 20),
                          _buildTextField(label: "Cintura (cm)", controller: _cinturaController, required: false),
                          const SizedBox(height: 20),
                          _buildTextField(label: "Cadera (cm)", controller: _caderaController, required: false),
                          const SizedBox(height: 30),
                          
                          // DROPDOWN NIVEL DE ACTIVIDAD - ACTUALIZADO
                          const Text("Nivel de actividad física *", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 10),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(15)),
                            child: _cargandoCatalogos
                                ? const Center(
                                    child: Padding(
                                      padding: EdgeInsets.all(16.0),
                                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                                    ),
                                  )
                                : DropdownButton<String>(
                                    value: _actividadSeleccionada,
                                    isExpanded: true,
                                    hint: const Text("Selecciona tu nivel", style: TextStyle(color: Colors.white70)),
                                    dropdownColor: Colors.grey[900],
                                    style: const TextStyle(color: Colors.white),
                                    underline: Container(),
                                    items: _nivelesActividad.map((nivel) {
                                      return DropdownMenuItem<String>(
                                        value: nivel['descripcion'],
                                        child: Text(nivel['descripcion'], style: const TextStyle(fontSize: 14)),
                                        onTap: () {
                                          setState(() {
                                            _nivelActividadId = nivel['id'];
                                          });
                                        },
                                      );
                                    }).toList(),
                                    onChanged: (value) => setState(() => _actividadSeleccionada = value),
                                  ),
                          ),
                          const SizedBox(height: 20),
                          
                          // DROPDOWN OBJETIVO - ACTUALIZADO
                          const Text("Objetivo nutricional *", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 10),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(15)),
                            child: _cargandoCatalogos
                                ? const Center(
                                    child: Padding(
                                      padding: EdgeInsets.all(16.0),
                                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                                    ),
                                  )
                                : DropdownButton<String>(
                                    value: _objetivoSeleccionado,
                                    isExpanded: true,
                                    hint: const Text("Selecciona tu objetivo", style: TextStyle(color: Colors.white70)),
                                    dropdownColor: Colors.grey[900],
                                    style: const TextStyle(color: Colors.white),
                                    underline: Container(),
                                    items: _objetivos.map((objetivo) {
                                      return DropdownMenuItem<String>(
                                        value: objetivo['descripcion'],
                                        child: Text(objetivo['descripcion'], style: const TextStyle(fontSize: 14)),
                                        onTap: () {
                                          setState(() {
                                            _objetivoId = objetivo['id'];
                                          });
                                        },
                                      );
                                    }).toList(),
                                    onChanged: (value) => setState(() => _objetivoSeleccionado = value),
                                  ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  
                  // (Tu UI de Botón)
                  _loading
                      ? const Center(child: CircularProgressIndicator(color: Colors.white))
                      : ElevatedButton(
                          onPressed: _finalizar,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF66BB6A),
                            foregroundColor: Colors.black,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                            elevation: 8,
                          ),
                          child: const Text("Finalizar", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // (Tu widget _buildTextField sin cambios)
  Widget _buildTextField({required String label, required TextEditingController controller, required bool required}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(label, style: const TextStyle(color: Colors.white, fontSize: 16)),
            if (required) const Text(" *", style: TextStyle(color: Colors.red, fontSize: 16)),
          ],
        ),
        const SizedBox(height: 10),
        TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            filled: true,
            fillColor: Colors.white.withOpacity(0.2),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
            hintText: required ? "Requerido" : "Opcional",
            hintStyle: TextStyle(color: Colors.white.withOpacity(0.5)),
          ),
        ),
      ],
    );
  }
}