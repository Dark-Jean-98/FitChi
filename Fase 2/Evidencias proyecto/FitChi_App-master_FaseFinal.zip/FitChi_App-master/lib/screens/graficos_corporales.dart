import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:fl_chart/fl_chart.dart'; 
import 'custom_bottom_nav.dart'; 
import 'edit_profile.dart'; 

class GraficosCorporalesPage extends StatefulWidget {
  const GraficosCorporalesPage({super.key});

  @override
  State<GraficosCorporalesPage> createState() => _GraficosCorporalesPageState();
}

class _GraficosCorporalesPageState extends State<GraficosCorporalesPage> {
  static const Color verdeApp = Color(0xFF66BB6A);
  final supabase = Supabase.instance.client;
  String? _avatarUrl;

  @override
  void initState() {
    super.initState();
    _cargarAvatar();
  }

  Future<void> _cargarAvatar() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final data = await supabase
          .from('usuarios')
          .select('avatar_url')
          .eq('id', user.id)
          .single();

      if (mounted) {
        setState(() {
          _avatarUrl = data['avatar_url'];
        });
      }
    } catch (e) {
      // Error silencioso
    }
  }

  // --- ¡FUNCIÓN DE FETCH CORREGIDA! ---
  // Ahora lee el historial real de Supabase
  Future<Map<String, dynamic>?> _fetchAndCalculateData() async {
    final user = supabase.auth.currentUser;
    if (user == null) return null;

    try {
      // 1. Obtener el historial real de Supabase
      final historialData = await supabase
          .from('historial_mediciones')
          .select()
          .eq('usuario_id', user.id)
          .order('fecha_registro', ascending: true); // ¡Ordenado por fecha!

      if (historialData.isEmpty) {
        // Si no hay historial (ej. usuario antiguo que aún no guarda),
        // mostramos un estado vacío.
        return {
          'imc_actual': 'N/A',
          'grasa_actual': 'N/A',
          'magra_actual': 'N/A',
          'historial': [], // Lista vacía
        };
      }

      // 2. Procesar el historial para el gráfico y la tabla
      final List<Map<String, dynamic>> historialProcesado = [];
      for (var reg in historialData) {
        // Parseamos la fecha que viene de Supabase
        final fecha = DateTime.parse(reg['fecha_registro']);
        
        historialProcesado.add({
          // Formato para las etiquetas del gráfico (ej: "7/11")
          'fecha': "${fecha.day}/${fecha.month}", 
          // Formato para la tabla (ej: "7/11/2025")
          'fecha_completa': "${fecha.day}/${fecha.month}/${fecha.year}", 
          'imc': reg['imc']?.toStringAsFixed(1) ?? '0',
          'grasa': reg['porcentaje_grasa']?.toStringAsFixed(1) ?? '0',
          'magra': reg['porcentaje_masa_magra']?.toStringAsFixed(1) ?? '0',
        });
      }
      
      // 3. Obtener los valores actuales (del último registro que encontramos)
      final ultimoRegistro = historialProcesado.last;
      
      return {
        'imc_actual': ultimoRegistro['imc'],
        'grasa_actual': ultimoRegistro['grasa'],
        'magra_actual': ultimoRegistro['magra'],
        'historial': historialProcesado,
      };

    } catch (e) {
      // Manejar el error
      return {
        'imc_actual': 'Error',
        'grasa_actual': 'Error',
        'magra_actual': 'Error',
        'historial': [],
      };
    }
  }

  // --- El resto del archivo (build, widgets, etc.) sin cambios ---
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        automaticallyImplyLeading: false,
        title: Row(
          children: [
            CircleAvatar(
              radius: 18,
              backgroundColor: verdeApp,
              backgroundImage: _avatarUrl != null && _avatarUrl!.isNotEmpty
                  ? NetworkImage(_avatarUrl!)
                  : null,
              child: _avatarUrl == null || _avatarUrl!.isEmpty
                  ? const Icon(Icons.person, color: Colors.white, size: 20)
                  : null,
            ),
            const SizedBox(width: 12),
            const Text(
              'Composición Corporal',
              style: TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
      body: FutureBuilder<Map<String, dynamic>?>(
        future: _fetchAndCalculateData(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: verdeApp));
          }
          
          final data = snapshot.data ?? {};

          final imcActual = data['imc_actual'] ?? 'N/A';
          final grasaActual = data['grasa_actual'] ?? 'N/A';
          final magraActual = data['magra_actual'] ?? 'N/A';
          final historial = (data['historial'] as List<dynamic>?)
              ?.map((e) => e as Map<String, dynamic>)
              .toList() ?? [];

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                _buildMetricsRow(imcActual, grasaActual, magraActual),
                const SizedBox(height: 16),
                
                // Si no hay historial, muestra un placeholder, si no, el gráfico
                historial.isEmpty
                  ? _buildEmptyChartPlaceholder()
                  : _buildHistoricalChartCard(context, historial),
                
                const SizedBox(height: 16),
                _buildDetailTable(historial),
                const SizedBox(height: 16),
                _buildRegisterButton(context),
                const SizedBox(height: 80),
              ],
            ),
          );
        },
      ),
      bottomNavigationBar: const CustomBottomNav(currentIndex: 0),
    );
  }

  Widget _buildMetricsRow(String imc, String grasa, String magra) {
    // (Este widget no cambia)
    return Row(
      children: [
        Expanded(child: _buildMetricCard("IMC", imc, "N/A", Colors.blue)),
        const SizedBox(width: 12),
        Expanded(child: _buildMetricCard("% Grasa", "$grasa%", "N/A", Colors.redAccent)),
        const SizedBox(width: 12),
        Expanded(child: _buildMetricCard("% M. Magra", "$magra%", "N/A", verdeApp)),
      ],
    );
  }

  Widget _buildMetricCard(String title, String value, String change, Color color) {
    // (Este widget no cambia)
    bool isPositive = change.startsWith('▲');
    
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: Colors.white70, fontSize: 12)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(
            change,
            style: TextStyle(
              color: change == 'N/A' ? Colors.white70 : (isPositive ? verdeApp : Colors.redAccent),
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyChartPlaceholder() {
    // (Este widget no cambia)
    return Container(
      width: double.infinity,
      height: 280, 
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(16),
      ),
      child: const Center(
        child: Text(
          'No hay datos históricos. \n¡Registra tus medidas para ver tu evolución!',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white70, fontSize: 14, height: 1.5),
        ),
      ),
    );
  }

  Widget _buildHistoricalChartCard(BuildContext context, List<Map<String, dynamic>> historial) {
    // (Este widget no cambia)
    
    List<FlSpot> imcSpots = [];
    List<FlSpot> grasaSpots = [];
    List<FlSpot> magraSpots = [];
    List<String> xLabels = [];

    for (int i = 0; i < historial.length; i++) {
        final reg = historial[i];
        final double imc = double.tryParse(reg['imc'] ?? '0') ?? 0;
        final double grasa = double.tryParse(reg['grasa'] ?? '0') ?? 0;
        final double magra = double.tryParse(reg['magra'] ?? '0') ?? 0;
        
        imcSpots.add(FlSpot(i.toDouble(), imc));
        grasaSpots.add(FlSpot(i.toDouble(), grasa));
        magraSpots.add(FlSpot(i.toDouble(), magra));
        
        xLabels.add(reg['fecha']!); // Usa la fecha corta (ej: "7/11")
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Evolución de Composición",
            style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          
          SizedBox(
            height: 200,
            child: LineChart(
              LineChartData(
                minY: 0,
                maxY: 100,
                backgroundColor: Colors.transparent,
                
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: true,
                  horizontalInterval: 20, 
                  verticalInterval: 1, 
                  getDrawingHorizontalLine: (value) {
                    return const FlLine(color: Colors.white24, strokeWidth: 0.5);
                  },
                  getDrawingVerticalLine: (value) {
                    return const FlLine(color: Colors.white24, strokeWidth: 0.5);
                  },
                ),
                
                borderData: FlBorderData(
                  show: true,
                  border: const Border(
                    bottom: BorderSide(color: Colors.white24, width: 1),
                    left: BorderSide(color: Colors.white24, width: 1),
                  ),
                ),
                
                titlesData: FlTitlesData(
                  show: true,
                  rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 30, 
                      interval: 20, 
                      getTitlesWidget: (value, meta) {
                        return Text(
                          value.toInt().toString(), 
                          style: const TextStyle(color: Colors.white70, fontSize: 10),
                          textAlign: TextAlign.right,
                        );
                      },
                    ),
                  ),
                  
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 22,
                      interval: 1,
                      getTitlesWidget: (value, meta) {
                        final index = value.toInt();
                        if (index >= 0 && index < xLabels.length) {
                          return Padding(
                            padding: const EdgeInsets.only(top: 8.0),
                            child: Text(
                              xLabels[index], 
                              style: const TextStyle(color: Colors.white70, fontSize: 10),
                            ),
                          );
                        }
                        return const Text('');
                      },
                    ),
                  ),
                ),

                lineTouchData: LineTouchData(
                  touchTooltipData: LineTouchTooltipData(
                    tooltipBgColor: Colors.black.withOpacity(0.8),
                    getTooltipItems: (touchedSpots) {
                      return touchedSpots.map((spot) {
                        String label = '';
                        if (spot.barIndex == 0) label = 'M. Magra:';
                        if (spot.barIndex == 1) label = 'Grasa:';
                        if (spot.barIndex == 2) label = 'IMC:';
                        
                        return LineTooltipItem(
                          '$label ${spot.y.toStringAsFixed(1)}',
                          const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12),
                        );
                      }).toList();
                    },
                  ),
                ),

                lineBarsData: [
                  _buildLineBarData(magraSpots, verdeApp), 
                  _buildLineBarData(grasaSpots, Colors.redAccent),
                  _buildLineBarData(imcSpots, Colors.blueAccent), 
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildLegendItem("Masa Magra", verdeApp),
              _buildLegendItem("Grasa", Colors.redAccent),
              _buildLegendItem("IMC", Colors.blueAccent),
            ],
          ),
        ],
      ),
    );
  }
  
  LineChartBarData _buildLineBarData(List<FlSpot> spots, Color color) {
    // (Este widget no cambia)
    return LineChartBarData(
      spots: spots,
      isCurved: true, 
      color: color,
      barWidth: 4,
      isStrokeCapRound: true,
      dotData: const FlDotData(show: false), 
      belowBarData: BarAreaData( 
        show: true,
        color: color.withOpacity(0.2),
      ),
    );
  }
  
  Widget _buildDetailTable(List<Map<String, dynamic>> historial) {
    // (Este widget no cambia)
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.list_alt, color: verdeApp, size: 24),
              const SizedBox(width: 8),
              const Text(
                "Historial de Registros",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ],
          ),
          const Divider(height: 24),
          _buildTableRow("Fecha", "IMC", "% Grasa", "% M. Magra", isHeader: true),
          
          if (historial.isEmpty)
            _buildTableRow("No hay", "datos", "históricos", "aún", isPlaceholder: true)
          else
            // Usamos 'fecha_completa' y .reversed para mostrar el más nuevo arriba
            ...historial.reversed.map((reg) => _buildTableRow( 
              reg['fecha_completa']!, reg['imc']!, reg['grasa']!, reg['magra']!
            )).toList(),
        ],
      ),
    );
  }

  Widget _buildTableRow(String date, String imc, String fat, String lean, {bool isHeader = false, bool isPlaceholder = false}) {
    // (Este widget no cambia)
    TextStyle style = isHeader 
        ? const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)
        : (isPlaceholder 
            ? const TextStyle(fontSize: 14, color: Colors.grey)
            : const TextStyle(fontSize: 14));

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Expanded(flex: 2, child: Text(date, style: style)),
          Expanded(flex: 1, child: Text(imc, style: style, textAlign: TextAlign.center)),
          Expanded(flex: 2, child: Text(fat, style: style, textAlign: TextAlign.center)),
          Expanded(flex: 2, child: Text(lean, style: style, textAlign: TextAlign.center)),
        ],
      ),
    );
  }

  Widget _buildLegendItem(String label, Color color) {
    // (Este widget no cambia)
    return Row(
      children: [
        Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
        const SizedBox(width: 4),
        Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11)),
      ],
    );
  }

  Widget _buildRegisterButton(BuildContext context) {
    // (Este widget no cambia)
    return InkWell(
      onTap: () {
        Navigator.push(
          context, 
          MaterialPageRoute(builder: (_) => const EditProfilePage())
        ).then((_) {
          // Refresca el FutureBuilder cuando vuelve de guardar
          setState(() {});
        });
      },
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: verdeApp.withOpacity(0.2), borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.add_chart, color: verdeApp, size: 28),
            ),
            const SizedBox(width: 16),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Registrar nuevas medidas", style: TextStyle(color: Colors.black, fontSize: 16, fontWeight: FontWeight.bold)),
                  SizedBox(height: 4),
                  Text("Actualiza tu peso, altura y circunferencias", style: TextStyle(color: Colors.grey, fontSize: 12)),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios, color: Colors.grey, size: 20),
          ],
        ),
      ),
    );
  }
}