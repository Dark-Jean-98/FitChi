import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'custom_bottom_nav.dart';

class HistorialPage extends StatefulWidget {
  const HistorialPage({super.key});

  @override
  State<HistorialPage> createState() => _HistorialPageState();
}

class _HistorialPageState extends State<HistorialPage> with SingleTickerProviderStateMixin {
  final supabase = Supabase.instance.client;
  final String baseUrl = "https://fitchi-backend-398799029559.southamerica-west1.run.app";
  static const Color verdeApp = Color(0xFF66BB6A);

  late TabController _tabController;
  List<Map<String, dynamic>> todasLasRecetas = [];
  List<Map<String, dynamic>> recetasFiltradas = [];
  bool _cargando = true;
  final TextEditingController _searchController = TextEditingController();
  String? _avatarUrl;

  // Lista de compras
  List<Map<String, dynamic>> _listaCompras = [];
  bool _cargandoLista = true;
  int _semanaOffsetLista = 0; // 0 = semana actual, 1 = próxima semana

  // Almacenar favoritos localmente en memoria
  static final Set<String> _favoritosLocales = {};
  static String? _ultimoUsuarioId;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _inicializar();
    _searchController.addListener(_filtrarRecetas);
  }

  Future<void> _inicializar() async {
    // Cargar favoritos primero, luego el historial
    await _cargarFavoritosLocales();
    await _cargarAvatar();
    await _cargarHistorial();
    await _cargarListaCompras();
  }

  Future<void> _cargarListaCompras() async {
    setState(() => _cargandoLista = true);

    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/lista-compras/${user.id}?semana_offset=$_semanaOffsetLista'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _listaCompras = List<Map<String, dynamic>>.from(data['ingredientes'] ?? []);
          _cargandoLista = false;
        });
      } else {
        setState(() => _cargandoLista = false);
      }
    } catch (e) {
      setState(() => _cargandoLista = false);
    }
  }

  Future<void> _toggleCheckIngrediente(String ingredienteId, bool completado) async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      await http.post(
        Uri.parse('$baseUrl/api/lista-compras/toggle'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'user_id': user.id,
          'ingrediente_id': ingredienteId,
          'completado': completado,
        }),
      );

      // Actualizar localmente
      setState(() {
        final index = _listaCompras.indexWhere((item) => item['id'] == ingredienteId);
        if (index != -1) {
          _listaCompras[index]['completado'] = completado;
        }
      });
    } catch (e) {
      // Error silencioso
    }
  }

  Future<void> _cargarAvatar() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final data = await supabase
          .from('usuarios')
          .select('avatar_url')
          .eq('id', user.id)
          .single();

      if (mounted) {
        setState(() {
          _avatarUrl = data['avatar_url'];
        });
      }
    } catch (e) {
      // Error silencioso
    }
  }

  Future<void> _cargarFavoritosLocales() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    if (_ultimoUsuarioId != null && _ultimoUsuarioId != user.id) {
      _favoritosLocales.clear();
    }
    _ultimoUsuarioId = user.id;
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _cargarHistorial() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    setState(() => _cargando = true);

    try {
      // Cargar desde el endpoint del backend
      final response = await http.get(
        Uri.parse('$baseUrl/api/historial-recetas/${user.id}'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final recetas = List<Map<String, dynamic>>.from(data['recetas']);

        // Sincronizar el estado de favoritos desde Supabase
        await _sincronizarFavoritos(recetas);

        setState(() {
          todasLasRecetas = recetas;
          recetasFiltradas = todasLasRecetas;
          _cargando = false;
        });
      } else {
        setState(() => _cargando = false);
      }
    } catch (e) {
      setState(() => _cargando = false);
    }
  }

  Future<void> _sincronizarFavoritos(List<Map<String, dynamic>> recetas) async {
    _favoritosLocales.clear();

    try {
      final recetaIds = recetas.map((r) => r['id']).where((id) => id != null).toList();

      if (recetaIds.isEmpty) return;

      final favoritosData = await supabase
          .from('recetas')
          .select('id, is_favorito')
          .inFilter('id', recetaIds);

      final Map<int, bool> favoritosMap = {};
      for (var item in favoritosData) {
        final id = item['id'] as int?;
        final isFav = item['is_favorito'] == true;
        if (id != null) {
          favoritosMap[id] = isFav;
          if (isFav) {
            _favoritosLocales.add(id.toString());
          }
        }
      }

      for (var receta in recetas) {
        final recetaId = receta['id'];
        if (recetaId != null) {
          final isFavorito = favoritosMap[recetaId] ?? false;
          receta['is_favorito'] = isFavorito;
        }
      }
    } catch (e) {
      for (var receta in recetas) {
        final recetaId = receta['id']?.toString() ?? '';
        final isFavorito = receta['is_favorito'] == true;
        if (isFavorito) {
          _favoritosLocales.add(recetaId);
        }
      }
    }
  }

  void _filtrarRecetas() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      if (query.isEmpty) {
        recetasFiltradas = todasLasRecetas;
      } else {
        recetasFiltradas = todasLasRecetas.where((receta) {
          final nombre = receta['nombre']?.toString().toLowerCase() ?? '';
          final tipoComida = receta['tipo_comida']?.toString().toLowerCase() ?? '';
          return nombre.contains(query) || tipoComida.contains(query);
        }).toList();
      }
    });
  }

  Future<void> _toggleFavorito(Map<String, dynamic> receta) async {
    try {
      final recetaId = receta['id']?.toString() ?? '';
      final nuevoEstado = !(receta['is_favorito'] ?? false);

      // Actualizar en el almacenamiento local
      if (nuevoEstado) {
        _favoritosLocales.add(recetaId);
      } else {
        _favoritosLocales.remove(recetaId);
      }

      // Actualizar en Supabase (BASE DE DATOS)
      try {
        await supabase
            .from('historial_recetas')
            .update({'is_favorito': nuevoEstado})
            .eq('id', receta['id']);

        print('✅ Favorito guardado en Supabase: receta_id=${receta['id']}, is_favorito=$nuevoEstado');
      } catch (e) {
        print('❌ Error al guardar favorito en Supabase: $e');

        // Revertir cambio local si falla Supabase
        if (nuevoEstado) {
          _favoritosLocales.remove(recetaId);
        } else {
          _favoritosLocales.add(recetaId);
        }

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error al guardar en base de datos: $e'),
              backgroundColor: Colors.orange,
              duration: const Duration(seconds: 3),
            ),
          );
        }
        return; // No actualizar UI si falló
      }

      // Actualizar el estado local
      setState(() {
        final index = todasLasRecetas.indexWhere((r) => r['id'] == receta['id']);
        if (index != -1) {
          todasLasRecetas[index]['is_favorito'] = nuevoEstado;
        }
        _filtrarRecetas();
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(nuevoEstado ? 'Agregado a favoritos' : 'Eliminado de favoritos'),
            duration: const Duration(seconds: 1),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error al actualizar favorito: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _mostrarTodasLasFavoritas(List<Map<String, dynamic>> favoritos) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.9,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        builder: (_, controller) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
          ),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(25)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: verdeApp.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.favorite, color: verdeApp, size: 24),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Text(
                        'Mis Favoritas',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.black),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              Expanded(
                child: GridView.builder(
                  controller: controller,
                  padding: const EdgeInsets.all(16),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 0.75,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                  ),
                  itemCount: favoritos.length,
                  itemBuilder: (context, index) {
                    return _buildRecetaCardGrid(favoritos[index]);
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            _buildTabBar(),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildRecetasTab(),
                  _buildListaComprasTab(),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: const CustomBottomNav(currentIndex: 4),
    );
  }

  Widget _buildTabBar() {
    return Container(
      color: Colors.white,
      child: TabBar(
        controller: _tabController,
        labelColor: verdeApp,
        unselectedLabelColor: Colors.grey,
        indicatorColor: verdeApp,
        labelStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        tabs: const [
          Tab(text: 'Recetas'),
          Tab(text: 'Lista de Compras'),
        ],
      ),
    );
  }

  Widget _buildRecetasTab() {
    return Column(
      children: [
        _buildSearchBar(),
        if (_cargando)
          const Expanded(
            child: Center(child: CircularProgressIndicator()),
          )
        else
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildFavoritosSection(),
                  const SizedBox(height: 24),
                  _buildUltimasComidasSection(),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildListaComprasTab() {
    return Column(
      children: [
        _buildSelectorSemanaLista(),
        if (_cargandoLista)
          const Expanded(child: Center(child: CircularProgressIndicator(color: verdeApp)))
        else if (_listaCompras.isEmpty)
          Expanded(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(32.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.shopping_cart_outlined, size: 100, color: Colors.grey[400]),
                    const SizedBox(height: 24),
                    const Text(
                      'No hay ingredientes',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _semanaOffsetLista == 0
                          ? 'Genera recetas para esta semana y automáticamente se creará tu lista de compras'
                          : 'Genera recetas para la próxima semana y automáticamente se creará tu lista de compras',
                      style: const TextStyle(fontSize: 14, color: Colors.grey),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          )
        else
          Expanded(child: _buildListaComprasContent()),
      ],
    );
  }

  Widget _buildSelectorSemanaLista() {
    final DateTime ahora = DateTime.now();
    final DateTime proximaSemana = ahora.add(const Duration(days: 7));

    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFF2D2D2D),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[800]!),
      ),
      child: Row(
        children: [
          Expanded(
            child: _buildBotonSemanaLista(
              texto: 'Esta Semana',
              subtexto: '${ahora.day}/${ahora.month}',
              seleccionada: _semanaOffsetLista == 0,
              onTap: () {
                if (_semanaOffsetLista != 0) {
                  setState(() {
                    _semanaOffsetLista = 0;
                  });
                  _cargarListaCompras();
                }
              },
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: _buildBotonSemanaLista(
              texto: 'Próxima Semana',
              subtexto: '${proximaSemana.day}/${proximaSemana.month}',
              seleccionada: _semanaOffsetLista == 1,
              onTap: () {
                if (_semanaOffsetLista != 1) {
                  setState(() {
                    _semanaOffsetLista = 1;
                  });
                  _cargarListaCompras();
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBotonSemanaLista({
    required String texto,
    required String subtexto,
    required bool seleccionada,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
        decoration: BoxDecoration(
          color: seleccionada ? verdeApp : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          children: [
            Text(
              texto,
              style: TextStyle(
                color: seleccionada ? Colors.white : Colors.grey[400],
                fontWeight: seleccionada ? FontWeight.bold : FontWeight.normal,
                fontSize: 13,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 4),
            Text(
              subtexto,
              style: TextStyle(
                color: seleccionada ? Colors.white70 : Colors.grey[500],
                fontSize: 11,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildListaComprasContent() {

    // Agrupar por categoría
    final Map<String, List<Map<String, dynamic>>> porCategoria = {};
    for (var item in _listaCompras) {
      final categoria = item['categoria'] ?? 'Otros';
      if (!porCategoria.containsKey(categoria)) {
        porCategoria[categoria] = [];
      }
      porCategoria[categoria]!.add(item);
    }

    return RefreshIndicator(
      color: verdeApp,
      onRefresh: _cargarListaCompras,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: porCategoria.length,
        itemBuilder: (context, index) {
          final categoria = porCategoria.keys.elementAt(index);
          final items = porCategoria[categoria]!;

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Text(
                  categoria,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
              ),
              ...items.map((item) => _buildIngredienteItem(item)),
              const SizedBox(height: 16),
            ],
          );
        },
      ),
    );
  }

  Widget _buildIngredienteItem(Map<String, dynamic> item) {
    final completado = item['completado'] ?? false;
    final nombre = item['nombre'] ?? '';
    final cantidad = item['cantidad'] ?? '';

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF2D2D2D),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[800]!),
      ),
      child: CheckboxListTile(
        value: completado,
        onChanged: (value) {
          _toggleCheckIngrediente(item['id'], value ?? false);
        },
        title: Text(
          nombre,
          style: TextStyle(
            fontSize: 16,
            color: completado ? Colors.grey[500] : Colors.white,
            decoration: completado ? TextDecoration.lineThrough : null,
          ),
        ),
        subtitle: cantidad.isNotEmpty
            ? Text(
                cantidad,
                style: TextStyle(
                  fontSize: 14,
                  color: completado ? Colors.grey[600] : Colors.grey[300],
                ),
              )
            : null,
        activeColor: verdeApp,
        controlAffinity: ListTileControlAffinity.leading,
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      color: Colors.white,
      child: Row(
        children: [
          CircleAvatar(
            radius: 21,
            backgroundColor: verdeApp,
            backgroundImage: _avatarUrl != null && _avatarUrl!.isNotEmpty
                ? NetworkImage(_avatarUrl!)
                : null,
            child: _avatarUrl == null || _avatarUrl!.isEmpty
                ? const Icon(Icons.person, color: Colors.white, size: 24)
                : null,
          ),
          const SizedBox(width: 12),
          const Text(
            'Historial',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      padding: const EdgeInsets.all(16),
      color: Colors.white,
      child: TextField(
        controller: _searchController,
        style: const TextStyle(color: Colors.black),
        decoration: InputDecoration(
          hintText: 'Buscar...',
          hintStyle: TextStyle(color: Colors.grey[500]),
          prefixIcon: Icon(Icons.search, color: Colors.grey[500]),
          filled: true,
          fillColor: Colors.grey[100],
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(30),
            borderSide: BorderSide.none,
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 0),
        ),
      ),
    );
  }

  Widget _buildFavoritosSection() {
    final favoritos = recetasFiltradas.where((r) => r['is_favorito'] == true).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Text(
            'Favoritos',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (favoritos.isEmpty)
          Padding(
            padding: const EdgeInsets.all(20),
            child: Center(
              child: Text(
                'No tienes favoritos aún',
                style: TextStyle(color: Colors.grey[600], fontSize: 14),
              ),
            ),
          )
        else
          SizedBox(
            height: 160,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: favoritos.length,
              itemBuilder: (context, index) {
                return _buildRecetaCardHorizontal(favoritos[index]);
              },
            ),
          ),
        if (favoritos.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 8, right: 20),
            child: Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () => _mostrarTodasLasFavoritas(favoritos),
                child: const Text(
                  'Ver todas las favoritas',
                  style: TextStyle(color: verdeApp, fontSize: 14),
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildRecetaCardHorizontal(Map<String, dynamic> receta) {
    return GestureDetector(
      onTap: () => _mostrarDetalleReceta(receta),
      child: Container(
        width: 160,
        margin: const EdgeInsets.only(right: 12),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                Container(
                  height: 110,
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: receta['imagen_url'] != null
                        ? Image.network(
                            receta['imagen_url'],
                            fit: BoxFit.cover,
                            width: double.infinity,
                            errorBuilder: (context, error, stackTrace) {
                              return Container(
                                color: Colors.grey[200],
                                child: Icon(Icons.restaurant, size: 40, color: Colors.grey[400]),
                              );
                            },
                          )
                        : Container(
                            color: Colors.grey[200],
                            child: Icon(Icons.restaurant, size: 40, color: Colors.grey[400]),
                          ),
                  ),
                ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: GestureDetector(
                    onTap: () => _toggleFavorito(receta),
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: verdeApp,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.check,
                        color: Colors.white,
                        size: 16,
                      ),
                    ),
                  ),
                ),
                Positioned(
                  bottom: 8,
                  left: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.7),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(_getTipoComidaIcon(receta['tipo_comida'] ?? ''),
                          color: verdeApp, size: 12),
                        const SizedBox(width: 4),
                        Text(
                          _getTipoComidaNombre(receta['tipo_comida'] ?? ''),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Flexible(
              child: Text(
                receta['nombre'] ?? '',
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Colors.black,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const SizedBox(height: 2),
            if (receta['calorias'] != null)
              Row(
                children: [
                  Icon(Icons.local_fire_department, size: 12, color: Colors.orange[400]),
                  const SizedBox(width: 4),
                  Flexible(
                    child: Text(
                      '${receta['calorias']} kcal',
                      style: TextStyle(
                        fontSize: 10,
                        color: Colors.grey[600],
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildUltimasComidasSection() {
    final ultimasComidas = recetasFiltradas.where((r) => r['is_favorito'] != true).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Text(
            'Últimas comidas',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (ultimasComidas.isEmpty)
          Padding(
            padding: const EdgeInsets.all(20),
            child: Center(
              child: Text(
                'No hay recetas en el historial',
                style: TextStyle(color: Colors.grey[600], fontSize: 14),
              ),
            ),
          )
        else
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 16),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 0.75,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
            ),
            itemCount: ultimasComidas.length > 8 ? 8 : ultimasComidas.length,
            itemBuilder: (context, index) {
              return _buildRecetaCardGrid(ultimasComidas[index]);
            },
          ),
      ],
    );
  }

  Widget _buildRecetaCardGrid(Map<String, dynamic> receta) {
    final isFavorito = receta['is_favorito'] == true;
    final DateTime? createdAt = receta['created_at'] != null
        ? DateTime.parse(receta['created_at'])
        : null;
    final String fechaTexto = createdAt != null
        ? '${createdAt.day}/${createdAt.month}/${createdAt.year}'
        : '';

    return GestureDetector(
      onTap: () => _mostrarDetalleReceta(receta),
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF1C1C1E),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                Container(
                  height: 120,
                  decoration: BoxDecoration(
                    color: Colors.grey[850],
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(12),
                      topRight: Radius.circular(12),
                    ),
                  ),
                  child: ClipRRect(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(12),
                      topRight: Radius.circular(12),
                    ),
                    child: receta['imagen_url'] != null
                        ? Image.network(
                            receta['imagen_url'],
                            fit: BoxFit.cover,
                            width: double.infinity,
                            errorBuilder: (context, error, stackTrace) {
                              return Container(
                                color: Colors.grey[850],
                                child: Icon(Icons.restaurant, size: 40, color: Colors.grey[600]),
                              );
                            },
                          )
                        : Container(
                            color: Colors.grey[850],
                            child: Icon(Icons.restaurant, size: 40, color: Colors.grey[600]),
                          ),
                  ),
                ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: GestureDetector(
                    onTap: () => _toggleFavorito(receta),
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: isFavorito ? verdeApp : Colors.grey[800],
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        isFavorito ? Icons.favorite : Icons.favorite_border,
                        color: isFavorito ? Colors.white : Colors.grey[400],
                        size: 18,
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: 8,
                  left: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.7),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(_getTipoComidaIcon(receta['tipo_comida'] ?? ''),
                          color: verdeApp, size: 12),
                        const SizedBox(width: 4),
                        Text(
                          _getTipoComidaNombre(receta['tipo_comida'] ?? ''),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    receta['nombre'] ?? '',
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      if (receta['calorias'] != null)
                        Row(
                          children: [
                            Icon(Icons.local_fire_department, size: 14, color: Colors.orange[400]),
                            const SizedBox(width: 4),
                            Text(
                              '${receta['calorias']}',
                              style: TextStyle(
                                fontSize: 11,
                                color: Colors.grey[400],
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      if (receta['tiempo_preparacion'] != null)
                        Row(
                          children: [
                            Icon(Icons.access_time, size: 14, color: Colors.blue[400]),
                            const SizedBox(width: 4),
                            Text(
                              receta['tiempo_preparacion'].toString().length > 10
                                  ? '${receta['tiempo_preparacion'].toString().substring(0, 10)}...'
                                  : receta['tiempo_preparacion'].toString(),
                              style: TextStyle(
                                fontSize: 11,
                                color: Colors.grey[400],
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                    ],
                  ),
                  if (fechaTexto.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Icon(Icons.calendar_today, size: 12, color: Colors.grey[500]),
                        const SizedBox(width: 4),
                        Text(
                          fechaTexto,
                          style: TextStyle(
                            fontSize: 10,
                            color: Colors.grey[500],
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _mostrarDetalleReceta(Map<String, dynamic> receta) {
    final isFavorito = receta['is_favorito'] == true;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.9,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        builder: (_, controller) => Container(
          decoration: BoxDecoration(
            color: Colors.grey[900],
            borderRadius: const BorderRadius.vertical(top: Radius.circular(25)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Center(
                child: Container(
                  margin: const EdgeInsets.only(top: 12, bottom: 8),
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[700],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: verdeApp.withAlpha(51),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(
                        _getTipoComidaIcon(receta['tipo_comida'] ?? ''),
                        color: verdeApp,
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _getTipoComidaNombre(receta['tipo_comida'] ?? ''),
                            style: const TextStyle(
                              fontSize: 12,
                              color: Colors.white70,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            receta['nombre'] ?? '',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton(
                      icon: Icon(
                        isFavorito ? Icons.favorite : Icons.favorite_border,
                        color: isFavorito ? verdeApp : Colors.white70,
                      ),
                      onPressed: () {
                        _toggleFavorito(receta);
                        Navigator.pop(context);
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.calendar_month, color: Colors.white70),
                      onPressed: () {
                        Navigator.pop(context);
                        _mostrarOpcionesAsignarSemana(receta);
                      },
                      tooltip: 'Asignar a semana',
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white70),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1, color: Colors.white24),
              Expanded(
                child: ListView(
                  controller: controller,
                  padding: const EdgeInsets.all(20),
                  children: [
                    if (receta['imagen_url'] != null)
                      Container(
                        height: 200,
                        margin: const EdgeInsets.only(bottom: 20),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.network(
                            receta['imagen_url'],
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) {
                              return Container(
                                color: Colors.grey[800],
                                child: const Icon(Icons.restaurant, size: 60, color: Colors.white),
                              );
                            },
                          ),
                        ),
                      ),
                    _buildRecetaFormateada(receta['contenido_completo'] ?? ''),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRecetaFormateada(String contenido) {
    final lineas = contenido.split('\n');
    List<Widget> widgets = [];
    String seccionActual = '';
    List<String> contenidoSeccion = [];

    for (var linea in lineas) {
      if (linea.toUpperCase().startsWith('NOMBRE:')) {
        widgets.add(_buildNombre(linea.replaceFirst(RegExp(r'NOMBRE:\s*', caseSensitive: false), '')));
      } else if (linea.toUpperCase().startsWith('INGREDIENTES:')) {
        if (seccionActual.isNotEmpty) {
          widgets.add(_buildSeccion(seccionActual, contenidoSeccion.join('\n')));
        }
        seccionActual = 'INGREDIENTES';
        contenidoSeccion = [];
      } else if (linea.toUpperCase().startsWith('PREPARACIÓN:')) {
        if (seccionActual.isNotEmpty) {
          widgets.add(_buildSeccion(seccionActual, contenidoSeccion.join('\n')));
        }
        seccionActual = 'PREPARACIÓN';
        contenidoSeccion = [];
      } else if (linea.toUpperCase().startsWith('INFORMACIÓN NUTRICIONAL:')) {
        if (seccionActual.isNotEmpty) {
          widgets.add(_buildSeccion(seccionActual, contenidoSeccion.join('\n')));
        }
        seccionActual = 'INFORMACIÓN NUTRICIONAL';
        contenidoSeccion = [];
      } else if (linea.toUpperCase().startsWith('TIEMPO DE PREPARACIÓN:')) {
        if (seccionActual.isNotEmpty) {
          widgets.add(_buildSeccion(seccionActual, contenidoSeccion.join('\n')));
        }
        seccionActual = 'TIEMPO';
        contenidoSeccion = [linea.replaceFirst(RegExp(r'TIEMPO DE PREPARACIÓN:\s*', caseSensitive: false), '')];
      } else if (linea.toUpperCase().startsWith('CONSEJOS:')) {
        if (seccionActual.isNotEmpty) {
          widgets.add(_buildSeccion(seccionActual, contenidoSeccion.join('\n')));
        }
        seccionActual = 'CONSEJOS';
        contenidoSeccion = [];
      } else if (linea.trim().isNotEmpty) {
        contenidoSeccion.add(linea);
      }
    }

    if (seccionActual.isNotEmpty) {
      widgets.add(_buildSeccion(seccionActual, contenidoSeccion.join('\n')));
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: widgets,
    );
  }

  Widget _buildNombre(String nombre) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 24),
      child: Text(
        nombre.trim(),
        style: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: verdeApp,
        ),
      ),
    );
  }

  Widget _buildSeccion(String tipo, String contenido) {
    IconData icon;
    Color color;

    switch (tipo) {
      case 'INGREDIENTES':
        icon = Icons.shopping_basket_outlined;
        color = Colors.orange[400]!;
        break;
      case 'PREPARACIÓN':
        icon = Icons.menu_book_outlined;
        color = Colors.blue[400]!;
        break;
      case 'INFORMACIÓN NUTRICIONAL':
        icon = Icons.bar_chart;
        color = verdeApp;
        break;
      case 'TIEMPO':
        icon = Icons.timer_outlined;
        color = Colors.purple[300]!;
        break;
      case 'CONSEJOS':
        icon = Icons.lightbulb_outline;
        color = Colors.amber[400]!;
        break;
      default:
        icon = Icons.info_outline;
        color = Colors.grey[400]!;
    }

    // Si es INFORMACIÓN NUTRICIONAL, usar diseño destacado
    if (tipo == 'INFORMACIÓN NUTRICIONAL') {
      return Container(
        margin: const EdgeInsets.only(bottom: 20),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: verdeApp.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: verdeApp.withValues(alpha: 0.3)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: verdeApp, size: 20),
                const SizedBox(width: 8),
                Text(
                  tipo,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: verdeApp,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              contenido.trim(),
              style: const TextStyle(
                fontSize: 13,
                height: 1.6,
                color: Colors.white,
              ),
            ),
          ],
        ),
      );
    }

    // Diseño normal para otras secciones
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 20),
              const SizedBox(width: 8),
              Text(
                tipo,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            contenido.trim(),
            style: const TextStyle(
              fontSize: 13,
              height: 1.6,
              color: Colors.white70,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSeccionDetalle(String titulo, IconData icon, Color color, String contenido) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 20),
              const SizedBox(width: 8),
              Text(
                titulo,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: color,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            contenido.trim(),
            style: const TextStyle(
              fontSize: 13,
              height: 1.5,
              color: Colors.white70,
            ),
          ),
          const SizedBox(height: 8),
          const Divider(color: Colors.white10, height: 1),
        ],
      ),
    );
  }

  Widget _buildInformacionNutricional(Map<String, dynamic> info) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: verdeApp.withAlpha(38),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: verdeApp.withAlpha(77)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.bar_chart, color: verdeApp, size: 20),
              const SizedBox(width: 8),
              const Text(
                'Información Nutricional',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: verdeApp,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _buildNutrienteRow('Proteínas', info['proteinas']?.toString() ?? 'N/A'),
          _buildNutrienteRow('Carbohidratos', info['carbohidratos']?.toString() ?? 'N/A'),
          _buildNutrienteRow('Grasas', info['grasas']?.toString() ?? 'N/A'),
          _buildNutrienteRow('Calorías', info['calorias']?.toString() ?? 'N/A'),
        ],
      ),
    );
  }

  Widget _buildNutrienteRow(String nombre, String valor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            nombre,
            style: const TextStyle(color: Colors.white70, fontSize: 13),
          ),
          Text(
            valor,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  IconData _getTipoComidaIcon(String tipo) {
    switch (tipo.toLowerCase()) {
      case 'desayuno':
        return Icons.wb_sunny_outlined;
      case 'almuerzo':
        return Icons.restaurant;
      case 'cena':
        return Icons.dinner_dining;
      case 'snack':
        return Icons.cookie_outlined;
      default:
        return Icons.restaurant_menu;
    }
  }

  String _getTipoComidaNombre(String tipo) {
    switch (tipo.toLowerCase()) {
      case 'desayuno':
        return 'Desayuno';
      case 'almuerzo':
        return 'Almuerzo';
      case 'cena':
        return 'Cena';
      case 'snack':
        return 'Snack';
      default:
        return 'Comida';
    }
  }

  // ========== MÉTODOS PARA ASIGNAR A SEMANA ==========

  void _mostrarOpcionesAsignarSemana(Map<String, dynamic> receta) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.grey[900],
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(
                color: Colors.grey[700],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const Text(
              'Asignar a semana',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 24),
            _buildOpcionSemana(
              icon: Icons.calendar_today,
              titulo: 'Semana Actual',
              subtitulo: 'Asignar a un día de esta semana',
              onTap: () {
                Navigator.pop(context);
                _asignarRecetaASemana(receta, 'actual');
              },
            ),
            const SizedBox(height: 12),
            _buildOpcionSemana(
              icon: Icons.calendar_month,
              titulo: 'Próxima Semana',
              subtitulo: 'Planificar para la semana siguiente',
              onTap: () {
                Navigator.pop(context);
                _asignarRecetaASemana(receta, 'proxima');
              },
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildOpcionSemana({
    required IconData icon,
    required String titulo,
    required String subtitulo,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.grey[850],
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey[800]!),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: verdeApp.withOpacity(0.2),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: verdeApp, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    titulo,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitulo,
                    style: TextStyle(
                      fontSize: 13,
                      color: Colors.grey[400],
                    ),
                  ),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios, color: Colors.grey[600], size: 16),
          ],
        ),
      ),
    );
  }

  Future<void> _asignarRecetaASemana(Map<String, dynamic> receta, String semana) async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      // Calcular el offset de semana (0 = actual, 1 = próxima)
      final semanaOffset = semana == 'actual' ? 0 : 1;

      // Seleccionar día de la semana
      final diaSeleccionado = await _mostrarDialogoSeleccionarDia();

      if (diaSeleccionado == null) return;

      final response = await http.post(
        Uri.parse('$baseUrl/api/asignar-receta-semana'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'user_id': user.id,
          'tipo_comida': receta['tipo_comida'],
          'dia_semana': diaSeleccionado,
          'semana_offset': semanaOffset,
          'contenido': receta['contenido_completo'],
        }),
      );

      if (response.statusCode == 200) {
        final mensaje = semana == 'actual'
            ? 'Receta asignada a $diaSeleccionado de esta semana'
            : 'Receta guardada para $diaSeleccionado de la próxima semana';

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(mensaje),
              backgroundColor: verdeApp,
              duration: const Duration(seconds: 3),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error al asignar receta: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<String?> _mostrarDialogoSeleccionarDia() async {
    final dias = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];

    return await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text('Selecciona el día', style: TextStyle(color: Colors.white)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: dias.map((dia) => ListTile(
            title: Text(dia, style: const TextStyle(color: Colors.white)),
            trailing: Icon(Icons.arrow_forward_ios, color: verdeApp, size: 16),
            onTap: () => Navigator.pop(context, dia),
          )).toList(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar', style: TextStyle(color: Colors.white70)),
          ),
        ],
      ),
    );
  }
}
