import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'custom_bottom_nav.dart';

class MisRecetasPage extends StatefulWidget {
  const MisRecetasPage({super.key});

  @override
  State<MisRecetasPage> createState() => _MisRecetasPageState();
}

class _MisRecetasPageState extends State<MisRecetasPage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final GlobalKey<_MenuSemanalTabState> _menuSemanalKey = GlobalKey<_MenuSemanalTabState>();
  final supabase = Supabase.instance.client;

  String? _avatarUrl;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(() {
      setState(() {});
    });
    _cargarAvatar();
  }

  Future<void> _cargarAvatar() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final data = await supabase
          .from('usuarios')
          .select('avatar_url')
          .eq('id', user.id)
          .single();

      if (mounted) {
        setState(() {
          _avatarUrl = data['avatar_url'];
        });
      }
    } catch (e) {
      // Error silencioso
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        automaticallyImplyLeading: false,
        title: Row(
          children: [
            CircleAvatar(
              radius: 18,
              backgroundColor: const Color(0xFF66BB6A),
              backgroundImage: _avatarUrl != null && _avatarUrl!.isNotEmpty
                  ? NetworkImage(_avatarUrl!)
                  : null,
              child: _avatarUrl == null || _avatarUrl!.isEmpty
                  ? const Icon(Icons.person, color: Colors.white, size: 20)
                  : null,
            ),
            const SizedBox(width: 12),
            const Text(
              'Mis Recetas',
              style: TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        bottom: TabBar(
          controller: _tabController,
          labelColor: const Color(0xFF66BB6A),
          unselectedLabelColor: Colors.grey,
          indicatorColor: const Color(0xFF66BB6A),
          labelStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
          tabs: const [
            Tab(text: 'Menú Semanal'),
            Tab(text: 'Generar Receta'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          MenuSemanalTab(key: _menuSemanalKey),
          const GenerarRecetaTab(),
        ],
      ),
      floatingActionButton: _tabController.index == 0
          ? FloatingActionButton.extended(
              onPressed: () {
                _menuSemanalKey.currentState?._confirmarGenerarProximaSemana();
              },
              backgroundColor: const Color(0xFF66BB6A),
              foregroundColor: Colors.black,
              elevation: 4,
              icon: const Icon(Icons.next_plan, color: Colors.black),
              label: const Text('Próxima Semana', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black)),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            )
          : null,
      bottomNavigationBar: const CustomBottomNav(currentIndex: 3),
    );
  }
}

class MenuSemanalTab extends StatefulWidget {
  const MenuSemanalTab({super.key});

  @override
  State<MenuSemanalTab> createState() => _MenuSemanalTabState();
}

class _MenuSemanalTabState extends State<MenuSemanalTab> {
  final String baseUrl = "https://fitchi-backend-398799029559.southamerica-west1.run.app";
  final supabase = Supabase.instance.client;
  static const Color verdeApp = Color(0xFF66BB6A);

  Map<String, dynamic>? menuSemanal;
  bool _cargando = true;
  int progreso = 0;
  bool menuCompleto = false;
  Timer? _pollingTimer;
  int _semanaOffset = 0; // 0 = semana actual, 1 = próxima semana

  @override
  void initState() {
    super.initState();
    _cargarMenuSemanal();
    _iniciarPolling();
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    super.dispose();
  }

  void _iniciarPolling() {
    _pollingTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      if (!menuCompleto && mounted) {
        _cargarMenuSemanal();
      } else {
        timer.cancel();
      }
    });
  }

  Future<void> _cargarMenuSemanal() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/menu-semanal/${user.id}?semana_offset=$_semanaOffset'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (mounted) {
          setState(() {
            menuSemanal = data['menu'];
            progreso = data['progreso'];
            menuCompleto = data['completo'];
            _cargando = false;
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() => _cargando = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  Future<void> _marcarComidaConsumida(int recetaId) async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/marcar-comida-consumida'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'user_id': user.id,
          'receta_id': recetaId,
          'tipo_comida': 'desayuno', // El backend lo obtiene de la receta
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(data['message'] ?? '¡Comida registrada!'),
              backgroundColor: verdeApp,
              duration: const Duration(seconds: 2),
            ),
          );
        }
      } else if (response.statusCode == 400) {
        final data = jsonDecode(response.body);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(data['detail'] ?? 'Esta comida ya fue registrada'),
              backgroundColor: Colors.orange,
              duration: const Duration(seconds: 2),
            ),
          );
        }
      } else {
        throw Exception('Error registrando comida');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error al registrar comida: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_cargando) {
      return const Center(child: CircularProgressIndicator());
    }
    
    if (menuSemanal == null || menuSemanal!.isEmpty) {
      return _buildEmptyState();
    }
    
    return Column(
      children: [
        _buildSelectorSemana(),
        if (!menuCompleto) _buildProgresoBar(),
        Expanded(child: _buildMenuList()),
      ],
    );
  }

  Widget _buildSelectorSemana() {
    final DateTime ahora = DateTime.now();
    final DateTime proximaSemana = ahora.add(const Duration(days: 7));

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.grey[850],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: verdeApp.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Expanded(
            child: _buildBotonSemana(
              texto: 'Esta Semana',
              subtexto: '${ahora.day}/${ahora.month}',
              seleccionada: _semanaOffset == 0,
              onTap: () {
                if (_semanaOffset != 0) {
                  setState(() {
                    _semanaOffset = 0;
                    _cargando = true;
                    menuSemanal = null; // Limpiar menú anterior
                  });
                  _cargarMenuSemanal();
                }
              },
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: _buildBotonSemana(
              texto: 'Próxima Semana',
              subtexto: '${proximaSemana.day}/${proximaSemana.month}',
              seleccionada: _semanaOffset == 1,
              onTap: () {
                if (_semanaOffset != 1) {
                  setState(() {
                    _semanaOffset = 1;
                    _cargando = true;
                    menuSemanal = null; // Limpiar menú anterior
                  });
                  _cargarMenuSemanal();
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBotonSemana({
    required String texto,
    required String subtexto,
    required bool seleccionada,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
        decoration: BoxDecoration(
          color: seleccionada ? verdeApp : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          children: [
            Text(
              texto,
              style: TextStyle(
                color: seleccionada ? Colors.white : Colors.grey[400],
                fontWeight: seleccionada ? FontWeight.bold : FontWeight.normal,
                fontSize: 13,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 4),
            Text(
              subtexto,
              style: TextStyle(
                color: seleccionada ? Colors.white70 : Colors.grey[600],
                fontSize: 11,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProgresoBar() {
  return Container(
    margin: const EdgeInsets.all(16),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.grey[850],
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: Colors.orange[700]!),
    ),
    child: Column(
      children: [
        Row(
          children: [
            Icon(Icons.access_time, color: Colors.orange[400]),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Generando tu menú personalizado',
                    style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '$progreso% completado',
                    style: TextStyle(fontSize: 12, color: Colors.white70),
                  ),
                ],
              ),
            ),
            IconButton(
              icon: Icon(Icons.refresh, color: Colors.orange[400]),
              onPressed: _cargarMenuSemanal,
            ),
          ],
        ),
        const SizedBox(height: 12),
        LinearProgressIndicator(
          value: progreso / 100,
          backgroundColor: Colors.grey[700],
          valueColor: AlwaysStoppedAnimation<Color>(Colors.orange[400]!),
        ),
      ],
    ),
  );
}

Widget _buildMenuList() {
  final dias = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
  
  return ListView.builder(
    padding: const EdgeInsets.all(12),
    itemCount: dias.length,
    itemBuilder: (context, index) {
      final dia = dias[index];
      final comidasDia = menuSemanal![dia];
      return _buildDiaCard(dia, comidasDia);
    },
  );
}

Widget _buildDiaCard(String dia, Map<String, dynamic> comidas) {
  final tieneComidas = comidas.values.any((c) => c != null);
  final esHoy = _esDiaDeHoy(dia);
  
  return Container(
    margin: const EdgeInsets.only(bottom: 12),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.grey[900],
      borderRadius: BorderRadius.circular(12),
      border: esHoy ? Border.all(color: verdeApp, width: 2) : null,
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.3),
          blurRadius: 8,
          offset: const Offset(0, 2),
        ),
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(Icons.calendar_today, size: 16, color: esHoy ? verdeApp : Colors.white70),
            const SizedBox(width: 8),
            Text(
              dia,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
            if (esHoy) ...[
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: verdeApp,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  'HOY',
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
            const Spacer(),
            Text(
              '4 comidas planificadas',
              style: TextStyle(
                fontSize: 12,
                color: Colors.white60,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        _buildComidasHorizontalCompacto(comidas),
      ],
    ),
  );
}

  Widget _buildComidasHorizontalCompacto(Map<String, dynamic> comidas) {
  final comidasList = [
    {'tipo': 'desayuno', 'nombre': 'Desayuno', 'icon': Icons.wb_sunny_outlined, 'data': comidas['desayuno']},
    {'tipo': 'almuerzo', 'nombre': 'Almuerzo', 'icon': Icons.restaurant, 'data': comidas['almuerzo']},
    {'tipo': 'cena', 'nombre': 'Cena', 'icon': Icons.dinner_dining, 'data': comidas['cena']},
    {'tipo': 'snack', 'nombre': 'Snack', 'icon': Icons.cookie_outlined, 'data': comidas['snack']},
  ];

  return SizedBox(
    height: 115,
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: comidasList.map((comida) {
        final data = comida['data'];
        final isGenerada = data != null;

        return GestureDetector(
          onTap: isGenerada ? () => _mostrarRecetaCompleta(data) : null,
          child: Column(
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    width: 65,
                    height: 65,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: isGenerada ? verdeApp : Colors.grey[700]!,
                        width: 2.5,
                      ),
                    ),
                    child: ClipOval(
                      child: isGenerada && data['imagen_url'] != null
                          ? Image.network(
                              data['imagen_url'],
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) {
                                return Container(
                                  color: Colors.grey[800],
                                  child: Icon(comida['icon'], color: verdeApp, size: 28),
                                );
                              },
                              loadingBuilder: (context, child, loadingProgress) {
                                if (loadingProgress == null) return child;
                                return Center(
                                  child: SizedBox(
                                    width: 22,
                                    height: 22,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      valueColor: AlwaysStoppedAnimation<Color>(verdeApp),
                                    ),
                                  ),
                                );
                              },
                            )
                          : Container(
                              color: Colors.grey[800],
                              child: Icon(
                                comida['icon'],
                                color: isGenerada ? verdeApp : Colors.grey[600],
                                size: 28,
                              ),
                            ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                comida['nombre'], // Siempre mostrar el tipo de comida (Desayuno, Almuerzo, etc.)
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                  color: isGenerada ? Colors.white : Colors.grey[600],
                ),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        );
      }).toList(),
    ),
  );
}

  bool _esDiaDeHoy(String dia) {
    final diasSemana = {
      1: 'Lunes', 2: 'Martes', 3: 'Miércoles', 4: 'Jueves',
      5: 'Viernes', 6: 'Sábado', 7: 'Domingo',
    };
    return diasSemana[DateTime.now().weekday] == dia;
  }

  String _extraerNombreDeContenido(String contenido) {
    // Buscar la línea que empieza con "NOMBRE:"
    final lineas = contenido.split('\n');
    for (var linea in lineas) {
      if (linea.toUpperCase().startsWith('NOMBRE:')) {
        return linea.replaceFirst(RegExp(r'NOMBRE:\s*', caseSensitive: false), '').trim();
      }
    }
    return 'Tu receta personalizada';
  }

  void _mostrarRecetaCompleta(dynamic comida) {
    // Extraer el nombre de la receta del contenido
    final nombreReceta = comida['nombre'] ?? _extraerNombreDeContenido(comida['contenido_completo']);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.9,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        builder: (_, controller) => Container(
          decoration: BoxDecoration(
            color: Colors.grey[900],
            borderRadius: const BorderRadius.vertical(top: Radius.circular(25)),
          ),
          child: Column(
            children: [
              Center(
                child: Container(
                  margin: const EdgeInsets.only(top: 12, bottom: 8),
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[700],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: verdeApp.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(Icons.restaurant_menu, color: verdeApp, size: 20),
                    ),
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 12),
                        child: Text(
                          nombreReceta,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white70),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1, color: Colors.white24),
              Expanded(
                child: ListView(
                  controller: controller,
                  padding: const EdgeInsets.all(20),
                  children: [
                    _buildRecetaFormateada(comida['contenido_completo']),
                  ],
                ),
              ),
              // Botón "Marcar como consumida"
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey[850],
                  border: Border(top: BorderSide(color: Colors.white24, width: 1)),
                ),
                child: SafeArea(
                  top: false,
                  child: ElevatedButton(
                    onPressed: () async {
                      Navigator.pop(context);
                      await _marcarComidaConsumida(comida['id']);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: verdeApp,
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.check_circle_outline, size: 20),
                        SizedBox(width: 8),
                        Text(
                          'Marcar como consumida',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRecetaFormateada(String contenido) {
    final lineas = contenido.split('\n');
    List<Widget> widgets = [];
    String seccionActual = '';
    List<String> contenidoSeccion = [];

    for (var linea in lineas) {
      if (linea.toUpperCase().startsWith('NOMBRE:')) {
        widgets.add(_buildNombre(linea.replaceFirst(RegExp(r'NOMBRE:\s*', caseSensitive: false), '')));
      } else if (linea.toUpperCase().startsWith('INGREDIENTES:')) {
        if (seccionActual.isNotEmpty) {
          widgets.add(_buildSeccion(seccionActual, contenidoSeccion.join('\n')));
        }
        seccionActual = 'INGREDIENTES';
        contenidoSeccion = [];
      } else if (linea.toUpperCase().startsWith('PREPARACIÓN:')) {
        if (seccionActual.isNotEmpty) {
          widgets.add(_buildSeccion(seccionActual, contenidoSeccion.join('\n')));
        }
        seccionActual = 'PREPARACIÓN';
        contenidoSeccion = [];
      } else if (linea.toUpperCase().startsWith('INFORMACIÓN NUTRICIONAL:')) {
        if (seccionActual.isNotEmpty) {
          widgets.add(_buildSeccion(seccionActual, contenidoSeccion.join('\n')));
        }
        seccionActual = 'INFORMACIÓN NUTRICIONAL';
        contenidoSeccion = [];
      } else if (linea.toUpperCase().startsWith('TIEMPO DE PREPARACIÓN:')) {
        if (seccionActual.isNotEmpty) {
          widgets.add(_buildSeccion(seccionActual, contenidoSeccion.join('\n')));
        }
        seccionActual = 'TIEMPO';
        contenidoSeccion = [linea.replaceFirst(RegExp(r'TIEMPO DE PREPARACIÓN:\s*', caseSensitive: false), '')];
      } else if (linea.toUpperCase().startsWith('CONSEJOS:')) {
        if (seccionActual.isNotEmpty) {
          widgets.add(_buildSeccion(seccionActual, contenidoSeccion.join('\n')));
        }
        seccionActual = 'CONSEJOS';
        contenidoSeccion = [];
      } else if (linea.trim().isNotEmpty) {
        contenidoSeccion.add(linea);
      }
    }

    if (seccionActual.isNotEmpty) {
      widgets.add(_buildSeccion(seccionActual, contenidoSeccion.join('\n')));
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: widgets,
    );
  }

  Widget _buildNombre(String nombre) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 24),
      child: Text(
        nombre.trim(),
        style: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: verdeApp,
        ),
      ),
    );
  }

  Widget _buildSeccion(String tipo, String contenido) {
    IconData icon;
    Color color;

    switch (tipo) {
      case 'INGREDIENTES':
        icon = Icons.shopping_basket_outlined;
        color = Colors.orange[400]!;
        break;
      case 'PREPARACIÓN':
        icon = Icons.menu_book_outlined;
        color = Colors.blue[400]!;
        break;
      case 'INFORMACIÓN NUTRICIONAL':
        icon = Icons.bar_chart;
        color = verdeApp;
        break;
      case 'TIEMPO':
        icon = Icons.timer_outlined;
        color = Colors.purple[300]!;
        break;
      case 'CONSEJOS':
        icon = Icons.lightbulb_outline;
        color = Colors.amber[400]!;
        break;
      default:
        icon = Icons.info_outline;
        color = Colors.grey[400]!;
    }

    // Si es INFORMACIÓN NUTRICIONAL, usar diseño destacado
    if (tipo == 'INFORMACIÓN NUTRICIONAL') {
      return Container(
        margin: const EdgeInsets.only(bottom: 20),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: verdeApp.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: verdeApp.withValues(alpha: 0.3)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: verdeApp, size: 20),
                const SizedBox(width: 8),
                Text(
                  tipo,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: verdeApp,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              contenido.trim(),
              style: const TextStyle(
                fontSize: 13,
                height: 1.6,
                color: Colors.white,
              ),
            ),
          ],
        ),
      );
    }

    // Diseño normal para otras secciones
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 20),
              const SizedBox(width: 8),
              Text(
                tipo,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            contenido.trim(),
            style: const TextStyle(
              fontSize: 13,
              height: 1.6,
              color: Colors.white70,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.calendar_month, size: 80, color: Colors.grey[400]),
            const SizedBox(height: 16),
            Text(
              'No tienes menú semanal',
              style: TextStyle(fontSize: 18, color: Colors.grey[600]),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: _generarMenuCompleto,
              icon: const Icon(Icons.auto_awesome),
              label: const Text('Generar Menú Semanal'),
              style: ElevatedButton.styleFrom(
                backgroundColor: verdeApp,
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _generarMenuCompleto() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    setState(() => _cargando = true);

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/inicializar-menu-usuario'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'user_id': user.id, 'tipo_comida': 'desayuno'}),
      );

      if (response.statusCode == 200 && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Generando tu menú semanal con fotos reales...'),
            backgroundColor: Colors.orange,
          ),
        );
        await Future.delayed(const Duration(seconds: 2));
        _cargarMenuSemanal();
      }
    } catch (e) {
      setState(() => _cargando = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  Future<void> _confirmarGenerarProximaSemana() async {
    final ahora = DateTime.now();
    final proximaSemana = ahora.add(const Duration(days: 7));
    final semanaNumero = _getWeekNumber(proximaSemana);

    final confirmar = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            Icon(Icons.calendar_month, color: verdeApp),
            const SizedBox(width: 12),
            const Text('Generar Menú Anticipado', style: TextStyle(color: Colors.white)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '¿Quieres generar el menú de la próxima semana?',
              style: TextStyle(fontSize: 16, color: Colors.white70),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: verdeApp.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: verdeApp.withValues(alpha: 0.4)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.info_outline, color: verdeApp, size: 20),
                      const SizedBox(width: 8),
                      Text(
                        'Semana $semanaNumero',
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    '• Tendrás tiempo para comprar ingredientes\n'
                    '• Solo puedes generar una vez por semana\n'
                    '• El menú actual no se verá afectado',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.white70,
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar', style: TextStyle(color: Colors.white54)),
          ),
          ElevatedButton.icon(
            onPressed: () => Navigator.pop(context, true),
            icon: const Icon(Icons.calendar_today, color: Colors.black),
            label: const Text('Generar', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
            style: ElevatedButton.styleFrom(
              backgroundColor: verdeApp,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
        ],
      ),
    );

    if (confirmar == true) {
      await _generarMenuProximaSemana();
    }
  }

  int _getWeekNumber(DateTime date) {
    final firstDayOfYear = DateTime(date.year, 1, 1);
    final daysSinceFirstDay = date.difference(firstDayOfYear).inDays;
    return ((daysSinceFirstDay + firstDayOfYear.weekday) / 7).ceil();
  }

  Future<void> _generarMenuProximaSemana() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    setState(() => _cargando = true);

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/generar-menu-proximo'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'user_id': user.id}),
      );

      if (response.statusCode == 200) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('¡Generando menú de la próxima semana! Esto tomará unos minutos.'),
              backgroundColor: Colors.green,
              duration: Duration(seconds: 4),
            ),
          );

          // Esperar 3 segundos antes de cambiar de semana
          await Future.delayed(const Duration(seconds: 3));

          // Cambiar automáticamente a la próxima semana
          setState(() {
            _semanaOffset = 1;
            menuSemanal = null;
            _cargando = true;
          });

          // Recargar el menú de la próxima semana
          await _cargarMenuSemanal();
        }
      } else if (response.statusCode == 400) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Ya existe un menú para la próxima semana'),
              backgroundColor: Colors.orange,
            ),
          );
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Error al generar el menú'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _cargando = false);
      }
    }
  }
}

class GenerarRecetaTab extends StatefulWidget {
  const GenerarRecetaTab({super.key});

  @override
  State<GenerarRecetaTab> createState() => _GenerarRecetaTabState();
}

class _GenerarRecetaTabState extends State<GenerarRecetaTab> {
  final String baseUrl = "https://fitchi-backend-398799029559.southamerica-west1.run.app";
  static const Color verdeApp = Color(0xFF66BB6A);
  final supabase = Supabase.instance.client;

  bool _cargando = false;
  String? _recetaActual;
  String? _tipoComidaSeleccionado;
  Map<String, dynamic>? _recetaGeneradaData; // Almacena los datos completos de la receta generada

  final List<Map<String, dynamic>> tiposComida = [
    {'tipo': 'desayuno', 'nombre': 'Desayuno', 'icon': Icons.wb_sunny_outlined},
    {'tipo': 'almuerzo', 'nombre': 'Almuerzo', 'icon': Icons.restaurant},
    {'tipo': 'cena', 'nombre': 'Cena', 'icon': Icons.dinner_dining},
    {'tipo': 'snack', 'nombre': 'Snack', 'icon': Icons.cookie_outlined},
  ];

  Future<void> generarReceta(String tipoComida) async {
    setState(() {
      _cargando = true;
      _recetaActual = null;
      _tipoComidaSeleccionado = tipoComida;
    });

    try {
      final user = supabase.auth.currentUser;
      if (user == null) throw Exception("Usuario no autenticado");

      final response = await http.post(
        Uri.parse('$baseUrl/api/generar-receta'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'user_id': user.id, 'tipo_comida': tipoComida}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _recetaActual = data['receta_completa'];
          _recetaGeneradaData = data;
        });
      } else {
        throw Exception('Error: ${response.statusCode}');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      setState(() => _cargando = false);
    }
  }

  Future<void> _mostrarDialogoSeleccionarSemana(String tipoComida) async {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.grey[900],
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(
                color: Colors.grey[700],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const Text(
              'Asignar a semana',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 24),
            _buildOpcionSemana(
              icon: Icons.calendar_today,
              titulo: 'Semana Actual',
              subtitulo: 'Asignar a un día de esta semana',
              onTap: () {
                Navigator.pop(context);
                _asignarRecetaASemana(tipoComida, 'actual');
              },
            ),
            const SizedBox(height: 12),
            _buildOpcionSemana(
              icon: Icons.calendar_month,
              titulo: 'Próxima Semana',
              subtitulo: 'Planificar para la semana siguiente',
              onTap: () {
                Navigator.pop(context);
                _asignarRecetaASemana(tipoComida, 'proxima');
              },
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildOpcionSemana({
    required IconData icon,
    required String titulo,
    required String subtitulo,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.grey[850],
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey[800]!),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: verdeApp.withOpacity(0.2),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: verdeApp, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    titulo,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitulo,
                    style: TextStyle(
                      fontSize: 13,
                      color: Colors.grey[400],
                    ),
                  ),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios, color: Colors.grey[600], size: 16),
          ],
        ),
      ),
    );
  }

  Future<void> _asignarRecetaASemana(String tipoComida, String semana) async {
    final user = supabase.auth.currentUser;
    if (user == null || _recetaGeneradaData == null) return;

    try {
      // Calcular el offset de semana (0 = actual, 1 = próxima)
      final semanaOffset = semana == 'actual' ? 0 : 1;

      // Necesitamos obtener un día de la semana. Para simplificar, usaremos "Lunes"
      // El usuario deberá elegir el día específico en una versión futura
      final diaSeleccionado = await _mostrarDialogoSeleccionarDia();

      if (diaSeleccionado == null) return;

      final response = await http.post(
        Uri.parse('$baseUrl/api/asignar-receta-semana'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'user_id': user.id,
          'tipo_comida': tipoComida,
          'dia_semana': diaSeleccionado,
          'semana_offset': semanaOffset,
          'contenido': _recetaGeneradaData!['receta_completa'],
        }),
      );

      if (response.statusCode == 200) {
        final mensaje = semana == 'actual'
            ? 'Receta asignada a $diaSeleccionado de esta semana'
            : 'Receta guardada para $diaSeleccionado de la próxima semana';

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(mensaje),
              backgroundColor: verdeApp,
              duration: const Duration(seconds: 3),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error al asignar receta: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<String?> _mostrarDialogoSeleccionarDia() async {
    final dias = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];

    return await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Selecciona el día', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: dias.map((dia) => InkWell(
            onTap: () => Navigator.pop(context, dia),
            borderRadius: BorderRadius.circular(12),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
              margin: const EdgeInsets.only(bottom: 8),
              decoration: BoxDecoration(
                color: Colors.grey[850],
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(dia, style: const TextStyle(color: Colors.white, fontSize: 15)),
                  ),
                  Icon(Icons.arrow_forward_ios, color: verdeApp, size: 16),
                ],
              ),
            ),
          )).toList(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar', style: TextStyle(color: Colors.white54)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.grey[900],
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: verdeApp.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(Icons.auto_awesome, color: verdeApp, size: 28),
                ),
                const SizedBox(width: 16),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Generadas con IA",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        "Según tus objetivos nutricionales",
                        style: TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 1.3,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
            ),
            itemCount: tiposComida.length,
            itemBuilder: (context, index) {
              final comida = tiposComida[index];
              final isSelected = _tipoComidaSeleccionado == comida['tipo'];
              
              return GestureDetector(
                onTap: _cargando ? null : () => generarReceta(comida['tipo']),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.grey[900],
                    borderRadius: BorderRadius.circular(16),
                    border: isSelected ? Border.all(color: verdeApp, width: 2) : null,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        comida['icon'],
                        size: 40,
                        color: isSelected ? verdeApp : Colors.white70,
                      ),
                      const SizedBox(height: 12),
                      Text(
                        comida['nombre'],
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: isSelected ? verdeApp : Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 24),
          if (_cargando)
            _buildLoadingCard()
          else if (_recetaActual != null)
            _buildRecetaCard()
          else
            _buildEmptyState(),
        ],
      ),
    );
  }

  Widget _buildLoadingCard() {
    return Container(
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          SizedBox(
            width: 60,
            height: 60,
            child: CircularProgressIndicator(
              strokeWidth: 5,
              valueColor: AlwaysStoppedAnimation<Color>(verdeApp),
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            "Creando tu receta personalizada...",
            style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.w500),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          const Text(
            "Esto puede tomar unos segundos",
            style: TextStyle(fontSize: 13, color: Colors.white70),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildRecetaCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.restaurant_menu, color: verdeApp, size: 24),
                  const SizedBox(width: 12),
                  const Text(
                    "Tu receta personalizada",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                ],
              ),
              IconButton(
                icon: const Icon(Icons.refresh_rounded),
                onPressed: _cargando ? null : () => generarReceta(_tipoComidaSeleccionado!),
                color: verdeApp,
                iconSize: 26,
              ),
            ],
          ),
          const Divider(height: 32, color: Colors.white24),
          _buildRecetaFormateadaGenerar(_recetaActual!),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () => _mostrarDialogoSeleccionarSemana(_tipoComidaSeleccionado!),
              icon: const Icon(Icons.calendar_month, color: Colors.white),
              label: const Text(
                'Asignar a una semana',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: verdeApp,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecetaFormateadaGenerar(String contenido) {
    final lineas = contenido.split('\n');
    List<Widget> widgets = [];
    String seccionActual = '';
    List<String> contenidoSeccion = [];

    for (var linea in lineas) {
      if (linea.toUpperCase().startsWith('NOMBRE:')) {
        widgets.add(_buildNombreGenerar(linea.replaceFirst(RegExp(r'NOMBRE:\s*', caseSensitive: false), '')));
      } else if (linea.toUpperCase().startsWith('INGREDIENTES:')) {
        if (seccionActual.isNotEmpty) {
          widgets.add(_buildSeccionGenerar(seccionActual, contenidoSeccion.join('\n')));
        }
        seccionActual = 'INGREDIENTES';
        contenidoSeccion = [];
        // Capturar contenido en la misma línea
        final restoLinea = linea.replaceFirst(RegExp(r'INGREDIENTES:\s*', caseSensitive: false), '').trim();
        if (restoLinea.isNotEmpty) {
          contenidoSeccion.add(restoLinea);
        }
      } else if (linea.toUpperCase().startsWith('PREPARACIÓN:')) {
        if (seccionActual.isNotEmpty) {
          widgets.add(_buildSeccionGenerar(seccionActual, contenidoSeccion.join('\n')));
        }
        seccionActual = 'PREPARACIÓN';
        contenidoSeccion = [];
        final restoLinea = linea.replaceFirst(RegExp(r'PREPARACIÓN:\s*', caseSensitive: false), '').trim();
        if (restoLinea.isNotEmpty) {
          contenidoSeccion.add(restoLinea);
        }
      } else if (linea.toUpperCase().startsWith('INFORMACIÓN NUTRICIONAL:')) {
        if (seccionActual.isNotEmpty) {
          widgets.add(_buildSeccionGenerar(seccionActual, contenidoSeccion.join('\n')));
        }
        seccionActual = 'INFORMACIÓN NUTRICIONAL';
        contenidoSeccion = [];
        final restoLinea = linea.replaceFirst(RegExp(r'INFORMACIÓN NUTRICIONAL:\s*', caseSensitive: false), '').trim();
        if (restoLinea.isNotEmpty) {
          contenidoSeccion.add(restoLinea);
        }
      } else if (linea.toUpperCase().startsWith('TIEMPO DE PREPARACIÓN:') || linea.toUpperCase().startsWith('TIEMPO:')) {
        if (seccionActual.isNotEmpty) {
          widgets.add(_buildSeccionGenerar(seccionActual, contenidoSeccion.join('\n')));
        }
        seccionActual = 'TIEMPO';
        contenidoSeccion = [];
        // Capturar el tiempo que puede estar en la misma línea
        final restoLinea = linea
            .replaceFirst(RegExp(r'TIEMPO DE PREPARACIÓN:\s*', caseSensitive: false), '')
            .replaceFirst(RegExp(r'TIEMPO:\s*', caseSensitive: false), '')
            .trim();
        if (restoLinea.isNotEmpty) {
          contenidoSeccion.add(restoLinea);
        }
      } else if (linea.toUpperCase().startsWith('CONSEJOS:')) {
        if (seccionActual.isNotEmpty) {
          widgets.add(_buildSeccionGenerar(seccionActual, contenidoSeccion.join('\n')));
        }
        seccionActual = 'CONSEJOS';
        contenidoSeccion = [];
        final restoLinea = linea.replaceFirst(RegExp(r'CONSEJOS:\s*', caseSensitive: false), '').trim();
        if (restoLinea.isNotEmpty) {
          contenidoSeccion.add(restoLinea);
        }
      } else if (linea.trim().isNotEmpty) {
        contenidoSeccion.add(linea);
      }
    }

    if (seccionActual.isNotEmpty && contenidoSeccion.isNotEmpty) {
      widgets.add(_buildSeccionGenerar(seccionActual, contenidoSeccion.join('\n')));
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: widgets,
    );
  }

  Widget _buildNombreGenerar(String nombre) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 24),
      child: Text(
        nombre.trim(),
        style: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: verdeApp,
        ),
      ),
    );
  }

  Widget _buildSeccionGenerar(String tipo, String contenido) {
    IconData icon;
    Color color;

    switch (tipo) {
      case 'INGREDIENTES':
        icon = Icons.shopping_basket_outlined;
        color = Colors.orange[400]!;
        break;
      case 'PREPARACIÓN':
        icon = Icons.menu_book_outlined;
        color = Colors.blue[400]!;
        break;
      case 'INFORMACIÓN NUTRICIONAL':
        icon = Icons.bar_chart;
        color = verdeApp;
        break;
      case 'TIEMPO':
        icon = Icons.timer_outlined;
        color = Colors.purple[300]!;
        break;
      case 'CONSEJOS':
        icon = Icons.lightbulb_outline;
        color = Colors.amber[400]!;
        break;
      default:
        icon = Icons.info_outline;
        color = Colors.grey[400]!;
    }

    // Si es INFORMACIÓN NUTRICIONAL, usar diseño destacado
    if (tipo == 'INFORMACIÓN NUTRICIONAL') {
      return Container(
        margin: const EdgeInsets.only(bottom: 20),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: verdeApp.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: verdeApp.withValues(alpha: 0.3)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: verdeApp, size: 20),
                const SizedBox(width: 8),
                Text(
                  tipo,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: verdeApp,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              contenido.trim(),
              style: const TextStyle(
                fontSize: 13,
                height: 1.6,
                color: Colors.white,
              ),
            ),
          ],
        ),
      );
    }

    // Diseño normal para otras secciones
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 20),
              const SizedBox(width: 8),
              Text(
                tipo,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            contenido.trim(),
            style: const TextStyle(
              fontSize: 13,
              height: 1.6,
              color: Colors.white70,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Container(
      padding: const EdgeInsets.all(48),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          Icon(Icons.restaurant_menu, size: 64, color: Colors.white38),
          const SizedBox(height: 24),
          const Text(
            "Selecciona un tipo de comida",
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
          ),
          const SizedBox(height: 8),
          const Text(
            "Generaremos una receta personalizada\nsegún tus objetivos nutricionales",
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 13, color: Colors.white70, height: 1.5),
          ),
        ],
      ),
    );
  }
}