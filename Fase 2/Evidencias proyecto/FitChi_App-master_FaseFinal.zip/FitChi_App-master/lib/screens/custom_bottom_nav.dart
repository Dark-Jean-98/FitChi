import 'package:flutter/material.dart';

class CustomBottomNav extends StatelessWidget {
  final int currentIndex;
  static const Color verdeApp = Color(0xFF66BB6A);

  const CustomBottomNav({
    super.key,
    required this.currentIndex,
  });

  void _onItemTapped(BuildContext context, int index) {
    if (index == currentIndex) return;
    
    switch (index) {
      case 0: // Estadísticas
        // ANTERIOR: Mostraba un SnackBar
        // AHORA: Navega a la nueva página de gráficos corporales
        Navigator.pushReplacementNamed(context, '/graficos-corporales');
        break;
      case 1: // Meta Física
        Navigator.pushReplacementNamed(context, '/meta-fisica');
        break;
      case 2: // Home
        Navigator.pushReplacementNamed(context, '/home');
        break;
      case 3: // Mis Recetas
        Navigator.pushReplacementNamed(context, '/mis-recetas');
        break;
      case 4: // Historial
        Navigator.pushReplacementNamed(context, '/historial');
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(30),
          topRight: Radius.circular(30),
        ),
      ),
      child: BottomNavigationBar(
        currentIndex: currentIndex,
        onTap: (index) => _onItemTapped(context, index),
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.transparent,
        elevation: 0,
        selectedItemColor: verdeApp,
        unselectedItemColor: Colors.grey[600],
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.home, size: 32),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.restaurant_menu),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: '',
          ),
        ],
      ),
    );
  }
}