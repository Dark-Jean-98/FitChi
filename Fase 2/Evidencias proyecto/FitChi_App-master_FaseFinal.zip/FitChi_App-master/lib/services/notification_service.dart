import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest_all.dart' as tz;

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin _notifications = FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  Future<void> initialize() async {
    if (_initialized) return;

    tz.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation('America/Santiago'));

    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _notifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onNotificationTap,
    );

    _initialized = true;
  }

  void _onNotificationTap(NotificationResponse response) {
  }

  Future<void> requestPermissions() async {
    final androidPlugin = _notifications.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();

    if (androidPlugin != null) {
      // Solicitar permisos de notificaciones
      final granted = await androidPlugin.requestNotificationsPermission();
      print('📱 Permiso de notificaciones: ${granted == true ? "✅ Concedido" : "❌ Denegado"}');

      // Solicitar permiso de alarmas exactas (Android 12+)
      final exactAlarmGranted = await androidPlugin.requestExactAlarmsPermission();
      print('⏰ Permiso de alarmas exactas: ${exactAlarmGranted == true ? "✅ Concedido" : "❌ Denegado"}');

      if (exactAlarmGranted == false) {
        print('⚠️ IMPORTANTE: Las alarmas exactas están deshabilitadas. Ve a Configuración > Apps > FitChi > Alarmas y recordatorios');
      }
    }

    final iosPlugin = _notifications.resolvePlatformSpecificImplementation<
        IOSFlutterLocalNotificationsPlugin>();

    if (iosPlugin != null) {
      await iosPlugin.requestPermissions(
        alert: true,
        badge: true,
        sound: true,
      );
    }
  }

  Future<void> programarRecordatorioComida({
    required int id,
    required String tipoComida,
    required int hora,
    required int minuto,
  }) async {
    await initialize();

    print('🔔 Programando recordatorio: $tipoComida a las $hora:$minuto');

    final now = tz.TZDateTime.now(tz.local);
    var scheduledDate = tz.TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day,
      hora,
      minuto,
    );

    print('🕐 Ahora: $now');
    print('🕐 Fecha programada inicial: $scheduledDate');

    if (scheduledDate.isBefore(now)) {
      scheduledDate = scheduledDate.add(const Duration(days: 1));
      print('⏭️ La hora ya pasó, programando para mañana: $scheduledDate');
    }

    const androidDetails = AndroidNotificationDetails(
      'meal_reminders',
      'Recordatorios de Comidas',
      channelDescription: 'Recordatorios para las horas de comida',
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    String titulo = '';
    String mensaje = '';

    switch (tipoComida.toLowerCase()) {
      case 'desayuno':
        titulo = '🌅 Hora del desayuno';
        mensaje = '¡Es hora de tu desayuno! Revisa tu menú del día.';
        break;
      case 'almuerzo':
        titulo = '🍽️ Hora del almuerzo';
        mensaje = '¡Es hora de tu almuerzo! No olvides registrar lo que comes.';
        break;
      case 'cena':
        titulo = '🌙 Hora de la cena';
        mensaje = '¡Es hora de tu cena! Recuerda comer ligero por la noche.';
        break;
      case 'snack':
        titulo = '🍎 Hora del snack';
        mensaje = '¡Es hora de tu snack! Elige algo saludable.';
        break;
    }

    try {
      await _notifications.zonedSchedule(
        id,
        titulo,
        mensaje,
        scheduledDate,
        details,
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: DateTimeComponents.time,
      );
      print('✅ Recordatorio programado exitosamente: $titulo');
    } catch (e) {
      print('❌ Error programando recordatorio: $e');
    }
  }

  Future<void> programarRecordatoriosAgua({
    required int intervaloHoras,
    required int horaInicio,
    required int horaFin,
  }) async {
    await initialize();

    for (int i = 100; i < 200; i++) {
      await _notifications.cancel(i);
    }

    int idNotificacion = 100;
    for (int hora = horaInicio; hora <= horaFin; hora += intervaloHoras) {
      final now = tz.TZDateTime.now(tz.local);
      var scheduledDate = tz.TZDateTime(
        tz.local,
        now.year,
        now.month,
        now.day,
        hora,
        0,
      );

      if (scheduledDate.isBefore(now)) {
        scheduledDate = scheduledDate.add(const Duration(days: 1));
      }

      const androidDetails = AndroidNotificationDetails(
        'water_reminders',
        'Recordatorios de Agua',
        channelDescription: 'Recordatorios para tomar agua',
        importance: Importance.defaultImportance,
        priority: Priority.defaultPriority,
        icon: '@mipmap/ic_launcher',
      );

      const iosDetails = DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
      );

      const details = NotificationDetails(
        android: androidDetails,
        iOS: iosDetails,
      );

      await _notifications.zonedSchedule(
        idNotificacion,
        '💧 Hora de hidratarte',
        '¡Recuerda tomar agua! Mantente hidratado durante el día.',
        scheduledDate,
        details,
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: DateTimeComponents.time,
      );

      idNotificacion++;
    }
  }

  Future<void> cancelarRecordatoriosComidas() async {
    for (int i = 0; i < 100; i++) {
      await _notifications.cancel(i);
    }
  }

  Future<void> cancelarRecordatoriosAgua() async {
    for (int i = 100; i < 200; i++) {
      await _notifications.cancel(i);
    }
  }

  Future<void> cancelarTodos() async {
    await _notifications.cancelAll();
  }

  Future<List<PendingNotificationRequest>> obtenerRecordatoriosPendientes() async {
    return await _notifications.pendingNotificationRequests();
  }
}
