# ============================================================================
# FITCHI BACKEND API
# Backend FastAPI para la aplicación FitChi - Sistema de generación de recetas
# personalizadas y seguimiento nutricional
# ============================================================================

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from supabase import create_client, Client
import os
from datetime import datetime, timezone, timedelta
import pytz
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
import time
import requests
from urllib.parse import quote
import re
import json
from fractions import Fraction

# Cargar variables de entorno
load_dotenv()

# ============================================================================
# CONFIGURACIÓN DE LA APLICACIÓN
# ============================================================================

app = FastAPI(title="FitChi API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

supabase: Client = create_client(
    os.getenv("SUPABASE_URL"),
    os.getenv("SUPABASE_SERVICE_ROLE_KEY")
)

llm = ChatOpenAI(
    model="gpt-3.5-turbo",
    temperature=0.9,
    openai_api_key=os.getenv("OPENAI_API_KEY")
)

UNSPLASH_ACCESS_KEY = os.getenv("UNSPLASH_ACCESS_KEY", "")

# ============================================================================
# MODELOS DE DATOS
# ============================================================================

class RecetaRequest(BaseModel):
    user_id: str
    tipo_comida: str

class MenuRequest(BaseModel):
    user_id: str

class RegenerarRecetaRequest(BaseModel):
    user_id: str
    receta_id: int
    tipo_comida: str
    accion: str

class AsignarRecetaRequest(BaseModel):
    user_id: str
    tipo_comida: str
    dia_semana: str
    semana_offset: int
    contenido: str

class MarcarComidaRequest(BaseModel):
    user_id: str
    receta_id: int
    tipo_comida: str

class IniciarPlanRequest(BaseModel):
    user_id: str
    fecha_inicio: str

class RegistrarPesoRequest(BaseModel):
    user_id: str
    peso: float
    notas: str = ""

class ItemCompraRequest(BaseModel):
    user_id: str
    semana_offset: int
    categoria: str
    ingrediente: str
    comprado: bool = True

class ItemsCompraBatchRequest(BaseModel):
    user_id: str
    semana_offset: int
    items: list[dict]

class ChatMessageRequest(BaseModel):
    user_id: str
    message: str
    include_context: bool = True

class ActualizarAvatarRequest(BaseModel):
    user_id: str
    avatar_url: str

class GuardarRecetaChatRequest(BaseModel):
    user_id: str
    receta: dict

class ToggleIngredienteRequest(BaseModel):
    user_id: str
    ingrediente_id: str
    completado: bool

# ============================================================================
# FUNCIONES DE UTILIDADES - TIMEZONE
# ============================================================================

def obtener_timezone_chile():
    return pytz.timezone('America/Santiago')

def obtener_datetime_chile():
    return datetime.now(obtener_timezone_chile())

def obtener_numero_semana():
    return obtener_datetime_chile().isocalendar()[1]

def obtener_dia_semana_espanol(offset=0):
    dias = {
        0: "Lunes", 1: "Martes", 2: "Miércoles", 3: "Jueves",
        4: "Viernes", 5: "Sábado", 6: "Domingo"
    }
    ahora_chile = obtener_datetime_chile()
    dia_actual = (ahora_chile.weekday() + offset) % 7
    return dias[dia_actual]

def log_chile(mensaje):
    if 'ERROR' in mensaje:
        ahora = obtener_datetime_chile().strftime('%Y-%m-%d %H:%M:%S %Z')
        print(f"[{ahora}] {mensaje}")

# ============================================================================
# FUNCIONES DE UTILIDADES - IMÁGENES Y EXTRACCIÓN
# ============================================================================

def obtener_imagen_comida(nombre_receta: str, tipo_comida: str) -> str:
    try:
        keywords = nombre_receta.lower()
        for palabra in ['con', 'de', 'y', 'en', 'al', 'a la']:
            keywords = keywords.replace(f' {palabra} ', ' ')

        keywords_list = keywords.split()[:4]
        query = f"{tipo_comida} {' '.join(keywords_list)} chilean food healthy"

        if UNSPLASH_ACCESS_KEY:
            try:
                headers = {'Authorization': f'Client-ID {UNSPLASH_ACCESS_KEY}'}
                response = requests.get(
                    'https://api.unsplash.com/search/photos',
                    params={
                        'query': query,
                        'per_page': 1,
                        'orientation': 'squarish',
                        'content_filter': 'high'
                    },
                    headers=headers,
                    timeout=5
                )

                if response.status_code == 200:
                    data = response.json()
                    if data.get('results') and len(data['results']) > 0:
                        return data['results'][0]['urls']['regular']
            except:
                pass

        return f"https://source.unsplash.com/400x400/?{quote(tipo_comida)},food,healthy"
    except:
        return f"https://source.unsplash.com/400x400/?{tipo_comida},food"

def extraer_nombre_receta(contenido: str) -> str:
    try:
        if 'NOMBRE:' in contenido:
            nombre = contenido.split('NOMBRE:')[1].split('\n')[0].strip()
            if nombre:
                return nombre
        return "Receta saludable"
    except:
        return "Receta saludable"

def extraer_info_nutricional_completa(contenido: str) -> dict:
    info = {
        'nombre': extraer_nombre_receta(contenido),
        'tiempo_preparacion': None,
        'calorias': None,
        'proteinas': None,
        'carbohidratos': None,
        'grasas': None
    }

    try:
        tiempo_match = re.search(r'TIEMPO DE PREPARACIÓN:\s*(.+)', contenido, re.IGNORECASE)
        if tiempo_match:
            info['tiempo_preparacion'] = tiempo_match.group(1).strip()

        proteinas_match = re.search(r'Proteínas:\s*(\d+)', contenido, re.IGNORECASE)
        if proteinas_match:
            info['proteinas'] = int(proteinas_match.group(1))

        carbos_match = re.search(r'Carbohidratos:\s*(\d+)', contenido, re.IGNORECASE)
        if carbos_match:
            info['carbohidratos'] = int(carbos_match.group(1))

        grasas_match = re.search(r'Grasas:\s*(\d+)', contenido, re.IGNORECASE)
        if grasas_match:
            info['grasas'] = int(grasas_match.group(1))

        calorias_match = re.search(r'Calorías:\s*(\d+)', contenido, re.IGNORECASE)
        if calorias_match:
            info['calorias'] = int(calorias_match.group(1))
    except:
        pass

    return info

def guardar_en_historial(user_id: str, contenido: str, tipo_comida: str, imagen_url: str, receta_id: int = None):
    try:
        info = extraer_info_nutricional_completa(contenido)

        historial_data = {
            'usuario_id': user_id,
            'nombre': info['nombre'],
            'tipo_comida': tipo_comida,
            'contenido_completo': contenido,
            'calorias': info['calorias'],
            'proteinas': info['proteinas'],
            'carbohidratos': info['carbohidratos'],
            'grasas': info['grasas'],
            'tiempo_preparacion': info['tiempo_preparacion'],
            'imagen_url': imagen_url,
            'receta_id': receta_id,
            'is_favorito': False,
            'veces_vista': 1
        }

        result = supabase.table('historial_recetas').insert(historial_data).execute()
        return result.data[0]['id'] if result.data else None
    except Exception as e:
        log_chile(f"ERROR guardando en historial: {e}")
        return None

# ============================================================================
# LÓGICA DE GENERACIÓN DE RECETAS
# ============================================================================

def generar_receta_logic(user_id: str, tipo_comida: str, dia_semana: str = None, semana: int = None):
    usuario_response = supabase.table('usuarios').select("*").eq('id', user_id).execute()

    if not usuario_response.data or len(usuario_response.data) == 0:
        return None

    usuario = usuario_response.data[0]

    nivel_act = None
    if usuario.get('nivel_actividad_id'):
        try:
            nivel_response = supabase.table('cat_niveles_actividad').select(
                "id, codigo, descripcion, factor_actividad"
            ).eq('id', usuario['nivel_actividad_id']).single().execute()
            nivel_act = nivel_response.data
        except:
            pass

    objetivo = None
    if usuario.get('objetivo_nutricional_id'):
        try:
            objetivo_response = supabase.table('cat_objetivos_nutricionales').select(
                "id, codigo, descripcion, ajuste_calorico"
            ).eq('id', usuario['objetivo_nutricional_id']).single().execute()
            objetivo = objetivo_response.data
        except:
            pass

    if nivel_act and nivel_act.get('descripcion'):
        nivel_actividad_desc = nivel_act['descripcion']
        factor_actividad = nivel_act['factor_actividad']
    else:
        nivel_actividad_desc = usuario.get('nivel_actividad', 'Moderada (3-5 días/sem)')
        factor_map = {
            'Sedentario': 1.2,
            'Ligera': 1.375,
            'Moderada': 1.55,
            'Intensa': 1.725,
            'Muy intensa': 1.9
        }
        factor_actividad = 1.55
        for key, factor in factor_map.items():
            if key.lower() in nivel_actividad_desc.lower():
                factor_actividad = factor
                break

    if objetivo and objetivo.get('descripcion'):
        objetivo_nombre = objetivo['descripcion']
        ajuste_calorico = objetivo['ajuste_calorico']
    else:
        objetivo_nombre = usuario.get('objetivo_nutricional', 'Mantenimiento')
        ajuste_map = {
            'déficit': -500,
            'deficit': -500,
            'pérdida': -500,
            'recomposición': -300,
            'recomposicion': -300,
            'superávit': 400,
            'superavit': 400,
            'ganancia': 400,
            'mantenimiento': 0
        }
        ajuste_calorico = 0
        for key, ajuste in ajuste_map.items():
            if key in objetivo_nombre.lower():
                ajuste_calorico = ajuste
                break

    recetas_previas_response = supabase.table('recetas').select("contenido").eq(
        'usuario_id', user_id
    ).order('created_at', desc=True).limit(3).execute()

    ingredientes_previos = []
    if recetas_previas_response.data:
        for receta in recetas_previas_response.data:
            contenido = receta.get('contenido', '')
            if 'INGREDIENTES:' in contenido:
                ingredientes_previos.append(contenido.split('INGREDIENTES:')[1].split('PREPARACIÓN:')[0])

    contexto_previas = ""
    if ingredientes_previos:
        contexto_previas = f"\n\nRECETAS RECIENTES DEL USUARIO (EVITA REPETIR ESTOS INGREDIENTES):\n{chr(10).join(ingredientes_previos[:200])}"

    preferencias_response = supabase.table('preferencias_alimentarias').select(
        "preferencia"
    ).eq('usuario_id', user_id).execute()

    preferencias_lista = [p['preferencia'] for p in preferencias_response.data]
    preferencias = ', '.join(preferencias_lista) if preferencias_lista else 'sin restricciones especiales'

    calorias_totales = usuario.get('calorias_objetivo', 2000)
    proteinas_totales = usuario.get('proteinas_gramos', 150)
    carbos_totales = usuario.get('carbohidratos_gramos', 200)
    grasas_totales = usuario.get('grasas_gramos', 60)

    numero_comidas = usuario.get('numero_comidas', 4)

    calorias_por_comida = {
        'desayuno': int(calorias_totales * 0.25),
        'almuerzo': int(calorias_totales * 0.35),
        'cena': int(calorias_totales * 0.30),
        'snack': int(calorias_totales * 0.10)
    }

    calorias_comida = calorias_por_comida.get(tipo_comida, int(calorias_totales / numero_comidas))
    proteinas_comida = int((calorias_comida * 0.275) / 4)
    carbos_comida = int((calorias_comida * 0.475) / 4)
    grasas_comida = int((calorias_comida * 0.25) / 9)

    peso = usuario.get('peso', 'No especificado')
    altura = usuario.get('altura', 'No especificada')
    sexo = usuario.get('sexo', 'No especificado')

    edad = 'No especificada'
    fecha_nac = usuario.get('fecha_nacimiento')
    if fecha_nac:
        try:
            fecha_nac_dt = datetime.fromisoformat(str(fecha_nac))
            hoy = datetime.now()
            edad = hoy.year - fecha_nac_dt.year
            if hoy.month < fecha_nac_dt.month or (hoy.month == fecha_nac_dt.month and hoy.day < fecha_nac_dt.day):
                edad -= 1
        except:
            pass

    alergias = usuario.get('alergias') or 'ninguna'
    patologia = usuario.get('patologia') or 'ninguna'

    contexto_objetivo = {
        "Déficit": "enfocada en saciedad, alto contenido de fibra y proteínas, baja densidad calórica",
        "Pérdida de grasa": "enfocada en saciedad, alto contenido de fibra y proteínas, baja densidad calórica",
        "Superávit": "rica en proteínas de alta calidad, carbohidratos complejos para energía",
        "Ganancia muscular": "rica en proteínas de alta calidad, carbohidratos complejos para energía",
        "Mantenimiento": "balanceada y variada",
        "Recomposición": "alta en proteínas, moderada en carbohidratos, enfocada en nutrientes de calidad"
    }

    descripcion_objetivo = "balanceada"
    for key, desc in contexto_objetivo.items():
        if key.lower() in objetivo_nombre.lower():
            descripcion_objetivo = desc
            break

    prompt_template = PromptTemplate(
        input_variables=["sexo", "edad", "peso", "altura", "nivel_actividad", "objetivo",
                       "tipo_comida", "calorias_comida", "proteinas_comida", "carbos_comida",
                       "grasas_comida", "alergias", "patologia", "preferencias",
                       "descripcion_objetivo", "contexto_previas"],
        template="""Eres un nutricionista profesional chileno. Genera UNA receta saludable y práctica usando ESPAÑOL DE CHILE.
{contexto_previas}

IMPORTANTE - COCINA CHILENA REAL Y PRÁCTICA:
- Para DESAYUNO (tiempo: 10-15 min): desayunos típicos chilenos como:
  * Pan con palta y huevo
  * Avena con frutas chilenas (plátano, manzana)
  * Yogurt con granola y frutas
  * Pan integral con quesillo y tomate
  * Huevos revueltos con tomate
  * Batidos/smoothies con frutas locales

- Para ALMUERZO (tiempo: 20-30 min): platos principales chilenos como:
  * Pollo con ensalada chilena
  * Pescado al horno con verduras
  * Lentejas o porotos (preparación rápida)
  * Arroz con atún y verduras
  * Cazuela ligera
  * Pastel de choclo (versión fitness)

- Para CENA (tiempo: 15-20 min): cenas livianas chilenas como:
  * Ensaladas completas con proteína
  * Tortilla de verduras
  * Sopa de verduras
  * Palta rellena con atún
  * Wrap de pollo y verduras

- Para SNACK (tiempo: 5 min): colaciones rápidas como:
  * Frutas con frutos secos
  * Yogurt con frutas
  * Pan integral con palta
  * Barrita de cereal casera
  * Batido proteico

INGREDIENTES:
- SOLO ingredientes disponibles en supermercados chilenos (Líder, Jumbo, Unimarc, Santa Isabel)
- Usa nombres chilenos: palta (no aguacate), porotos (no frijoles), choclo (no maíz), zapallo, betarraga
- Ingredientes económicos y de fácil acceso

PREPARACIÓN:
- Métodos simples: hervido, al horno, salteado, a la plancha
- Tiempos de preparación REALISTAS para personas que trabajan
- Pasos claros y concisos

PERFIL DEL USUARIO:
- Sexo: {sexo} | Edad: {edad} años | Peso: {peso} kg | Altura: {altura} cm
- Nivel de actividad: {nivel_actividad}
- Objetivo: {objetivo}

REQUERIMIENTOS NUTRICIONALES ({tipo_comida}):
- Calorías: {calorias_comida} kcal (±50 kcal)
- Proteínas: {proteinas_comida}g (±5g)
- Carbohidratos: {carbos_comida}g (±10g)
- Grasas: {grasas_comida}g (±5g)

RESTRICCIONES:
- Alergias: {alergias}
- Condiciones médicas: {patologia}
- Preferencias: {preferencias}

La receta debe ser {descripcion_objetivo}, práctica, económica y con ingredientes accesibles en Chile.

FORMATO DE RESPUESTA (DEBES SEGUIR ESTE FORMATO EXACTAMENTE):

NOMBRE: [Escribe aquí un nombre atractivo y descriptivo de 2-5 palabras]

INGREDIENTES:
- [ingrediente] - [cantidad en medidas chilenas]

PREPARACIÓN:
1. [Paso detallado y simple]

INFORMACIÓN NUTRICIONAL:
Proteínas: [X]g
Carbohidratos: [X]g
Grasas: [X]g
Calorías: [X] kcal

TIEMPO DE PREPARACIÓN: [X minutos - REALISTA]

CONSEJOS:
[Tips personalizados para el objetivo {objetivo} y estilo de vida chileno]

Genera una receta PRÁCTICA, RÁPIDA y 100% adaptada a la cocina chilena cotidiana."""
    )

    formatted_prompt = prompt_template.format(
        sexo=sexo,
        edad=edad,
        peso=peso,
        altura=altura,
        nivel_actividad=nivel_actividad_desc,
        objetivo=objetivo_nombre,
        tipo_comida=tipo_comida.upper(),
        calorias_comida=calorias_comida,
        proteinas_comida=proteinas_comida,
        carbos_comida=carbos_comida,
        grasas_comida=grasas_comida,
        alergias=alergias,
        patologia=patologia,
        preferencias=preferencias,
        descripcion_objetivo=descripcion_objetivo,
        contexto_previas=contexto_previas
    )

    receta_contenido = llm.invoke(formatted_prompt).content
    nombre_receta = extraer_nombre_receta(receta_contenido)
    imagen_url = obtener_imagen_comida(nombre_receta, tipo_comida)

    receta_data = {
        'usuario_id': user_id,
        'contenido': receta_contenido,
        'tipo_comida': tipo_comida,
        'calorias_objetivo': calorias_comida,
        'proteinas_objetivo': proteinas_comida,
        'carbos_objetivo': carbos_comida,
        'grasas_objetivo': grasas_comida,
        'objetivo_nutricional': objetivo_nombre,
        'modelo': 'gpt-3.5-turbo-unsplash-v1',
        'dia_semana': dia_semana,
        'semana_numero': semana or obtener_numero_semana(),
        'es_sugerencia': True if dia_semana else False,
        'imagen_url': imagen_url,
        '_contenido_para_historial': receta_contenido
    }

    return receta_data

def generar_resto_semana_desde_martes(user_id: str, semana: int):
    dias = ["Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
    tipos_comida = ["desayuno", "almuerzo", "cena", "snack"]

    try:
        for dia in dias:
            for tipo in tipos_comida:
                receta_data = generar_receta_logic(user_id, tipo, dia, semana)
                if receta_data:
                    contenido_historial = receta_data.pop('_contenido_para_historial', receta_data['contenido'])
                    result = supabase.table('recetas').insert(receta_data).execute()

                    receta_id = None
                    saved_imagen = receta_data.get('imagen_url')

                    if result.data and len(result.data) > 0:
                        receta_id = result.data[0].get('id')
                        saved_imagen = result.data[0].get('imagen_url')

                    guardar_en_historial(
                        user_id=user_id,
                        contenido=contenido_historial,
                        tipo_comida=tipo,
                        imagen_url=saved_imagen,
                        receta_id=receta_id
                    )

                time.sleep(1)
    except Exception as e:
        log_chile(f"ERROR generando semana: {e}")

# ============================================================================
# FUNCIONES AUXILIARES - CHATBOT
# ============================================================================

def obtener_contexto_usuario(user_id: str) -> dict:
    contexto = {}

    try:
        perfil_response = supabase.table('usuarios').select(
            'nombre, peso, altura, sexo, objetivo_nutricional, alergias, patologia, calorias_objetivo'
        ).eq('id', user_id).execute()

        if perfil_response.data and len(perfil_response.data) > 0:
            contexto['perfil'] = perfil_response.data[0]

        recetas_response = supabase.table('recetas').select(
            'contenido, tipo_comida, calorias_objetivo, created_at'
        ).eq('usuario_id', user_id).order('created_at', desc=True).limit(5).execute()

        if recetas_response.data:
            recetas_resumidas = []
            for receta in recetas_response.data:
                nombre = extraer_nombre_receta(receta['contenido'])
                recetas_resumidas.append({
                    'nombre': nombre,
                    'tipo_comida': receta['tipo_comida'],
                    'calorias': receta['calorias_objetivo']
                })
            contexto['recetas_recientes'] = recetas_resumidas

        dia_hoy = obtener_dia_semana_espanol()
        semana_actual = obtener_numero_semana()
        
        menu_hoy = supabase.table('recetas').select(
            'contenido, tipo_comida'
        ).eq('usuario_id', user_id).eq('semana_numero', semana_actual).eq(
            'dia_semana', dia_hoy
        ).eq('es_sugerencia', True).execute()

        if menu_hoy.data:
            menu_resumido = []
            for comida in menu_hoy.data:
                nombre = extraer_nombre_receta(comida['contenido'])
                menu_resumido.append({
                    'tipo_comida': comida['tipo_comida'],
                    'nombre': nombre
                })
            contexto['menu_hoy'] = menu_resumido
    except:
        pass

    return contexto

def obtener_historial_conversacion(user_id: str, limit: int = 10) -> list:
    try:
        response = supabase.table('chat_messages').select(
            'role, content'
        ).eq('user_id', user_id).neq('role', 'system').order(
            'created_at', desc=False
        ).limit(limit).execute()

        mensajes = []
        for msg in response.data:
            mensajes.append({
                "role": msg['role'],
                "content": msg['content']
            })
        return mensajes
    except:
        return []

def construir_prompt_sistema(contexto_usuario: dict) -> str:
    prompt_base = """Eres FitChi Assistant, un asistente de nutrición y fitness chileno, inteligente y amigable.

Tu propósito es ayudar a los usuarios con:
- Consejos sobre nutrición y alimentación saludable
- Sugerencias de recetas chilenas y planes de comida
- Modificaciones a recetas según preferencias o restricciones
- Información sobre calorías, macronutrientes y nutrición
- Motivación y apoyo para alcanzar objetivos de salud
- Responder preguntas sobre su menú semanal y recetas

IMPORTANTE:
- Sé conversacional, amigable y motivador
- Usa ESPAÑOL DE CHILE (palta, porotos, choclo, etc.)
- Proporciona información basada en evidencia
- Si no estás seguro de algo médico, recomienda consultar a un profesional
- Mantén las respuestas concisas pero informativas (máximo 3-4 párrafos)
- Personaliza tus respuestas según el contexto del usuario
- Si preguntan por recetas, sugiere opciones chilenas y prácticas
"""

    if 'perfil' in contexto_usuario:
        perfil = contexto_usuario['perfil']
        info_perfil = f"""
CONTEXTO DEL USUARIO:
- Nombre: {perfil.get('nombre', 'Usuario')}
- Peso actual: {perfil.get('peso', 'N/A')} kg
- Altura: {perfil.get('altura', 'N/A')} cm
- Sexo: {perfil.get('sexo', 'N/A')}
- Objetivo: {perfil.get('objetivo_nutricional', 'N/A')}
- Calorías objetivo: {perfil.get('calorias_objetivo', 'N/A')} kcal/día
- Alergias: {perfil.get('alergias', 'Ninguna')}
- Condiciones médicas: {perfil.get('patologia', 'Ninguna')}
"""
        prompt_base += info_perfil

    if 'menu_hoy' in contexto_usuario and contexto_usuario['menu_hoy']:
        menu_info = f"\nMENÚ DE HOY ({obtener_dia_semana_espanol()}):\n"
        for comida in contexto_usuario['menu_hoy']:
            menu_info += f"- {comida['tipo_comida'].capitalize()}: {comida['nombre']}\n"
        prompt_base += menu_info

    if 'recetas_recientes' in contexto_usuario and contexto_usuario['recetas_recientes']:
        recetas_info = "\nRECETAS RECIENTES GENERADAS:\n"
        for i, receta in enumerate(contexto_usuario['recetas_recientes'][:3], 1):
            recetas_info += f"{i}. {receta['nombre']} ({receta['tipo_comida']}) - {receta['calorias']}kcal\n"
        prompt_base += recetas_info

    prompt_base += """
Usa esta información para personalizar tus respuestas, pero no la menciones explícitamente a menos que sea relevante para la pregunta del usuario.
"""

    return prompt_base

def construir_prompt_sistema_con_receta(contexto_usuario: dict) -> str:
    perfil = contexto_usuario.get('perfil', {})

    calorias_por_comida = {
        'desayuno': int(perfil.get('calorias_objetivo', 2000) * 0.25),
        'almuerzo': int(perfil.get('calorias_objetivo', 2000) * 0.35),
        'cena': int(perfil.get('calorias_objetivo', 2000) * 0.30),
        'snack': int(perfil.get('calorias_objetivo', 2000) * 0.10)
    }

    prompt = f"""Eres un nutricionista chileno experto. Vas a generar una receta personalizada.

PERFIL DEL USUARIO:
- Objetivo: {perfil.get('objetivo_nutricional', 'Mantenimiento')}
- Calorías diarias: {perfil.get('calorias_objetivo', 2000)} kcal
- Peso: {perfil.get('peso')}kg | Altura: {perfil.get('altura')}cm
- Alergias: {perfil.get('alergias', 'Ninguna')}
- Restricciones: {perfil.get('patologia', 'Ninguna')}

IMPORTANTE - FORMATO DE RESPUESTA:

Tu respuesta DEBE tener EXACTAMENTE este formato (SIN incluir los títulos "PARTE 1" ni "PARTE 2"):

PRIMERO, el JSON dentro de ```json ``` :
```json
{{
  "nombre": "Nombre atractivo de la receta chilena",
  "descripcion": "Descripción breve que motive al usuario",
  "tiempo_preparacion": "20 minutos",
  "dificultad": "Fácil",
  "porciones": 1,
  "calorias_por_porcion": 450,
  "proteinas": 35,
  "carbohidratos": 45,
  "grasas": 15,
  "ingredientes": [
    {{"nombre": "Pechuga de pollo", "cantidad": "150g", "categoria": "Proteínas"}},
    {{"nombre": "Arroz integral", "cantidad": "80g", "categoria": "Carbohidratos"}},
    {{"nombre": "Brócoli", "cantidad": "100g", "categoria": "Verduras"}},
    {{"nombre": "Aceite de oliva", "cantidad": "1 cdta", "categoria": "Grasas"}}
  ],
  "pasos": [
    "Cocinar el arroz integral en agua con sal durante 20 minutos",
    "Cortar la pechuga en cubos y cocinar a la plancha con especias",
    "Cocer el brócoli al vapor por 5-7 minutos",
    "Servir todo junto y rociar con aceite de oliva"
  ],
  "imagen_url": null
}}
```

SEGUNDO, DESPUÉS del JSON, escribe tu mensaje amigable y motivador (2-3 párrafos):
- Presenta la receta de forma atractiva
- Explica por qué es buena para su objetivo ({perfil.get('objetivo_nutricional')})
- Da consejos prácticos
- Sé cercano y motivador

NO incluyas títulos como "PARTE 1", "PARTE 2", "JSON", "MENSAJE" en tu respuesta.
Solo el bloque ```json``` seguido del texto amigable.

REGLAS:
- Usa ingredientes chilenos: palta, porotos, choclo, zapallo, etc.
- Disponibles en supermercados Líder, Jumbo, Unimarc
- Métodos simples: plancha, horno, hervido
- Tiempos realistas (10-30 min máximo)
- Ajusta calorías según tipo de comida solicitada
- NO uses jerga técnica complicada
- Sé amigable y motivador

Si el usuario pide desayuno: {calorias_por_comida['desayuno']}kcal aprox.
Si pide almuerzo: {calorias_por_comida['almuerzo']}kcal aprox.
Si pide cena: {calorias_por_comida['cena']}kcal aprox.
Si pide snack: {calorias_por_comida['snack']}kcal aprox.
"""

    return prompt

def detectar_solicitud_receta(mensaje: str) -> bool:
    keywords_receta = [
        'receta', 'genera', 'crea', 'dame', 'prepara', 'cocinar',
        'comida', 'plato', 'almuerzo', 'cena', 'desayuno', 'snack',
        'menú', 'menu', 'cocina', 'preparar'
    ]
    mensaje_lower = mensaje.lower()
    return any(keyword in mensaje_lower for keyword in keywords_receta)

def extraer_receta_json(respuesta: str) -> tuple:
    json_match = re.search(r'```json\s*(\{.*?\})\s*```', respuesta, re.DOTALL)

    if json_match:
        try:
            receta_dict = json.loads(json_match.group(1))
            mensaje_limpio = re.sub(r'```json\s*\{.*?\}\s*```', '', respuesta, flags=re.DOTALL).strip()
            mensaje_limpio = '\n'.join([line for line in mensaje_limpio.split('\n') if line.strip()])
            return mensaje_limpio, receta_dict
        except:
            return respuesta, None

    return respuesta, None

def guardar_mensajes_chat(user_id: str, mensaje_usuario: str, mensaje_asistente: str, tokens_usados: int):
    try:
        mensajes_insertar = [
            {
                'user_id': user_id,
                'role': 'user',
                'content': mensaje_usuario,
                'tokens_used': 0
            },
            {
                'user_id': user_id,
                'role': 'assistant',
                'content': mensaje_asistente,
                'tokens_used': tokens_usados
            }
        ]
        supabase.table('chat_messages').insert(mensajes_insertar).execute()
    except:
        pass

# ============================================================================
# FUNCIONES AUXILIARES - LISTA DE COMPRAS
# ============================================================================

def parsear_cantidad(cantidad_str: str) -> dict:
    try:
        cantidad_str = cantidad_str.strip().lower()

        fraccion_match = re.match(r'(\d+)/(\d+)\s*(.*)', cantidad_str)
        if fraccion_match:
            numerador = int(fraccion_match.group(1))
            denominador = int(fraccion_match.group(2))
            valor = numerador / denominador
            unidad = fraccion_match.group(3).strip() or 'unidad'
            return {'valor': valor, 'unidad': unidad}

        numero_match = re.match(r'([\d.]+)\s*(.*)', cantidad_str)
        if numero_match:
            valor = float(numero_match.group(1))
            unidad = numero_match.group(2).strip() or 'unidad'
            return {'valor': valor, 'unidad': unidad}

        return {'valor': 1.0, 'unidad': cantidad_str}
    except:
        return {'valor': 1.0, 'unidad': cantidad_str}

def formatear_cantidad(valor: float, unidad: str) -> str:
    try:
        if valor == int(valor):
            return f"{int(valor)}{unidad}" if unidad in ['g', 'kg', 'ml', 'l'] else f"{int(valor)} {unidad}".strip()

        if valor < 1:
            frac = Fraction(valor).limit_denominator(8)
            if abs(float(frac) - valor) < 0.01:
                return f"{frac.numerator}/{frac.denominator} {unidad}".strip()

        if valor > 1:
            parte_entera = int(valor)
            parte_decimal = valor - parte_entera

            if parte_decimal > 0.01:
                frac = Fraction(parte_decimal).limit_denominator(8)
                if abs(float(frac) - parte_decimal) < 0.01:
                    return f"{parte_entera} {frac.numerator}/{frac.denominator} {unidad}".strip()

        return f"{valor:.1f} {unidad}".strip()
    except:
        return f"{valor} {unidad}".strip()

def agrupar_ingredientes_mejorado(recetas: list) -> dict:
    ingredientes_agrupados = {}

    for receta in recetas:
        contenido = receta.get('contenido', '')

        if 'INGREDIENTES:' in contenido:
            ingredientes_seccion = contenido.split('INGREDIENTES:')[1].split('PREPARACIÓN:')[0]
            lineas = ingredientes_seccion.strip().split('\n')

            for linea in lineas:
                linea = linea.strip()
                if not linea or linea.startswith('PREPARACIÓN'):
                    continue

                linea = linea.lstrip('•-–—*· ')

                if ' - ' in linea:
                    partes = linea.split(' - ', 1)
                    nombre_ingrediente = partes[0].strip().title()
                    cantidad_str = partes[1].strip()

                    cantidad_parseada = parsear_cantidad(cantidad_str)
                    valor = cantidad_parseada['valor']
                    unidad = cantidad_parseada['unidad']

                    unidad_normalizada = unidad.lower()
                    if unidad_normalizada in ['unidades', 'uni', 'u', 'unidad']:
                        unidad_normalizada = 'unidad'
                    elif unidad_normalizada in ['gramos', 'gr']:
                        unidad_normalizada = 'g'
                    elif unidad_normalizada in ['kilogramos', 'kilo', 'kilos']:
                        unidad_normalizada = 'kg'
                    elif unidad_normalizada in ['mililitros', 'ml']:
                        unidad_normalizada = 'ml'
                    elif unidad_normalizada in ['litros', 'l']:
                        unidad_normalizada = 'l'
                    elif unidad_normalizada in ['taza', 'tazas']:
                        unidad_normalizada = 'tazas'
                    elif unidad_normalizada in ['cucharada', 'cucharadas', 'cda']:
                        unidad_normalizada = 'cdas'
                    elif unidad_normalizada in ['cucharadita', 'cucharaditas', 'cdta']:
                        unidad_normalizada = 'cdta'

                    if nombre_ingrediente not in ingredientes_agrupados:
                        ingredientes_agrupados[nombre_ingrediente] = {
                            'unidades': {}
                        }

                    unidades_dict = ingredientes_agrupados[nombre_ingrediente]['unidades']
                    if unidad_normalizada in unidades_dict:
                        unidades_dict[unidad_normalizada] += valor
                    else:
                        unidades_dict[unidad_normalizada] = valor

    resultado_final = {}

    for ingrediente, datos in ingredientes_agrupados.items():
        unidades = datos['unidades']

        if len(unidades) > 1:
            cantidades_formateadas = []
            for unidad, valor in sorted(unidades.items()):
                cantidades_formateadas.append(formatear_cantidad(valor, unidad))
            cantidad_final = ' + '.join(cantidades_formateadas)
        else:
            unidad, valor = list(unidades.items())[0]
            cantidad_final = formatear_cantidad(valor, unidad)

        categoria = determinar_categoria_ingrediente(ingrediente)

        if categoria not in resultado_final:
            resultado_final[categoria] = []

        resultado_final[categoria].append({
            'nombre': ingrediente,
            'cantidad': cantidad_final
        })

    return resultado_final

def determinar_categoria_ingrediente(nombre: str) -> str:
    nombre_lower = nombre.lower()

    proteinas = [
        'pollo', 'pavo', 'pechuga', 'carne', 'vacuno', 'cerdo', 'pescado',
        'salmón', 'atún', 'merluza', 'reineta', 'huevo', 'huevos',
        'tofu', 'tempeh', 'lentejas', 'garbanzos', 'porotos'
    ]
    if any(p in nombre_lower for p in proteinas):
        return 'Proteínas'

    verduras = [
        'lechuga', 'tomate', 'cebolla', 'ajo', 'zanahoria', 'brócoli',
        'espinaca', 'acelga', 'apio', 'pimentón', 'pepino', 'zapallo',
        'calabaza', 'berenjena', 'champiñón', 'palta', 'repollo'
    ]
    if any(v in nombre_lower for v in verduras):
        return 'Verduras y Hortalizas'

    frutas = [
        'manzana', 'plátano', 'banana', 'naranja', 'limón', 'frutilla',
        'uva', 'sandía', 'melón', 'pera', 'durazno', 'kiwi', 'piña'
    ]
    if any(f in nombre_lower for f in frutas):
        return 'Frutas'

    carbohidratos = [
        'arroz', 'pasta', 'fideos', 'pan', 'avena', 'quinoa',
        'papa', 'camote', 'batata', 'choclo', 'maíz'
    ]
    if any(c in nombre_lower for c in carbohidratos):
        return 'Carbohidratos'

    lacteos = [
        'leche', 'yogurt', 'yogur', 'queso', 'quesillo', 'mantequilla',
        'crema', 'ricotta', 'parmesano'
    ]
    if any(l in nombre_lower for l in lacteos):
        return 'Lácteos'

    grasas = [
        'aceite', 'oliva', 'manteca', 'margarina'
    ]
    if any(g in nombre_lower for g in grasas):
        return 'Aceites y Grasas'

    condimentos = [
        'sal', 'pimienta', 'orégano', 'comino', 'ají', 'merkén',
        'curry', 'paprika', 'cilantro', 'perejil', 'albahaca',
        'salsa', 'vinagre', 'mostaza', 'ketchup', 'mayonesa'
    ]
    if any(c in nombre_lower for c in condimentos):
        return 'Condimentos y Especias'

    return 'Otros'

# ============================================================================
# ENDPOINTS - INFORMACIÓN Y DEBUG
# ============================================================================

@app.get("/")
async def root():
    return {"message": "FitChi API - Sistema completo de nutrición", "version": "2.5.0"}

@app.get("/api/debug/timezone")
async def debug_timezone():
    chile_tz = pytz.timezone('America/Santiago')
    chile_now = datetime.now(chile_tz)

    dias = {
        0: "Lunes", 1: "Martes", 2: "Miércoles", 3: "Jueves",
        4: "Viernes", 5: "Sábado", 6: "Domingo"
    }
    dia_chile = dias[chile_now.weekday()]

    return {
        "chile_time": chile_now.strftime('%Y-%m-%d %H:%M:%S %Z'),
        "dia_detectado": dia_chile,
        "semana_numero": chile_now.isocalendar()[1],
    }

# ============================================================================
# ENDPOINTS - GENERACIÓN DE RECETAS
# ============================================================================

@app.post("/api/generar-receta")
async def generar_receta(request: RecetaRequest):
    try:
        receta_data = generar_receta_logic(request.user_id, request.tipo_comida)

        if not receta_data:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")

        contenido_historial = receta_data.pop('_contenido_para_historial', receta_data['contenido'])
        result = supabase.table('recetas').insert(receta_data).execute()

        receta_id = None
        saved_imagen = receta_data.get('imagen_url')

        if result.data and len(result.data) > 0:
            receta_id = result.data[0].get('id')
            saved_imagen = result.data[0].get('imagen_url')

        guardar_en_historial(
            user_id=request.user_id,
            contenido=contenido_historial,
            tipo_comida=request.tipo_comida,
            imagen_url=saved_imagen,
            receta_id=receta_id
        )

        return {
            "receta_completa": receta_data['contenido'],
            "imagen_url": saved_imagen
        }
    except Exception as e:
        import traceback
        log_chile(f"ERROR: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/inicializar-menu-usuario")
async def inicializar_menu_usuario(request: RecetaRequest, background_tasks: BackgroundTasks):
    try:
        user_id = request.user_id
        semana_actual = obtener_numero_semana()

        menu_existente = supabase.table('recetas').select("id").eq(
            'usuario_id', user_id
        ).eq('semana_numero', semana_actual).limit(1).execute()

        if menu_existente.data:
            return {
                "message": "Usuario ya tiene menú de esta semana",
                "status": "exists"
            }

        dia_inicio = "Lunes"
        recetas_lunes = []
        
        for tipo in ["desayuno", "almuerzo", "cena", "snack"]:
            receta_data = generar_receta_logic(user_id, tipo, dia_inicio, semana_actual)
            if receta_data:
                contenido_historial = receta_data.pop('_contenido_para_historial', receta_data['contenido'])
                result = supabase.table('recetas').insert(receta_data).execute()

                receta_id = None
                saved_imagen = receta_data.get('imagen_url')

                if result.data and len(result.data) > 0:
                    receta_id = result.data[0].get('id')
                    saved_imagen = result.data[0].get('imagen_url')

                guardar_en_historial(
                    user_id=user_id,
                    contenido=contenido_historial,
                    tipo_comida=tipo,
                    imagen_url=saved_imagen,
                    receta_id=receta_id
                )

                recetas_lunes.append(tipo)

        background_tasks.add_task(generar_resto_semana_desde_martes, user_id, semana_actual)

        return {
            "message": "Generando tu semana completa con imágenes...",
            "status": "processing",
            "recetas_lunes": recetas_lunes,
            "semana": semana_actual
        }
    except Exception as e:
        import traceback
        log_chile(f"ERROR: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# ENDPOINTS - CONSULTA DE MENÚ E HISTORIAL
# ============================================================================

@app.get("/api/menu-semanal/{user_id}")
async def obtener_menu_semanal(user_id: str, semana_offset: int = 0):
    try:
        semana_actual = obtener_numero_semana()
        semana_objetivo = semana_actual + semana_offset

        if semana_objetivo > 52:
            semana_objetivo = semana_objetivo - 52
        elif semana_objetivo < 1:
            semana_objetivo = 52 + semana_objetivo

        recetas = supabase.table('recetas').select(
            "id, contenido, tipo_comida, dia_semana, calorias_objetivo, imagen_url, created_at"
        ).eq('usuario_id', user_id).eq('semana_numero', semana_objetivo).eq('es_sugerencia', True).execute()

        menu_organizado = {}
        dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]

        for dia in dias:
            menu_organizado[dia] = {
                "desayuno": None,
                "almuerzo": None,
                "cena": None,
                "snack": None
            }

        for receta in recetas.data:
            dia = receta['dia_semana']
            tipo = receta['tipo_comida']
            nombre = extraer_nombre_receta(receta['contenido'])

            if dia in menu_organizado:
                menu_organizado[dia][tipo] = {
                    'id': receta['id'],
                    'nombre': nombre,
                    'calorias': receta['calorias_objetivo'],
                    'contenido_completo': receta['contenido'],
                    'imagen_url': receta.get('imagen_url')
                }

        total_esperadas = 28
        total_generadas = len(recetas.data)
        progreso = (total_generadas / total_esperadas) * 100

        return {
            "menu": menu_organizado,
            "semana": semana_objetivo,
            "progreso": round(progreso),
            "completo": total_generadas == total_esperadas
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/historial-recetas/{user_id}")
async def obtener_historial(user_id: str):
    try:
        recetas = supabase.table('historial_recetas').select(
            "id, nombre, tipo_comida, calorias, proteinas, carbohidratos, grasas, "
            "tiempo_preparacion, imagen_url, created_at, contenido_completo, is_favorito"
        ).eq('usuario_id', user_id).order('created_at', desc=True).limit(100).execute()

        recetas_formateadas = []
        for receta in recetas.data:
            recetas_formateadas.append({
                'id': receta['id'],
                'nombre': receta['nombre'],
                'tipo_comida': receta['tipo_comida'],
                'calorias': receta['calorias'],
                'proteinas': receta.get('proteinas'),
                'carbohidratos': receta.get('carbohidratos'),
                'grasas': receta.get('grasas'),
                'fecha': receta['created_at'],
                'contenido_completo': receta['contenido_completo'],
                'imagen_url': receta.get('imagen_url'),
                'tiempo_preparacion': receta.get('tiempo_preparacion', 'N/A'),
                'is_favorito': receta.get('is_favorito', False)
            })

        return {"recetas": recetas_formateadas}
    except Exception as e:
        log_chile(f"ERROR obteniendo historial: {e}")
        import traceback
        log_chile(traceback.format_exc())
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# ENDPOINTS - GESTIÓN DE MENÚ SEMANAL
# ============================================================================

@app.post("/api/generar-menu-proximo")
async def generar_menu_proximo(request: MenuRequest, background_tasks: BackgroundTasks):
    try:
        user_id = request.user_id
        semana_actual = obtener_numero_semana()
        proxima_semana = semana_actual + 1

        if proxima_semana > 52:
            proxima_semana = 1

        menu_existente = supabase.table('recetas').select("id").eq(
            'usuario_id', user_id
        ).eq('semana_numero', proxima_semana).limit(1).execute()

        if menu_existente.data:
            raise HTTPException(
                status_code=400,
                detail=f"Ya existe un menú para la semana {proxima_semana}"
            )

        dia_inicio = "Lunes"
        recetas_lunes = []

        for tipo in ["desayuno", "almuerzo", "cena", "snack"]:
            receta_data = generar_receta_logic(user_id, tipo, dia_inicio, proxima_semana)
            if receta_data:
                contenido_historial = receta_data.pop('_contenido_para_historial', receta_data['contenido'])
                result = supabase.table('recetas').insert(receta_data).execute()

                receta_id = None
                saved_imagen = receta_data.get('imagen_url')

                if result.data and len(result.data) > 0:
                    receta_id = result.data[0].get('id')
                    saved_imagen = result.data[0].get('imagen_url')

                guardar_en_historial(
                    user_id=user_id,
                    contenido=contenido_historial,
                    tipo_comida=tipo,
                    imagen_url=saved_imagen,
                    receta_id=receta_id
                )

                recetas_lunes.append(tipo)

        background_tasks.add_task(generar_resto_semana_desde_martes, user_id, proxima_semana)

        return {
            "message": f"Generando menú para la semana {proxima_semana}...",
            "status": "processing",
            "recetas_lunes": recetas_lunes,
            "semana": proxima_semana
        }
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        log_chile(f"ERROR generando menú próximo: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/asignar-receta-semana")
async def asignar_receta_semana(request: AsignarRecetaRequest):
    try:
        semana_actual = obtener_numero_semana()
        semana_objetivo = semana_actual + request.semana_offset

        if semana_objetivo > 52:
            semana_objetivo = semana_objetivo - 52
        elif semana_objetivo < 1:
            semana_objetivo = 52 + semana_objetivo

        info = extraer_info_nutricional_completa(request.contenido)
        imagen_url = obtener_imagen_comida(info['nombre'], request.tipo_comida)

        receta_existente = supabase.table('recetas').select("id").eq(
            'usuario_id', request.user_id
        ).eq('semana_numero', semana_objetivo).eq(
            'dia_semana', request.dia_semana
        ).eq('tipo_comida', request.tipo_comida).execute()

        if receta_existente.data:
            update_data = {
                'contenido': request.contenido,
                'imagen_url': imagen_url,
                'calorias_objetivo': info.get('calorias'),
                'proteinas_objetivo': info.get('proteinas'),
                'carbos_objetivo': info.get('carbohidratos'),
                'grasas_objetivo': info.get('grasas'),
            }
            result = supabase.table('recetas').update(update_data).eq(
                'id', receta_existente.data[0]['id']
            ).execute()
        else:
            receta_data = {
                'usuario_id': request.user_id,
                'contenido': request.contenido,
                'tipo_comida': request.tipo_comida,
                'dia_semana': request.dia_semana,
                'semana_numero': semana_objetivo,
                'es_sugerencia': True,
                'imagen_url': imagen_url,
                'calorias_objetivo': info.get('calorias'),
                'proteinas_objetivo': info.get('proteinas'),
                'carbos_objetivo': info.get('carbohidratos'),
                'grasas_objetivo': info.get('grasas'),
                'modelo': 'manual-assignment'
            }
            result = supabase.table('recetas').insert(receta_data).execute()

        if not result.data:
            raise HTTPException(status_code=500, detail="Error asignando receta")

        return {
            "success": True,
            "message": f"Receta asignada a {request.dia_semana}",
            "semana": semana_objetivo
        }
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        log_chile(f"ERROR asignando receta: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# ENDPOINTS - REGISTRO DE COMIDAS CONSUMIDAS
# ============================================================================

@app.post("/api/marcar-comida-consumida")
async def marcar_comida_consumida(request: MarcarComidaRequest):
    try:
        receta = supabase.table('recetas').select(
            "id, contenido, tipo_comida, calorias_objetivo, proteinas_objetivo, carbos_objetivo, grasas_objetivo"
        ).eq('id', request.receta_id).eq('usuario_id', request.user_id).execute()

        if not receta.data or len(receta.data) == 0:
            raise HTTPException(status_code=404, detail="Receta no encontrada")

        receta_data = receta.data[0]
        nombre = extraer_nombre_receta(receta_data['contenido'])

        ahora_chile = obtener_datetime_chile()
        fecha_actual = ahora_chile.date()
        hora_actual = ahora_chile.time()

        registro_existente = supabase.table('registro_comidas').select("id").eq(
            'usuario_id', request.user_id
        ).eq('receta_id', request.receta_id).eq('fecha', str(fecha_actual)).execute()

        if registro_existente.data:
            raise HTTPException(status_code=400, detail="Esta comida ya fue registrada hoy")

        registro_data = {
            'usuario_id': request.user_id,
            'receta_id': request.receta_id,
            'tipo_comida': receta_data['tipo_comida'],
            'nombre_comida': nombre,
            'calorias': receta_data['calorias_objetivo'],
            'proteinas': receta_data.get('proteinas_objetivo'),
            'carbohidratos': receta_data.get('carbos_objetivo'),
            'grasas': receta_data.get('grasas_objetivo'),
            'fecha': str(fecha_actual),
            'hora': str(hora_actual)
        }

        result = supabase.table('registro_comidas').insert(registro_data).execute()

        if not result.data:
            raise HTTPException(status_code=500, detail="Error registrando comida")

        return {
            "success": True,
            "message": f"¡{nombre} registrada como consumida!",
            "calorias": receta_data['calorias_objetivo']
        }
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        log_chile(f"ERROR marcando comida: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/resumen-dia/{user_id}")
async def obtener_resumen_dia(user_id: str):
    try:
        fecha_actual = obtener_datetime_chile().date()

        usuario = supabase.table('usuarios').select(
            "calorias_objetivo, proteinas_gramos, carbohidratos_gramos, grasas_gramos"
        ).eq('id', user_id).execute()

        if not usuario.data or len(usuario.data) == 0:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")

        usuario_data = usuario.data[0]
        calorias_objetivo = usuario_data.get('calorias_objetivo', 2000)
        proteinas_objetivo = usuario_data.get('proteinas_gramos', 150)
        carbohidratos_objetivo = usuario_data.get('carbohidratos_gramos', 200)
        grasas_objetivo = usuario_data.get('grasas_gramos', 60)

        comidas_hoy = supabase.table('registro_comidas').select(
            "id, nombre_comida, calorias, proteinas, carbohidratos, grasas, hora, tipo_comida, receta_id"
        ).eq('usuario_id', user_id).eq('fecha', str(fecha_actual)).order('hora', desc=True).execute()

        calorias_consumidas = 0
        proteinas_consumidas = 0
        carbohidratos_consumidos = 0
        grasas_consumidas = 0

        for comida in comidas_hoy.data:
            calorias_consumidas += comida.get('calorias', 0)
            proteinas_consumidas += comida.get('proteinas', 0) or 0
            carbohidratos_consumidos += comida.get('carbohidratos', 0) or 0
            grasas_consumidas += comida.get('grasas', 0) or 0

        calorias_restantes = calorias_objetivo - calorias_consumidas
        proteinas_restantes = proteinas_objetivo - proteinas_consumidas
        carbohidratos_restantes = carbohidratos_objetivo - carbohidratos_consumidos
        grasas_restantes = grasas_objetivo - grasas_consumidas

        ultima_comida = None
        if comidas_hoy.data and len(comidas_hoy.data) > 0:
            ultima = comidas_hoy.data[0]

            imagen_url = None
            if ultima.get('receta_id'):
                receta = supabase.table('recetas').select("imagen_url").eq(
                    'id', ultima['receta_id']
                ).execute()
                if receta.data and len(receta.data) > 0:
                    imagen_url = receta.data[0].get('imagen_url')

            ultima_comida = {
                'nombre': ultima['nombre_comida'],
                'calorias': ultima['calorias'],
                'hora': ultima['hora'],
                'tipo_comida': ultima.get('tipo_comida'),
                'imagen_url': imagen_url
            }

        return {
            "calorias_objetivo": calorias_objetivo,
            "calorias_consumidas": calorias_consumidas,
            "calorias_restantes": calorias_restantes,
            "proteinas_objetivo": proteinas_objetivo,
            "proteinas_consumidas": proteinas_consumidas,
            "proteinas_restantes": proteinas_restantes,
            "carbohidratos_objetivo": carbohidratos_objetivo,
            "carbohidratos_consumidos": carbohidratos_consumidos,
            "carbohidratos_restantes": carbohidratos_restantes,
            "grasas_objetivo": grasas_objetivo,
            "grasas_consumidas": grasas_consumidas,
            "grasas_restantes": grasas_restantes,
            "ultima_comida": ultima_comida,
            "comidas_registradas": len(comidas_hoy.data) if comidas_hoy.data else 0,
            "fecha": str(fecha_actual)
        }
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        log_chile(f"ERROR obteniendo resumen: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# ENDPOINTS - CALENDARIO DE SEGUIMIENTO Y PESO
# ============================================================================

@app.post("/api/iniciar-plan")
async def iniciar_plan(request: IniciarPlanRequest):
    try:
        plan_existente = supabase.table('plan_seguimiento').select('*').eq('usuario_id', request.user_id).eq('activo', True).execute()

        if plan_existente.data:
            supabase.table('plan_seguimiento').update({
                'activo': False
            }).eq('id', plan_existente.data[0]['id']).execute()

        nuevo_plan = supabase.table('plan_seguimiento').insert({
            'usuario_id': request.user_id,
            'fecha_inicio': request.fecha_inicio,
            'activo': True
        }).execute()

        return {"message": "Plan iniciado correctamente", "plan": nuevo_plan.data[0]}
    except Exception as e:
        import traceback
        log_chile(f"ERROR iniciando plan: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/calendario-seguimiento/{user_id}")
async def obtener_calendario_seguimiento(user_id: str):
    try:
        plan = supabase.table('plan_seguimiento').select('*').eq('usuario_id', user_id).eq('activo', True).execute()

        if not plan.data:
            return {
                "plan_activo": False,
                "mensaje": "No hay plan activo"
            }

        plan_data = plan.data[0]
        fecha_inicio = datetime.strptime(plan_data['fecha_inicio'], '%Y-%m-%d').date()
        chile_tz = pytz.timezone('America/Santiago')
        fecha_actual = datetime.now(chile_tz).date()

        dias_transcurridos = (fecha_actual - fecha_inicio).days

        controles = []
        for i in range(1, 25):
            fecha_control = fecha_inicio + timedelta(days=i * 15)
            control = {
                "numero_control": i,
                "fecha": str(fecha_control),
                "dias_desde_inicio": i * 15,
                "completado": fecha_control <= fecha_actual
            }
            controles.append(control)

        registros_peso = supabase.table('registro_peso').select('*').eq('usuario_id', user_id).order('fecha', desc=False).execute()

        return {
            "plan_activo": True,
            "fecha_inicio": str(fecha_inicio),
            "fecha_actual": str(fecha_actual),
            "dias_transcurridos": dias_transcurridos,
            "controles": controles,
            "registros_peso": registros_peso.data if registros_peso.data else [],
            "proximo_control": next((c for c in controles if not c["completado"]), None)
        }
    except Exception as e:
        import traceback
        log_chile(f"ERROR obteniendo calendario: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/registrar-peso")
async def registrar_peso(request: RegistrarPesoRequest):
    try:
        chile_tz = pytz.timezone('America/Santiago')
        fecha_actual = datetime.now(chile_tz)

        registro_hoy = supabase.table('registro_peso').select('*').eq('usuario_id', request.user_id).eq('fecha', fecha_actual.date().isoformat()).execute()

        if registro_hoy.data:
            registro = supabase.table('registro_peso').update({
                'peso': request.peso,
                'notas': request.notas,
                'hora': fecha_actual.time().isoformat()
            }).eq('id', registro_hoy.data[0]['id']).execute()
            mensaje = "Peso actualizado correctamente"
        else:
            registro = supabase.table('registro_peso').insert({
                'usuario_id': request.user_id,
                'peso': request.peso,
                'fecha': fecha_actual.date().isoformat(),
                'hora': fecha_actual.time().isoformat(),
                'notas': request.notas
            }).execute()
            mensaje = "Peso registrado correctamente"

        supabase.table('usuarios').update({
            'peso': request.peso
        }).eq('id', request.user_id).execute()

        return {"message": mensaje, "registro": registro.data[0]}
    except Exception as e:
        import traceback
        log_chile(f"ERROR registrando peso: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# ENDPOINTS - LISTA DE COMPRAS
# ============================================================================

@app.get("/api/lista-compras/items")
async def obtener_items_comprados(user_id: str, semana_offset: int = 0):
    try:
        response = supabase.table('lista_compras_items').select('*').eq(
            'user_id', user_id
        ).eq('semana_offset', semana_offset).eq('comprado', True).execute()

        items_comprados = []
        for item in response.data:
            key = f"{item['categoria']}-{item['ingrediente']}"
            items_comprados.append(key)

        return {
            "success": True,
            "items_comprados": items_comprados,
            "total": len(items_comprados)
        }
    except Exception as e:
        import traceback
        log_chile(f"ERROR obteniendo items comprados: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/lista-compras/items")
async def guardar_item_comprado(request: ItemCompraRequest):
    try:
        if request.comprado:
            supabase.table('lista_compras_items').upsert({
                'user_id': request.user_id,
                'semana_offset': request.semana_offset,
                'categoria': request.categoria,
                'ingrediente': request.ingrediente,
                'comprado': True
            }, on_conflict='user_id,semana_offset,categoria,ingrediente').execute()
        else:
            supabase.table('lista_compras_items').delete().eq(
                'user_id', request.user_id
            ).eq('semana_offset', request.semana_offset).eq(
                'categoria', request.categoria
            ).eq('ingrediente', request.ingrediente).execute()

        return {
            "success": True,
            "message": f"Item {'marcado' if request.comprado else 'desmarcado'} correctamente"
        }
    except Exception as e:
        import traceback
        log_chile(f"ERROR guardando item: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/lista-compras/items/batch")
async def guardar_items_batch(request: ItemsCompraBatchRequest):
    try:
        if not request.items:
            raise HTTPException(status_code=400, detail="items no puede estar vacío")

        items_to_insert = []
        items_to_delete = []

        for item in request.items:
            categoria = item.get('categoria')
            ingrediente = item.get('ingrediente')
            comprado = item.get('comprado', True)

            if not categoria or not ingrediente:
                continue

            if comprado:
                items_to_insert.append({
                    'user_id': request.user_id,
                    'semana_offset': request.semana_offset,
                    'categoria': categoria,
                    'ingrediente': ingrediente,
                    'comprado': True
                })
            else:
                items_to_delete.append({
                    'categoria': categoria,
                    'ingrediente': ingrediente
                })

        if items_to_insert:
            supabase.table('lista_compras_items').upsert(
                items_to_insert,
                on_conflict='user_id,semana_offset,categoria,ingrediente'
            ).execute()

        for item_delete in items_to_delete:
            supabase.table('lista_compras_items').delete().eq(
                'user_id', request.user_id
            ).eq('semana_offset', request.semana_offset).eq(
                'categoria', item_delete['categoria']
            ).eq('ingrediente', item_delete['ingrediente']).execute()

        return {
            "success": True,
            "inserted": len(items_to_insert),
            "deleted": len(items_to_delete),
            "message": "Items guardados correctamente"
        }
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        log_chile(f"ERROR guardando batch: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/lista-compras/items/limpiar")
async def limpiar_items_semana(user_id: str, semana_offset: int = 0):
    try:
        supabase.table('lista_compras_items').delete().eq(
            'user_id', user_id
        ).eq('semana_offset', semana_offset).execute()

        return {
            "success": True,
            "message": "Items limpiados correctamente"
        }
    except Exception as e:
        import traceback
        log_chile(f"ERROR limpiando items: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/lista-compras/{user_id}")
async def obtener_lista_compras(user_id: str, semana_offset: int = 0):
    try:
        semana_actual = obtener_numero_semana()
        semana_objetivo = semana_actual + semana_offset

        if semana_objetivo > 52:
            semana_objetivo = semana_objetivo - 52
        elif semana_objetivo < 1:
            semana_objetivo = 52 + semana_objetivo

        recetas_response = supabase.table('recetas').select(
            'contenido, tipo_comida'
        ).eq('usuario_id', user_id).eq(
            'semana_numero', semana_objetivo
        ).eq('es_sugerencia', True).execute()

        if not recetas_response.data:
            return {
                "ingredientes": [],
                "semana_numero": semana_objetivo,
                "total_ingredientes": 0
            }

        ingredientes_agrupados = agrupar_ingredientes_mejorado(recetas_response.data)

        estados_response = supabase.table('lista_compras_items').select(
            'ingrediente, comprado, id, categoria'
        ).eq('user_id', user_id).eq('semana_offset', semana_offset).execute()

        estados_guardados = {}
        for item in estados_response.data:
            key = (item['categoria'], item['ingrediente'].lower())
            estados_guardados[key] = item

        ingredientes_lista = []
        for categoria, items in ingredientes_agrupados.items():
            for item in items:
                nombre = item['nombre']
                key = (categoria, nombre.lower())

                if key in estados_guardados:
                    ingrediente_dict = {
                        'id': estados_guardados[key]['id'],
                        'nombre': nombre,
                        'cantidad': item['cantidad'],
                        'categoria': categoria,
                        'completado': estados_guardados[key]['comprado']
                    }
                else:
                    nuevo_item = {
                        'user_id': user_id,
                        'semana_offset': semana_offset,
                        'ingrediente': nombre,
                        'categoria': categoria,
                        'comprado': False
                    }
                    
                    try:
                        result = supabase.table('lista_compras_items').insert(nuevo_item).execute()
                        item_id = result.data[0]['id'] if result.data else f"temp_{nombre.lower()}"
                    except:
                        item_id = f"temp_{nombre.lower()}"

                    ingrediente_dict = {
                        'id': item_id,
                        'nombre': nombre,
                        'cantidad': item['cantidad'],
                        'categoria': categoria,
                        'completado': False
                    }

                ingredientes_lista.append(ingrediente_dict)

        return {
            "ingredientes": ingredientes_lista,
            "semana_numero": semana_objetivo,
            "total_ingredientes": len(ingredientes_lista)
        }
    except Exception as e:
        import traceback
        log_chile(f"ERROR generando lista: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/lista-compras/toggle")
async def toggle_ingrediente_lista(request: ToggleIngredienteRequest):
    try:
        result = supabase.table('lista_compras_items').update({
            'comprado': request.completado
        }).eq('id', request.ingrediente_id).execute()

        if not result.data:
            return {"success": False, "message": "Ingrediente no encontrado"}

        return {
            "success": True,
            "completado": request.completado
        }
    except Exception as e:
        import traceback
        log_chile(f"ERROR en toggle: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# ENDPOINTS - CHATBOT CON IA
# ============================================================================

@app.post("/api/chat/message")
async def enviar_mensaje_chat(request: ChatMessageRequest):
    try:
        user_id = request.user_id
        mensaje = request.message
        include_context = request.include_context

        pide_receta = detectar_solicitud_receta(mensaje)
        contexto_usuario = obtener_contexto_usuario(user_id)

        if pide_receta:
            system_prompt = construir_prompt_sistema_con_receta(contexto_usuario)
        else:
            system_prompt = construir_prompt_sistema(contexto_usuario)

        historial_mensajes = []
        if include_context:
            historial_mensajes = obtener_historial_conversacion(user_id, limit=10)

        messages = [SystemMessage(content=system_prompt)]

        for msg in historial_mensajes:
            if msg['role'] == 'user':
                messages.append(HumanMessage(content=msg['content']))
            else:
                messages.append(AIMessage(content=msg['content']))

        messages.append(HumanMessage(content=mensaje))

        respuesta = llm.invoke(messages)
        respuesta_completa = respuesta.content

        tokens_usados = len(respuesta_completa.split())

        receta_generada = None
        mensaje_para_mostrar = respuesta_completa

        if pide_receta:
            mensaje_limpio, receta_dict = extraer_receta_json(respuesta_completa)
            if receta_dict:
                receta_generada = receta_dict
                mensaje_para_mostrar = mensaje_limpio

        guardar_mensajes_chat(user_id, mensaje, mensaje_para_mostrar, tokens_usados)

        response_data = {
            'message': mensaje_para_mostrar,
        }

        if receta_generada:
            response_data['receta'] = receta_generada

        return response_data
    except Exception as e:
        import traceback
        log_chile(f"ERROR en chat: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/guardar-receta-chat")
async def guardar_receta_chat(request: GuardarRecetaChatRequest):
    try:
        user_id = request.user_id
        receta = request.receta

        contenido_texto = f"""NOMBRE: {receta.get('nombre')}

DESCRIPCIÓN: {receta.get('descripcion')}

INGREDIENTES:
"""
        for ing in receta.get('ingredientes', []):
            contenido_texto += f"- {ing['nombre']} - {ing['cantidad']}\n"

        contenido_texto += f"\nPREPARACIÓN:\n"
        for i, paso in enumerate(receta.get('pasos', []), 1):
            contenido_texto += f"{i}. {paso}\n"

        contenido_texto += f"""
INFORMACIÓN NUTRICIONAL:
Proteínas: {receta.get('proteinas')}g
Carbohidratos: {receta.get('carbohidratos')}g
Grasas: {receta.get('grasas')}g
Calorías: {receta.get('calorias_por_porcion')} kcal

TIEMPO DE PREPARACIÓN: {receta.get('tiempo_preparacion')}

CONSEJOS:
Esta receta fue generada especialmente para ti por el asistente FitChi.
"""

        imagen_url = obtener_imagen_comida(receta.get('nombre'), 'comida')

        historial_data = {
            'usuario_id': user_id,
            'nombre': receta.get('nombre'),
            'tipo_comida': receta.get('tipo_comida', 'almuerzo'),
            'contenido_completo': contenido_texto,
            'calorias': receta.get('calorias_por_porcion'),
            'proteinas': receta.get('proteinas'),
            'carbohidratos': receta.get('carbohidratos'),
            'grasas': receta.get('grasas'),
            'tiempo_preparacion': receta.get('tiempo_preparacion'),
            'imagen_url': imagen_url,
            'is_favorito': False,
            'veces_vista': 1
        }

        result = supabase.table('historial_recetas').insert(historial_data).execute()

        if not result.data:
            raise HTTPException(status_code=500, detail="Error al guardar la receta")

        receta_id = result.data[0].get('id')

        return {
            "success": True,
            "message": "¡Receta guardada exitosamente en tu historial!",
            "receta_id": receta_id
        }
    except Exception as e:
        import traceback
        log_chile(f"ERROR guardando receta: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/chat/history")
async def obtener_historial_chat(user_id: str, limit: int = 50):
    try:
        response = supabase.table('chat_messages').select(
            'id, role, content, created_at, tokens_used'
        ).eq('user_id', user_id).neq('role', 'system').order(
            'created_at', desc=False
        ).limit(limit).execute()

        mensajes = response.data

        return {
            "success": True,
            "messages": mensajes,
            "total": len(mensajes) if mensajes else 0
        }
    except Exception as e:
        import traceback
        log_chile(f"ERROR obteniendo historial: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/chat/clear")
async def limpiar_historial_chat(user_id: str):
    try:
        supabase.table('chat_messages').delete().eq('user_id', user_id).execute()

        return {
            "success": True,
            "message": "Historial de chat eliminado correctamente"
        }
    except Exception as e:
        import traceback
        log_chile(f"ERROR limpiando historial: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# ENDPOINTS - AVATARES
# ============================================================================

@app.get("/api/avatares")
async def obtener_avatares():
    try:
        response = supabase.storage.from_('avatares').list()

        avatares = []
        for file in response:
            file_name = file['name']
            public_url = supabase.storage.from_('avatares').get_public_url(file_name)

            avatares.append({
                'name': file_name,
                'url': public_url
            })

        avatares.sort(key=lambda x: x['name'])

        return {
            "success": True,
            "avatares": avatares,
            "total": len(avatares)
        }
    except Exception as e:
        import traceback
        log_chile(f"ERROR obteniendo avatares: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

@app.put("/api/usuario/avatar")
async def actualizar_avatar(request: ActualizarAvatarRequest):
    try:
        response = supabase.table('usuarios').update({
            'avatar_url': request.avatar_url
        }).eq('id', request.user_id).execute()

        if not response.data:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")

        return {
            "success": True,
            "message": "Avatar actualizado correctamente",
            "avatar_url": request.avatar_url
        }
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        log_chile(f"ERROR actualizando avatar: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# INICIAR SERVIDOR
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
