from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from supabase import create_client, Client
import os
from datetime import datetime, timezone
import pytz
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
import time

load_dotenv()

app = FastAPI(title="FitChi API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Inicializar Supabase
supabase: Client = create_client(
    os.getenv("SUPABASE_URL"),
    os.getenv("SUPABASE_SERVICE_ROLE_KEY")
)

# Inicializar LangChain con OpenAI
llm = ChatOpenAI(
    model="gpt-3.5-turbo",
    temperature=0.9,
    openai_api_key=os.getenv("OPENAI_API_KEY")
)

class RecetaRequest(BaseModel):
    user_id: str
    tipo_comida: str

# ========================================
# UTILIDADES
# ========================================

def obtener_timezone_chile():
    """Obtiene timezone de Chile"""
    return pytz.timezone('America/Santiago')

def obtener_datetime_chile():
    """Obtiene datetime actual en zona horaria de Chile"""
    return datetime.now(obtener_timezone_chile())

def obtener_numero_semana():
    """Obtiene el número de semana del año (Chile timezone)"""
    return obtener_datetime_chile().isocalendar()[1]

def obtener_dia_semana_espanol(offset=0):
    """Obtiene el nombre del día en español (Chile timezone)"""
    dias = {
        0: "Lunes", 1: "Martes", 2: "Miércoles", 3: "Jueves",
        4: "Viernes", 5: "Sábado", 6: "Domingo"
    }
    ahora_chile = obtener_datetime_chile()
    dia_actual = (ahora_chile.weekday() + offset) % 7
    return dias[dia_actual]

def log_chile(mensaje):
    """Log con timestamp de Chile"""
    ahora = obtener_datetime_chile().strftime('%Y-%m-%d %H:%M:%S %Z')
    print(f"[{ahora}] {mensaje}")

# ========================================
# LÓGICA DE GENERACIÓN DE RECETAS
# ========================================

def generar_receta_logic(user_id: str, tipo_comida: str, dia_semana: str = None, semana: int = None):
    """Lógica reutilizable para generar una receta"""
    # Obtener datos del usuario
    usuario_response = supabase.table('usuarios').select("*").eq('id', user_id).execute()

    if not usuario_response.data or len(usuario_response.data) == 0:
        return None

    usuario = usuario_response.data[0] if isinstance(usuario_response.data, list) else usuario_response.data

    if not usuario:
        return None

    # Obtener recetas previas para evitar repeticiones
    recetas_previas_response = supabase.table('recetas').select("contenido").eq('usuario_id', user_id).order('created_at', desc=True).limit(3).execute()

    ingredientes_previos = []
    if recetas_previas_response.data:
        for receta in recetas_previas_response.data:
            contenido = receta.get('contenido', '')
            if 'INGREDIENTES:' in contenido:
                ingredientes_previos.append(contenido.split('INGREDIENTES:')[1].split('PREPARACIÓN:')[0])
    
    contexto_previas = ""
    if ingredientes_previos:
        contexto_previas = f"\n\nRECETAS RECIENTES DEL USUARIO (EVITA REPETIR ESTOS INGREDIENTES):\n{chr(10).join(ingredientes_previos[:200])}"
    
    # Obtener preferencias alimentarias
    preferencias_response = supabase.table('preferencias_alimentarias').select("preferencia").eq('usuario_id', user_id).execute()
    preferencias_lista = [p['preferencia'] for p in preferencias_response.data]
    preferencias = ', '.join(preferencias_lista) if preferencias_lista else 'sin restricciones especiales'
    
    # Datos nutricionales
    numero_comidas = usuario.get('numero_comidas', 3)
    calorias_comida = usuario.get('calorias_objetivo', 2000) // numero_comidas
    proteinas_comida = usuario.get('proteinas_gramos', 150) // numero_comidas
    carbos_comida = usuario.get('carbohidratos_gramos', 200) // numero_comidas
    grasas_comida = usuario.get('grasas_gramos', 60) // numero_comidas
    
    # Datos personales
    objetivo = usuario.get('objetivo_nutricional', 'Mantenimiento')
    nivel_actividad = usuario.get('nivel_actividad', 'Moderada')
    peso = usuario.get('peso', 'No especificado')
    altura = usuario.get('altura', 'No especificada')
    sexo = usuario.get('sexo', 'No especificado')
    
    # Calcular edad
    edad = 'No especificada'
    fecha_nac = usuario.get('fecha_nacimiento')
    if fecha_nac:
        try:
            fecha_nac_dt = datetime.fromisoformat(str(fecha_nac))
            hoy = datetime.now()
            edad = hoy.year - fecha_nac_dt.year
            if hoy.month < fecha_nac_dt.month or (hoy.month == fecha_nac_dt.month and hoy.day < fecha_nac_dt.day):
                edad -= 1
        except:
            pass
    
    alergias = usuario.get('alergias') or 'ninguna'
    patologia = usuario.get('patologia') or 'ninguna'
    
    contexto_objetivo = {
        "Déficit calórico (pérdida de grasa)": "enfocada en saciedad, alto contenido de fibra y proteínas, baja densidad calórica",
        "Superávit (ganancia muscular)": "rica en proteínas de alta calidad, carbohidratos complejos para energía",
        "Mantenimiento": "balanceada y variada",
        "Recomposición corporal": "alta en proteínas, moderada en carbohidratos, enfocada en nutrientes de calidad"
    }
    
    descripcion_objetivo = contexto_objetivo.get(objetivo, "balanceada")
    
    # Crear el prompt template con LangChain - VERSIÓN REGIONALIZADA CHILE
    prompt_template = PromptTemplate(
        input_variables=["sexo", "edad", "peso", "altura", "nivel_actividad", "objetivo", 
                       "tipo_comida", "calorias_comida", "proteinas_comida", "carbos_comida", 
                       "grasas_comida", "alergias", "patologia", "preferencias", "descripcion_objetivo", "contexto_previas"],
    template="""Eres un nutricionista profesional chileno. Genera UNA receta saludable y práctica usando ESPAÑOL DE CHILE.
{contexto_previas}

IMPORTANTE - REGIONALIZACIÓN:
- Usa vocabulario y términos culinarios de Chile (palta, porotos, choclo, zapallo, betarraga, etc.)
- Solo ingredientes disponibles en supermercados chilenos (Líder, Jumbo, Unimarc, Santa Isabel)
- Medidas en uso común en Chile (cucharadas, tazas, gramos, unidades)
- Lenguaje natural y cercano, como hablaría un nutricionista chileno
- Preparaciones típicas chilenas son bienvenidas cuando sea apropiado

VARIEDAD:
- Genera recetas VARIADAS usando diferentes ingredientes principales
- Considera cocina chilena, mediterránea, asiática, mexicana (todas adaptadas a ingredientes locales)
- Evita repetir ingredientes base
- Métodos variados: horno, salteado, plancha, vapor, guisado

PERFIL DEL USUARIO:
- Sexo: {sexo} | Edad: {edad} años | Peso: {peso} kg | Altura: {altura} cm
- Nivel de actividad: {nivel_actividad}
- Objetivo: {objetivo}

REQUERIMIENTOS NUTRICIONALES ({tipo_comida}):
- Calorías: {calorias_comida} kcal (±50 kcal)
- Proteínas: {proteinas_comida}g (±5g)
- Carbohidratos: {carbos_comida}g (±10g)
- Grasas: {grasas_comida}g (±5g)

RESTRICCIONES:
- Alergias: {alergias}
- Condiciones médicas: {patologia}
- Preferencias: {preferencias}

La receta debe ser {descripcion_objetivo}, práctica, económica y con ingredientes accesibles en Chile.

FORMATO DE RESPUESTA:

NOMBRE:
[Nombre atractivo]

INGREDIENTES:
- [ingrediente] - [cantidad]

PREPARACIÓN:
1. [Paso detallado]

INFORMACIÓN NUTRICIONAL:
Proteínas: [X]g
Carbohidratos: [X]g
Grasas: [X]g
Calorías: [X] kcal

TIEMPO DE PREPARACIÓN: [X minutos]

CONSEJOS:
[Tips personalizados para el objetivo {objetivo}]

Genera una receta variada, deliciosa y 100% adaptada a Chile."""
    )
    
    # Formatear el prompt con los datos
    formatted_prompt = prompt_template.format(
        sexo=sexo,
        edad=edad,
        peso=peso,
        altura=altura,
        nivel_actividad=nivel_actividad,
        objetivo=objetivo,
        tipo_comida=tipo_comida.upper(),
        calorias_comida=calorias_comida,
        proteinas_comida=proteinas_comida,
        carbos_comida=carbos_comida,
        grasas_comida=grasas_comida,
        alergias=alergias,
        patologia=patologia,
        preferencias=preferencias,
        descripcion_objetivo=descripcion_objetivo,
        contexto_previas=contexto_previas
    )
    
    # Generar la receta usando LangChain
    receta_contenido = llm.invoke(formatted_prompt).content
    
    # Preparar datos para guardar
    receta_data = {
        'usuario_id': user_id,
        'contenido': receta_contenido,
        'tipo_comida': tipo_comida,
        'calorias_objetivo': calorias_comida,
        'proteinas_objetivo': proteinas_comida,
        'carbos_objetivo': carbos_comida,
        'grasas_objetivo': grasas_comida,
        'objetivo_nutricional': objetivo,
        'modelo': 'gpt-3.5-turbo-langchain-cl',
        'dia_semana': dia_semana,
        'semana_numero': semana or obtener_numero_semana(),
        'es_sugerencia': True if dia_semana else False
    }
    
    return receta_data
    
def generar_resto_semana_desde_martes(user_id: str, semana: int):
    """Genera de Martes a Domingo (Lunes ya se generó antes)"""
    log_chile(f"🔄 Generando Martes-Domingo para usuario {user_id}")
    
    dias = ["Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
    tipos_comida = ["desayuno", "almuerzo", "cena", "snack"]
    
    try:
        for dia in dias:
            for tipo in tipos_comida:
                receta_data = generar_receta_logic(user_id, tipo, dia, semana)
                if receta_data:
                    supabase.table('recetas').insert(receta_data).execute()
                    log_chile(f"✅ Generada: {dia} - {tipo}")
                time.sleep(1)  # Evitar rate limits
        
        log_chile(f"✅ Semana completa generada para usuario {user_id}")
    except Exception as e:
        log_chile(f"❌ Error generando semana: {e}")

# ========================================
# ENDPOINTS
# ========================================

@app.get("/")
async def root():
    return {"message": "FitChi API funcionando con Supabase y LangChain", "version": "2.2.0"}

@app.get("/api/debug/timezone")
async def debug_timezone():
    """Endpoint de debug para verificar timezone"""
    import pytz
    from datetime import datetime
    
    # UTC
    utc_now = datetime.now(pytz.UTC)
    
    # Chile
    chile_tz = pytz.timezone('America/Santiago')
    chile_now = datetime.now(chile_tz)
    
    # Día detectado
    dias = {
        0: "Lunes", 1: "Martes", 2: "Miércoles", 3: "Jueves",
        4: "Viernes", 5: "Sábado", 6: "Domingo"
    }
    dia_chile = dias[chile_now.weekday()]
    
    return {
        "utc_time": utc_now.strftime('%Y-%m-%d %H:%M:%S %Z'),
        "chile_time": chile_now.strftime('%Y-%m-%d %H:%M:%S %Z'),
        "dia_detectado": dia_chile,
        "semana_numero": chile_now.isocalendar()[1],
        "timezone_configurado": os.getenv('TZ', 'NO CONFIGURADO')
    }

@app.post("/api/generar-receta")
async def generar_receta(request: RecetaRequest):
    """Genera una receta individual (endpoint original)"""
    try:
        receta_data = generar_receta_logic(request.user_id, request.tipo_comida)
        
        if not receta_data:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")
        
        # Guardar receta
        supabase.table('recetas').insert(receta_data).execute()
        
        return {"receta_completa": receta_data['contenido']}
        
    except Exception as e:
        import traceback
        error_detail = traceback.format_exc()
        log_chile(f"❌ ERROR COMPLETO:")
        print(error_detail)
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/inicializar-menu-usuario")
async def inicializar_menu_usuario(request: RecetaRequest, background_tasks: BackgroundTasks):
    """Genera semana COMPLETA desde Lunes, independiente del día actual"""
    try:
        user_id = request.user_id
        semana_actual = obtener_numero_semana()
        
        log_chile(f"🔍 Iniciando generación de semana completa para user: {user_id}")
        
        # Verificar si ya tiene menú de esta semana
        menu_existente = supabase.table('recetas').select("id").eq(
            'usuario_id', user_id
        ).eq(
            'semana_numero', semana_actual
        ).limit(1).execute()
        
        if menu_existente.data:
            log_chile(f"⚠️ Usuario ya tiene menú de semana {semana_actual}")
            return {
                "message": "Usuario ya tiene menú de esta semana",
                "status": "exists"
            }
        
        # CAMBIO CLAVE: Siempre empezar desde LUNES
        dia_inicio = "Lunes"
        
        log_chile(f"🔍 Generando desde {dia_inicio} (semana completa)")
        
        # Generar recetas de LUNES inmediatamente (4 recetas)
        recetas_lunes = []
        for tipo in ["desayuno", "almuerzo", "cena", "snack"]:
            log_chile(f"🔍 Generando {tipo} para {dia_inicio}")
            receta_data = generar_receta_logic(user_id, tipo, dia_inicio, semana_actual)
            if receta_data:
                log_chile(f"✅ Receta {tipo} generada")
                result = supabase.table('recetas').insert(receta_data).execute()
                log_chile(f"✅ Receta {tipo} guardada")
                recetas_lunes.append(tipo)
            else:
                log_chile(f"❌ Fallo generando {tipo}")
        
        log_chile(f"🔍 Recetas de Lunes generadas: {recetas_lunes}")
        
        # Programar Martes-Domingo en background
        background_tasks.add_task(generar_resto_semana_desde_martes, user_id, semana_actual)
        log_chile(f"✅ Background task programado para Martes-Domingo")
        
        return {
            "message": "Generando tu semana completa (Lunes-Domingo)...",
            "status": "processing",
            "recetas_lunes": recetas_lunes,
            "semana": semana_actual
        }
        
    except Exception as e:
        import traceback
        log_chile(f"❌ ERROR COMPLETO: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/menu-semanal/{user_id}")
async def obtener_menu_semanal(user_id: str):
    """Obtiene el menú de la semana actual"""
    try:
        semana_actual = obtener_numero_semana()
        
        recetas = supabase.table('recetas').select(
            "id, contenido, tipo_comida, dia_semana, calorias_objetivo, created_at"
        ).eq('usuario_id', user_id).eq('semana_numero', semana_actual).eq('es_sugerencia', True).execute()
        
        # Organizar por día y tipo
        menu_organizado = {}
        dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
        
        for dia in dias:
            menu_organizado[dia] = {
                "desayuno": None,
                "almuerzo": None,
                "cena": None,
                "snack": None
            }
        
        for receta in recetas.data:
            dia = receta['dia_semana']
            tipo = receta['tipo_comida']
            
            # Extraer nombre
            nombre = "Receta"
            if 'NOMBRE:' in receta['contenido']:
                nombre = receta['contenido'].split('NOMBRE:')[1].split('\n')[0].strip()
            
            if dia in menu_organizado:
                menu_organizado[dia][tipo] = {
                    'id': receta['id'],
                    'nombre': nombre,
                    'calorias': receta['calorias_objetivo'],
                    'contenido_completo': receta['contenido']
                }
        
        # Contar recetas generadas
        total_esperadas = 28  # 7 días × 4 comidas
        total_generadas = len(recetas.data)
        progreso = (total_generadas / total_esperadas) * 100
        
        return {
            "menu": menu_organizado,
            "semana": semana_actual,
            "progreso": round(progreso),
            "completo": total_generadas == total_esperadas
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/historial-recetas/{user_id}")
async def obtener_historial(user_id: str):
    """Obtiene el historial de recetas del usuario"""
    try:
        recetas = supabase.table('recetas').select(
            "id, contenido, tipo_comida, calorias_objetivo, created_at, objetivo_nutricional"
        ).eq('usuario_id', user_id).order('created_at', desc=True).limit(50).execute()
        
        # Extraer nombre de cada receta
        recetas_formateadas = []
        for receta in recetas.data:
            nombre = "Receta sin nombre"
            if 'NOMBRE:' in receta['contenido']:
                nombre = receta['contenido'].split('NOMBRE:')[1].split('\n')[0].strip()
            
            recetas_formateadas.append({
                'id': receta['id'],
                'nombre': nombre,
                'tipo_comida': receta['tipo_comida'],
                'calorias': receta['calorias_objetivo'],
                'fecha': receta['created_at'],
                'objetivo': receta['objetivo_nutricional'],
                'contenido_completo': receta['contenido']
            })
        
        return {"recetas": recetas_formateadas}
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
